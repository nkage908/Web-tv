// constants.js — все магические числа и строки проекта

// ─── Приложение ───────────────────────────────────────────────────────────────
export const APP_NAME = 'IPTV Player';

// ─── Плеер / фейд ─────────────────────────────────────────────────────────────
/** Страховочный таймаут фейда: если loadeddata/playing не сработали */
export const FADE_FALLBACK_MS = 1200;
/** Минимально допустимая длительность фейда, мс */
export const FADE_DURATION_MIN_MS = 50;
/** Максимально допустимая длительность фейда, мс */
export const FADE_DURATION_MAX_MS = 2000;
/** Таймаут network-прогрева URL следующего потока перед fade-out (DNS/TCP/TLS + манифест), мс.
 *  Запрос отменяется по истечении этого времени, чтобы не висеть, если сервер не отвечает. */
export const STREAM_PREFETCH_TIMEOUT_MS = 4000;
/** Максимальный размер ответа, который прогрев читает целиком (HLS-манифест — это маленький текст).
 *  Всё больше этого или не текстовое (видео, бесконечный поток) не скачивается — тело отменяется. */
export const STREAM_PREFETCH_MAX_MANIFEST_BYTES = 512 * 1024;
/** Не прогревать один и тот же URL чаще, чем раз в это время, мс (прогретое соединение всё равно протухает) */
export const STREAM_PREFETCH_DEDUPE_MS = 30_000;

// ─── HLS ──────────────────────────────────────────────────────────────────────
/** backBufferLength для явных HLS-потоков (секунды) */
export const HLS_BACK_BUFFER = 90;
/** backBufferLength при автоопределении формата (секунды) */
export const HLS_BACK_BUFFER_AUTO = 30;
/** Таймаут автоопределения HLS перед fallback на progressive, мс */
export const HLS_AUTO_DETECT_TIMEOUT_MS = 5000;
/** Сколько раз подряд пробовать recoverMediaError/startLoad перед тем как
 *  сдаться и переключиться на progressive-fallback */
export const HLS_MAX_RECOVER_ATTEMPTS = 3;

// ─── MPEG-TS ──────────────────────────────────────────────────────────────────
/** Таймаут загрузки MPEG-TS потока, мс */
export const MPEGTS_LOAD_TIMEOUT_MS = 8000;
/** Задержка показа подсказки «Используйте VLC», мс */
export const MPEGTS_VLC_TIP_DELAY_MS = 3000;
/** Задержка показа альтернативных решений после ошибки, мс */
export const MPEGTS_ALT_SOLUTIONS_DELAY_MS = 2000;
/** Интервал между строками showAlternativeSolutions, мс */
export const MPEGTS_ALT_SOLUTIONS_INTERVAL_MS = 4000;

// ─── UI / таймауты ────────────────────────────────────────────────────────────
/** Таймаут скрытия статус-индикатора для type==='info', мс */
export const STATUS_HIDE_INFO_MS = 5000;
/** Таймаут скрытия статус-индикатора для остальных типов, мс */
export const STATUS_HIDE_DEFAULT_MS = 3000;
/** Таймаут скрытия панели loader, мс */
export const PANEL_HIDE_LOADER_MS = 5000;
/** Таймаут скрытия прочих панелей, мс */
export const PANEL_HIDE_DEFAULT_MS = 2000;
/** Таймаут скрытия видео-контролов при тапе, мс */
export const VIDEO_CONTROLS_HIDE_MS = 3500;
/** Задержка возобновления последнего канала после загрузки плейлиста, мс */
export const RESUME_CHANNEL_DELAY_MS = 1500;
/** Задержка скрытия текущего EPG-элемента при открытии дровера, мс */
export const EPG_DRAWER_SCROLL_DELAY_MS = 350;
/** Задержка закрытия EPG-дровера (анимация), мс */
export const EPG_DRAWER_CLOSE_DELAY_MS = 320;
/** Таймаут первого тика прогресс-баров EPG после DOMContentLoaded, мс */
export const EPG_TICK_INIT_DELAY_MS = 1000;
/** Интервал обновления прогресс-баров EPG, мс */
export const EPG_TICK_INTERVAL_MS = 60_000;
/** Задержка перед скроллом к категории при нажатии G, мс */
export const HOTKEY_DRAWER_SCROLL_DELAY_MS = 100;
/** Задержка фокуса поиска при нажатии /, мс */
export const HOTKEY_SEARCH_FOCUS_DELAY_MS = 150;
/** Задержка переключения на введённый номер канала (время на ввод 4-5 цифр), мс */
export const HOTKEY_CHANNEL_NUMBER_DELAY_MS = 1500;
/** Максимальная длительность свайпа для закрытия дровера, px */
export const DRAWER_SWIPE_CLOSE_THRESHOLD_PX = 80;
/** Максимальное смещение при свайпе дровера, px */
export const DRAWER_SWIPE_MAX_PX = 300;
/** Минимальное горизонтальное смещение для свайпа переключения канала, px */
export const CHANNEL_SWIPE_MIN_X_PX = 60;
/** Максимальное вертикальное отклонение при горизонтальном свайпе канала, px */
export const CHANNEL_SWIPE_MAX_Y_PX = 50;
/** Минимальное смещение по вертикали, чтобы начать жест яркость/громкость, px */
export const VJ_GESTURE_MIN_Y_PX = 12;
/** Высота экрана (px), соответствующая полному диапазону яркости/громкости (0-100%) */
export const VJ_GESTURE_FULL_RANGE_PX = 300;
/** Минимальное значение яркости (filter: brightness), доля */
export const BRIGHTNESS_MIN = 0.3;
/** Максимальное значение яркости (filter: brightness), доля */
export const BRIGHTNESS_MAX = 1.7;

// ─── Скорость воспроизведения VOD ──────────────────────────────────────────────
/** Доступные значения скорости воспроизведения (кнопка на панели плеера, только для VOD) */
export const PLAYBACK_RATES = [0.25, 0.5, 0.75, 1, 1.25, 1.5, 2];
/** Скорость по умолчанию при старте нового ролика */
export const PLAYBACK_RATE_DEFAULT = 1;

// ─── TV-режим / spatial navigation (пульт) ─────────────────────────────────────
/** Штраф за перпендикулярное смещение при поиске ближайшего фокусируемого элемента (чем больше — тем строже требуется совпадение по оси движения) */
export const TV_NAV_PERPENDICULAR_PENALTY = 3;
/** Селектор фокусируемых элементов в TV-режиме.
 *  Включает [tabindex="-1"] намеренно: элементы списка каналов/категорий помечены tabindex="-1",
 *  чтобы НЕ попадать в обычный Tab-порядок браузера, но программный spatial-navigation фокус
 *  на них ставить можно и нужно. */
export const TV_NAV_FOCUSABLE_SELECTOR = 'button:not([disabled]), [tabindex]:not([disabled]), input[type="range"]:not([disabled]), a[href]';
/** Шаг изменения значения range-слайдера (громкость) при Left/Right в TV-режиме, % */
export const TV_NAV_RANGE_STEP = 5;

// ─── Virtual scroll ───────────────────────────────────────────────────────────
/** Min channels in a group before virtual scroll kicks in */
export const VS_THRESHOLD = 80;
/** Items rendered above/below the visible window */
export const VS_OVERSCAN = 8;
/** Fallback row height (px) when measurement hasn't happened yet */
export const VS_ROW_HEIGHT_FALLBACK = 38;
/** Max height of a virtualised list as a fraction of viewport height */
export const VS_MAX_HEIGHT_VH = 0.62;

// ─── Storage ──────────────────────────────────────────────────────────────────
/** Максимальное количество сохранённых плейлистов */
export const PLAYLISTS_MAX_COUNT = 10;
/** TTL последнего канала: 24 часа в мс */
export const LAST_CHANNEL_TTL_MS = 86_400_000;

// ─── Режимы воспроизведения по завершении ролика ──────────────────────────────
/** Единая настройка режима, отображаемая кнопкой на панели плеера.
 *  Каждый режим разворачивается в пару playbackEnd/categoryEnd (см. player.js) */
export const PLAY_MODES = {
  pause: { icon: '⏸', label: 'Пауза', hint: 'Остановиться после ролика' },
loop_video:{icon:'🔂',
  label: 'Зациклить ролик',
  hint: 'Повторять текущий ролик' },
  loop_group: { icon: '🔁',
  label: 'Зациклить группу',
  hint: 'Повторять текущую категорию' },
  loop_playlist: { icon: '🔄', label: 'Зациклить плейлист', hint: 'Повторять весь плейлист' },
  random_category: { icon: '🔀', label: 'Рандом по категории',     hint: 'Случайный ролик из текущей категории' },
  random_playlist: { icon: '🎲', label: 'Рандом по плейлисту', hint: 'Случайный ролик из всего плейлиста' },
};
export const PLAY_MODE_ORDER = ['pause', 'loop_video', 'loop_group', 'loop_playlist', 'random_category', 'random_playlist'];

// ─── Режим демонстрации ────────────────────────────────────────────────────────
/** Минимально допустимое пользователем значение длительности/числа фрагментов */
export const DEMO_PARAM_MIN = 1;
/** Максимально допустимое пользователем значение длительности/числа фрагментов */
export const DEMO_PARAM_MAX = 60;
/** Сколько миллисекунд остаётся видна подпись «сейчас показывается» в демо-режиме */
export const DEMO_NOW_PLAYING_VISIBLE_MS = 2000;
/** Пауза перед стартом показа фрагментов после сигнала готовности видео — даёт
 *  HLS.js время уточнить state.isLiveStream (событие LEVEL_LOADED обычно приходит
 *  на тик позже 'playing'), чтобы VOD-ролик в HLS-упаковке не был принят за live. */
export const DEMO_LIVE_FLAG_SETTLE_MS = 250;

// ─── Теги каналов ───────────────────────────────────────────────────────────────
/** Максимальное число тематических групп тегов */
export const TAG_GROUPS_MAX_COUNT = 40;
/** Максимальное число тегов внутри одной группы */
export const TAGS_PER_GROUP_MAX_COUNT = 200;

// ─── Настройки по умолчанию ───────────────────────────────────────────────────
export const DEFAULT_SETTINGS = {
  theme: 'dark',
  videoFit: 'contain',
  fontSize: 'normal',
  autoplay: true,
  menuTimeout: 10000,
  volume: 30,
  seekStep: 15,
  volumeStep: 5,
  autoLoadPlaylist: true,
  enableEPG: false,
  epgUrl: '',
  epgUseCORS: false,
  epgMatchBy: 'id',
  epgIncludePast: false,
  epgTimezone: 'auto',
  playbackEnd: 'next',
  categoryEnd: 'next',
  fadeTransition: true,
  fadeDuration: 1000,
  prefetchNext: true,
  showChannelNumbers: true,
  playMode: 'loop_playlist',
  tvMode: false,
  demoSegmentDuration: 5,
  demoFragmentsCount: 5,
};
