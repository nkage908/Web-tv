import { state, escapeHtml } from './state.js';
import { playlistManager, loadSettings, loadLastChannel } from './storage.js';
import { showStatus } from './ui.js';
import { getWorker } from './worker-bridge.js';
import { loadEPG } from './epg.js';
import { renderCategories, vsInvalidateCache } from './drawer.js';
import { playStream, invalidateChannelCache } from './player.js';
import { RESUME_CHANNEL_DELAY_MS } from './constants.js';

let _pendingM3USave = null;

export function onM3UParsed({ channels, grouped, detectedEPG, excludedCount }) {
  state.currentChannelElement = null;
  state.allChannels = channels;
  state.groupedChannels = grouped;
  state.playlistData = channels;
  state.activeSearchQuery = '';
  state.activeSearchList = [];
  invalidateChannelCache(); // сбрасываем кеш url→channel
  vsInvalidateCache();      // сбрасываем кеш высот строк виртуального скролла
  if (_pendingM3USave) {
    playlistManager.save(_pendingM3USave.name, _pendingM3USave.sourceUrl, _pendingM3USave.text);
    _pendingM3USave = null;
  }
  document.getElementById('loader')?.classList.remove('visible');
  document.getElementById('introOverlay')?.classList.add('hidden');
  document.getElementById('mainContent')?.classList.remove('blurred');
  renderCategories();
  renderSavedPlaylists();
  showStatus(`✅ Плейлист загружен: ${channels.length} каналов${excludedCount > 0 ? ` (исключено ${excludedCount})` : ''}`, 'success');
  const settings = loadSettings();
  if (settings.enableEPG) {
    if (settings.epgUrl) loadEPG(settings.epgUrl, settings.epgUseCORS);
    else if (detectedEPG) loadEPG(detectedEPG, settings.epgUseCORS);
  }
  // Автовозобновление — только при первой загрузке (ничего ещё не играет), если включено «автовоспроизведение»,
  // и только если пользователь сам не успел выбрать канал за время задержки
  const startedUrl = state.currentChannelUrl;
  const last = loadLastChannel();
  if (settings.autoplay && !startedUrl && last && state.allChannels.some(ch => ch.url === last.url)) {
    setTimeout(() => {
      if (state.currentChannelUrl) return;
      playStream(last.url, last.title);
      showStatus(`Возобновлён просмотр: ${last.title}`, 'info');
    }, RESUME_CHANNEL_DELAY_MS);
  }
}

export const parseM3U = (data, sourceUrl = '', saveName = '') => {
  state.playlistData = [];
  state.groupedChannels = {};
  state.allChannels = [];
  state.epgData = {};
  state.epgIndex = new Map();
  if (saveName) _pendingM3USave = { text: data, name: saveName, sourceUrl };
  showStatus('⚙️ Парсинг плейлиста...', 'loading');
  getWorker().postMessage({ type: 'parse_m3u', payload: { text: data } });
};

const tryProxies = async proxies => {
  for (const proxyUrl of proxies) {
    try {
      const r = await fetch(proxyUrl);
      if (!r.ok) continue;
      const ct = r.headers.get('content-type') || '';
      if (ct.includes('application/json')) {
        const data = await r.json();
        return data.contents || data.data || JSON.stringify(data);
      }
      return await r.text();
    } catch (err) {
      console.warn(`Proxy ${proxyUrl} failed:`, err);
    }
  }
  throw new Error('Не удалось загрузить плейлист через прокси');
};

export const fetchWithCORS = async (url, useCORS = true) => {
  try {
    const r = await fetch(url, { mode: 'cors', headers: { 'Accept': 'text/plain, application/x-mpegURL, */*' } });
    if (!r.ok) throw new Error(`HTTP ${r.status}: ${r.statusText}`);
    return await r.text();
  } catch (error) {
    const isFetchError = error instanceof TypeError || error.name === 'TypeError' ||
      (error.name === 'AbortError') || String(error.message).match(/fetch|network|failed|load/i);
    if (useCORS && isFetchError) {
      console.log('Direct fetch failed, trying CORS proxies...');
      return tryProxies([
        `https://api.allorigins.win/get?url=${encodeURIComponent(url)}`,
        `https://corsproxy.io/?${encodeURIComponent(url)}`,
        `https://cors-anywhere.herokuapp.com/${url}`,
      ]);
    }
    throw error;
  }
};

export const loadFromURL = (inputId, save = true) => {
  const url = document.getElementById(inputId).value;
  if (!url) return;
  showStatus('Загрузка плейлиста...', 'loading');
  fetchWithCORS(url)
    .then(data => {
      const name = save ? url.split('/').pop().replace(/\.[^/.]+$/, '') || 'Плейлист' : '';
      parseM3U(data, url, name);
    })
    .catch(err => { showStatus('Ошибка загрузки плейлиста', 'error'); console.error(err); });
};

export const loadSavedPlaylist = id => {
  const playlist = playlistManager.load(id);
  if (playlist) {
    parseM3U(playlist.data, playlist.url, '');
    showStatus(`Загружен сохраненный плейлист: ${playlist.name}`, 'success');
  }
};

export const deleteSavedPlaylist = id => {
  playlistManager.remove(id);
  renderSavedPlaylists();
  showStatus('Плейлист удален', 'info');
};

export const renderSavedPlaylists = () => {
  const container = document.getElementById('savedPlaylists');
  const selector = document.getElementById('playlistSelector');
  const playlists = playlistManager.getAll();
  if (container) {
    container.innerHTML = playlists.length > 0
      ? `<h4>Сохраненные плейлисты:</h4>${playlists.map(p =>
        `<div class="saved-playlist">
          <span class="saved-playlist-name" data-id="${p.id}" style="cursor:pointer;flex:1">${escapeHtml(p.name)}</span>
          <small>${new Date(p.lastUsed).toLocaleDateString()}</small>
          <button class="saved-playlist-del" data-id="${p.id}" style="margin-left:10px">✕</button>
        </div>`).join('')}`
      : '<small>Нет сохраненных плейлистов</small>';
  }
  if (selector) {
    selector.innerHTML = `<option value="">Выберите плейлист...</option>${playlists.map(p =>
      `<option value="${p.id}">${escapeHtml(p.name)}</option>`).join('')}`;
  }
};

document.addEventListener('DOMContentLoaded', () => {
  document.getElementById('savedPlaylists')?.addEventListener('click', e => {
    const name = e.target.closest('.saved-playlist-name');
    if (name) { loadSavedPlaylist(name.dataset.id); return; }
    const del = e.target.closest('.saved-playlist-del');
    if (del) deleteSavedPlaylist(del.dataset.id);
  });
});


