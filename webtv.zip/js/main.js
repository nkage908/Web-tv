import { showStatus, showPanel, hidePanel, keepPanelVisible, showHeaderMobile } from './ui.js';
import { loadSettings, loadLastChannel, playlistManager } from './storage.js';
import { state, isMobile } from './state.js';
import { parseM3U, loadFromURL, loadSavedPlaylist, deleteSavedPlaylist, renderSavedPlaylists, onM3UParsed } from './playlist.js';
import { loadEPG, loadEPGFromFile, epgScrollToDate, getChannelEPGKey, onEPGParsed, onEPGChunk } from './epg.js';
import { playStream, vcSeekClick, tickEPGProgressBars, startEPGPlayerTick, stopEPGPlayerTick, tickEPGPlayerBar, toggleMute, seekVideo, changeVolume, toggleFullscreen, applyFullscreenUI, initVideoEvents, vcTogglePlay, vcSetVolume, cyclePlayMode, updatePlayModeButton, vcTogglePlaybackRateMenu, vcSetPlaybackRate } from './player.js';
import { startDemoMode, stopDemoMode, toggleDemoMode, isDemoActive } from './demo.js';
import { openDrawer, closeDrawer, drawerOpenGroup, drawerClearSearch, openEPGDrawer, closeEPGDrawer, renderChannels, renderCategories, initDrawerEvents, _resetDrawerTimer, channelItemHtml, refreshCurrentGroup, vsInvalidateRowHeight, _vsRenderExport, refreshChannelListForTagFilter } from './drawer.js';
import { showSettings, hideSettings, saveSettings, toggleEPGUrlField, toggleFadeDurationField, applySettings, clearAllData } from './settings.js';
import { navigateChannel, toggleHotkeyHelp, initKeyboard } from './hotkeys.js';
import { onWorkerEvent } from './worker-bridge.js';
import { toggleFavourite, isFavourite } from './favourites.js';
import { initTvNav, setTvMode } from './tv-nav.js';
import { toggleTagFilterPanel, closeTagPopover, clearTagFilter, initTagPopoverEvents, addTagGroupFromUI, initTagsManagerEvents, initTagSelectEvents } from './tags.js';
import { initCastLazy, toggleCast } from './cast.js';
import { exportDataToFile, importDataFromFile, triggerImportPicker } from './data-export.js';
import { registerServiceWorker, initInstallButton, promptInstall } from './pwa.js';
import { VIDEO_CONTROLS_HIDE_MS, EPG_TICK_INIT_DELAY_MS, EPG_TICK_INTERVAL_MS, CHANNEL_SWIPE_MIN_X_PX, CHANNEL_SWIPE_MAX_Y_PX, VJ_GESTURE_MIN_Y_PX, VJ_GESTURE_FULL_RANGE_PX, BRIGHTNESS_MIN, BRIGHTNESS_MAX } from './constants.js';

// Регистрируем хендлеры воркера здесь, чтобы разорвать циклические зависимости
onWorkerEvent('m3u_done', onM3UParsed);
onWorkerEvent('epg_chunk', onEPGChunk);
onWorkerEvent('epg_done', onEPGParsed);
onWorkerEvent('status', (msg, type) => showStatus(msg, type));

window.__appModules = {
  loadSettings, renderSavedPlaylists, _resetDrawerTimer,
  playStream, _vcHideTimer: null,
  isFavourite, channelItemHtml,
  vsInvalidateRowHeight, _vsRenderExport,
  startEPGPlayerTick,
  refreshChannelListForTagFilter,
};

window.openDrawer = openDrawer;
window.closeDrawer = closeDrawer;
window.drawerOpenGroup = drawerOpenGroup;
window.drawerClearSearch = drawerClearSearch;
window.openEPGDrawer = openEPGDrawer;
window.closeEPGDrawer = closeEPGDrawer;
window.playStream = playStream;
window.loadSavedPlaylist = loadSavedPlaylist;
window.deleteSavedPlaylist = deleteSavedPlaylist;
window.clearAllData = clearAllData;
window.showAddPlaylistMenu = showAddPlaylistMenu;
window.hideAddPlaylistMenu = hideAddPlaylistMenu;
window.switchPlaylist = switchPlaylist;
window.handleEnterKey = handleEnterKey;
window.showSettings = showSettings;
window.hideSettings = hideSettings;
window.saveSettings = saveSettings;
window.toggleEPGUrlField = toggleEPGUrlField;
window.toggleFadeDurationField = toggleFadeDurationField;
window.loadEPG = loadEPG;
window.loadEPGFromFile = loadEPGFromFile;
window.epgScrollToDate = epgScrollToDate;
window.getChannelEPGKey = getChannelEPGKey;
window.navigateChannel = navigateChannel;
window.toggleHotkeyHelp = toggleHotkeyHelp;
window.toggleFullscreen = toggleFullscreen;
window.toggleCast = toggleCast;
window.exportDataToFile = exportDataToFile;
window.importDataFromFile = importDataFromFile;
window.triggerImportPicker = triggerImportPicker;
window.promptInstall = promptInstall;
registerServiceWorker();
window.vcToggleFav = () => {
  const btn = document.getElementById('vcFavBtn');
  if (!btn?.dataset.favUrl) return;
  const isNow = toggleFavourite(btn.dataset.favUrl);
  showStatus(isNow ? '⭐ Добавлено в избранное' : '✕ Убрано из избранного', 'info');
};
window.toggleMute = toggleMute;
window.seekVideo = seekVideo;
window.changeVolume = changeVolume;
window.vcTogglePlay = vcTogglePlay;
window.vcSetVolume = vcSetVolume;
window.cyclePlayMode = cyclePlayMode;
window.updatePlayModeButton = updatePlayModeButton;
window.startDemoMode = startDemoMode;
window.stopDemoMode = stopDemoMode;
window.toggleDemoMode = toggleDemoMode;
window.isDemoActive = isDemoActive;
window.setTvMode = setTvMode;
window.vcSeekClick = vcSeekClick;
window.vcTogglePlaybackRateMenu = vcTogglePlaybackRateMenu;
window.vcSetPlaybackRate = vcSetPlaybackRate;
window.renderChannels = renderChannels;
window.renderCategories = renderCategories;
window.refreshCurrentGroup = refreshCurrentGroup;
window.loadIntroURL = () => loadFromURL('urlInputIntro');
window.showHeaderMobile = showHeaderMobile;
window.toggleTagFilterPanel = toggleTagFilterPanel;
window.closeTagPopover = closeTagPopover;
window.clearTagFilter = clearTagFilter;
window.addTagGroupFromUI = addTagGroupFromUI;

function showAddPlaylistMenu() {
  document.getElementById('introOverlay').classList.remove('hidden');
  document.getElementById('mainContent').classList.add('blurred');
}

function hideAddPlaylistMenu() {
  document.getElementById('introOverlay').classList.add('hidden');
  document.getElementById('mainContent').classList.remove('blurred');
}

function switchPlaylist(id) {
  if (id) { loadSavedPlaylist(id); document.getElementById('playlistSelector').value = ''; }
}

function handleEnterKey(event, fnName) {
  if (event.key === 'Enter') window[fnName]?.();
}

// Video controls: fullscreen icon update
document.addEventListener('fullscreenchange', () => {
  const inFS = !!document.fullscreenElement;
  applyFullscreenUI(inFS);
  const { showVideoControls } = window.__appModules || {};
  if (inFS) showVideoControls?.();
});

// Автоматический переход в полноэкранный режим при загрузке.
// Спецификация Fullscreen API требует "activation" пользователя — браузер молча
// отклонит requestFullscreen() при обычной загрузке страницы без клика. Поэтому:
//  1) пробуем сразу (сработает в редких случаях — PWA в standalone/fullscreen
//     display-режиме, повторный визит с уже выданным разрешением и т.п.);
//  2) если не сработало — переходим в fullscreen по самому первому взаимодействию
//     пользователя со страницей, каким бы оно ни было (клик/тап/нажатие клавиши).
function _tryAutoFullscreen() {
  if (document.fullscreenElement) return true;
  document.documentElement.requestFullscreen?.().catch(() => {});
  return false;
}
function _initAutoFullscreen() {
  _tryAutoFullscreen();
  const onFirstInteraction = () => {
    if (!document.fullscreenElement) document.documentElement.requestFullscreen?.().catch(() => {});
    document.removeEventListener('click', onFirstInteraction);
    document.removeEventListener('keydown', onFirstInteraction);
    document.removeEventListener('touchstart', onFirstInteraction);
  };
  document.addEventListener('click', onFirstInteraction, { once: true });
  document.addEventListener('keydown', onFirstInteraction, { once: true });
  document.addEventListener('touchstart', onFirstInteraction, { once: true });
}

let _vcHideTimer = null;

function showVideoControls() {
  const vc = document.getElementById('videoControls');
  if (!vc) return;
  vc.classList.add('visible');
  clearTimeout(_vcHideTimer);
  _vcHideTimer = setTimeout(() => vc.classList.remove('visible'), VIDEO_CONTROLS_HIDE_MS);
  window.__appModules._vcHideTimer = _vcHideTimer;
}

window.__appModules.showVideoControls = showVideoControls;
window.__appModules.hideAddPlaylistMenu = hideAddPlaylistMenu;

let _lastTap = 0, _lastTapX = 0;
// Были ли кнопки управления видны В МОМЕНТ касания (до того, как этот же тап их показал).
// Тап по изображению работает в два шага: первый только показывает панель управления,
// play/pause выполняется лишь повторным тапом, пока панель на экране.
let _tapControlsWereVisible = false;
// Время последнего касания — чтобы синтетический click-«эхо» тача (на гибридных устройствах
// с hover) не выполнил play/pause повторно поверх тачевого обработчика.
let _lastTouchAt = 0;

/** Видна ли панель управления видео сейчас: класс .visible (его ставит showVideoControls)
 *  либо реальная непрозрачность (на устройствах с hover панель показывается через main:hover).
 *  Класс проверяем первым — он выставляется мгновенно, а opacity ещё анимируется 0.25 с. */
function _videoControlsShown() {
  const vc = document.getElementById('videoControls');
  if (!vc) return false;
  return vc.classList.contains('visible') || parseFloat(getComputedStyle(vc).opacity) > 0.5;
}
let _singleTapTimer = null; // отложенный play/pause одиночного тапа — отменяется, если пришёл второй тап (двойной тап)
let _swipeStartY = 0, _swipeStartX = 0, _swipeActive = false;
// Жест яркость/громкость: null пока не определился, 'brightness' | 'volume' | 'horizontal' после определения направления
let _vGestureMode = null;
let _vGestureStartVal = 0; // яркость (доля) или громкость (0-100) на старте жеста

function _currentBrightness() {
  const v = document.getElementById('video');
  const m = /brightness\(([\d.]+)\)/.exec(v.style.filter || '');
  return m ? parseFloat(m[1]) : 1;
}

function _setBrightness(val) {
  const v = document.getElementById('video');
  const clamped = Math.max(BRIGHTNESS_MIN, Math.min(BRIGHTNESS_MAX, val));
  v.style.filter = `brightness(${clamped})`;
  showStatus(`💡 Яркость: ${Math.round((clamped - BRIGHTNESS_MIN) / (BRIGHTNESS_MAX - BRIGHTNESS_MIN) * 100)}%`, 'info');
}

document.getElementById('mainContent')?.addEventListener('touchstart', e => {
  if (e.target.closest('#videoControls,#navDrawer,#drawerOverlay,#epgDrawer')) return;
  const t = e.touches[0];
  _swipeStartY = t.clientY; _swipeStartX = t.clientX; _swipeActive = true;
  _vGestureMode = null;
  const now = Date.now();
  _lastTouchAt = now;
  // Запоминаем состояние панели ДО showVideoControls() ниже — иначе первый тап всегда видел бы её «уже показанной»
  _tapControlsWereVisible = _videoControlsShown();
  const isDoubleTap = now - _lastTap < 300 && Math.abs(t.clientX - _lastTapX) < 60;
  if (isDoubleTap) {
    // Второй тап пары: отменяем отложенный play/pause от первого тапа —
    // это двойной тап (перемотка/пустое действие), а не два одиночных подряд.
    clearTimeout(_singleTapTimer);
    const video = document.getElementById('video');
    if (video?.src && !state.isLiveStream) {
      const isRight = t.clientX > window.innerWidth / 2;
      const { seekStep = 10 } = loadSettings();
      seekVideo(isRight ? seekStep : -seekStep);
      showStatus(isRight ? `⏩ +${seekStep}с` : `⏪ −${seekStep}с`, 'info');
      showVideoControls();
    }
    _lastTap = 0; _swipeActive = false;
    return;
  }
  _lastTap = now; _lastTapX = t.clientX;
  showVideoControls();
  const h = document.getElementById('loader');
  if (h?.classList.contains('visible')) { h.classList.remove('visible'); }
  else showHeaderMobile();
}, { passive: true });

document.getElementById('mainContent')?.addEventListener('touchmove', e => {
  if (!_swipeActive) return;
  if (e.target.closest('#videoControls,#navDrawer,#drawerOverlay,#epgDrawer')) return;
  const t = e.touches[0];
  const dx = t.clientX - _swipeStartX;
  const dy = t.clientY - _swipeStartY;
  if (!_vGestureMode) {
    // Определяем направление жеста один раз, когда смещение станет заметным
    if (Math.abs(dy) < VJ_GESTURE_MIN_Y_PX && Math.abs(dx) < CHANNEL_SWIPE_MIN_X_PX) return;
    if (Math.abs(dy) > Math.abs(dx)) {
      // Вертикальный жест: левая половина — яркость, правая — громкость
      _vGestureMode = _swipeStartX < window.innerWidth / 2 ? 'brightness' : 'volume';
      _vGestureStartVal = _vGestureMode === 'brightness'
        ? _currentBrightness()
        : Math.round((document.getElementById('video').muted ? 0 : document.getElementById('video').volume) * 100);
    } else {
      _vGestureMode = 'horizontal';
    }
  }
  if (_vGestureMode === 'brightness') {
    const delta = -dy / VJ_GESTURE_FULL_RANGE_PX * (BRIGHTNESS_MAX - BRIGHTNESS_MIN);
    _setBrightness(_vGestureStartVal + delta);
  } else if (_vGestureMode === 'volume') {
    const delta = -dy / VJ_GESTURE_FULL_RANGE_PX * 100;
    vcSetVolume(Math.max(0, Math.min(100, Math.round(_vGestureStartVal + delta))));
  }
}, { passive: true });

document.getElementById('mainContent')?.addEventListener('touchend', e => {
  if (!_swipeActive) return;
  _swipeActive = false;
  if (e.target.closest('#videoControls,#navDrawer,#drawerOverlay,#epgDrawer')) return;
  if (_vGestureMode === 'brightness' || _vGestureMode === 'volume') { _vGestureMode = null; return; }
  const t = e.changedTouches[0];
  const dx = t.clientX - _swipeStartX;
  const dy = Math.abs(t.clientY - _swipeStartY);
  _vGestureMode = null;
  if (Math.abs(dx) < CHANNEL_SWIPE_MIN_X_PX || dy > CHANNEL_SWIPE_MAX_Y_PX) {
    // Ни жест смены канала, ни вертикальный жест яркости/громкости — похоже на
    // одиночный тап по пустому месту области воспроизведения. Откладываем
    // play/pause на длительность окна двойного тапа: если следующий touchstart
    // придёт как isDoubleTap, он отменит этот таймер (см. выше) — иначе два тапа
    // подряд (двойной тап) переключили бы play/pause дважды подряд.
    // Первый тап по скрытой панели управления только показывает её (см. touchstart) —
    // play/pause делает повторный тап, когда кнопки уже на экране.
    if (!isDemoActive() && _tapControlsWereVisible && Math.abs(dx) < VJ_GESTURE_MIN_Y_PX && dy < VJ_GESTURE_MIN_Y_PX) {
      clearTimeout(_singleTapTimer);
      _singleTapTimer = setTimeout(() => {
        // Перепроверяем на момент срабатывания: за эти 300мс пользователь мог
        // успеть открыть дровер/EPG или запустить демо каким-то другим путём —
        // тогда отложенный play/pause уже не должен применяться.
        if (isDemoActive()) return;
        if (document.getElementById('navDrawer')?.classList.contains('open')) return;
        if (document.getElementById('epgDrawer')?.classList.contains('open')) return;
        vcTogglePlay();
      }, 300);
    }
    return;
  }
  // Свайп вправо -> предыдущий канал, влево -> следующий
  navigateChannel(dx < 0 ? 1 : -1);
}, { passive: true });

document.body.addEventListener('mousemove', e => {
  if (e.clientY < 5) showPanel('loader');
  showVideoControls();
});

// Одиночный клик мышью по пустому месту области воспроизведения — play/pause.
// Не срабатывает на touch-устройствах: там play/pause уже встроен в touchend
// выше (обычный click там — синтетическое эхо тача, задвоило бы вызов).
// Не должен срабатывать по контролам, seekbar'у, дроверам/EPG-панели и служебным
// элементам поверх видео.
document.getElementById('mainContent')?.addEventListener('click', e => {
  if (isMobile() || isDemoActive()) return;
  // Эхо касания на гибридных устройствах (тач + hover): play/pause уже обработан в touchend
  if (Date.now() - _lastTouchAt < 800) return;
  if (e.target.closest('#videoControls,#navDrawer,#drawerOverlay,#epgDrawer,#leftEdge,#statusIndicator,#demoExitBtn,#demoNowPlaying')) return;
  vcTogglePlay();
});

document.getElementById('urlInputIntro')?.addEventListener('input', () => keepPanelVisible('loader'));
document.getElementById('urlInputIntro')?.addEventListener('blur', () => hidePanel('loader'));
window.addEventListener('resize', () => {
  // Не закрываем при ресайзе если открыта EPG (виртуальная клавиатура на мобайле и т.п.)
  if (document.getElementById('epgDrawer')?.classList.contains('open')) return;
  // Не закрываем, если ресайз вызван появлением экранной клавиатуры под полем ввода внутри дровера —
  // иначе на мобильном поле поиска само закрывается в момент фокуса (клавиатура сжимает viewport → resize)
  const active = document.activeElement;
  if (active && (active.tagName === 'INPUT' || active.tagName === 'TEXTAREA') && document.getElementById('navDrawer')?.contains(active)) return;
  closeDrawer();
});

// На мобильном подгоняем высоту дровера под реально видимую область (без учёта экранной клавиатуры),
// чтобы сфокусированное поле поиска не оказывалось перекрыто клавиатурой снизу.
if (window.visualViewport && isMobile()) {
  const _syncDrawerToVisualViewport = () => {
    const drawer = document.getElementById('navDrawer');
    if (!drawer) return;
    const vv = window.visualViewport;
    const covered = window.innerHeight - vv.height; // высота, занятая клавиатурой
    if (covered > 60) {
      // Клавиатура открыта — ограничиваем высоту дровера видимой областью, чтобы поле ввода не пряталось
      drawer.style.maxHeight = `${vv.height - 8}px`;
    } else {
      drawer.style.maxHeight = '';
    }
  };
  window.visualViewport.addEventListener('resize', _syncDrawerToVisualViewport);
}

// File input
document.getElementById('fileInputIntro')?.addEventListener('change', e => {
  const file = e.target.files[0];
  if (!file) return;
  const reader = new FileReader();
  reader.onload = () => parseM3U(reader.result, '', file.name.replace(/\.[^/.]+$/, ''));
  reader.readAsText(file);
});

// Init
document.addEventListener('DOMContentLoaded', () => {
  renderSavedPlaylists();
  const s = loadSettings();
  applySettings(s);
  initVideoEvents();
  initDrawerEvents();
  initKeyboard();
  initTagPopoverEvents();
  initTagsManagerEvents();
  initTagSelectEvents();
  updatePlayModeButton();
  initTvNav();
  initCastLazy();
  initInstallButton();
  _initAutoFullscreen();
  setTimeout(() => { tickEPGProgressBars(); setInterval(tickEPGProgressBars, EPG_TICK_INTERVAL_MS); }, EPG_TICK_INIT_DELAY_MS);
  if (s.autoLoadPlaylist) {
    const playlists = playlistManager.getAll();
    if (playlists.length > 0) {
      // onM3UParsed will handle resuming the last channel after parsing
      loadSavedPlaylist(playlists[0].id);
    } else if (s.autoplay) {
      // No saved playlist — try resuming last channel directly
      const last = loadLastChannel();
      if (last) playStream(last.url, last.title);
    }
  } else if (s.autoplay) {
    const last = loadLastChannel();
    if (last) playStream(last.url, last.title);
  }
});
