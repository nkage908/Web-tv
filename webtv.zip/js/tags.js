// tags.js — теги каналов, объединённые в тематические группы (актёры, жанры, страна и т.д.).
//
// Хранение (localStorage, глобально, не привязано к конкретному плейлисту):
//   tagGroups:    [{ id, name, tags: [{ id, name }] }]  — сами группы и теги
//   channelTags:  { [url]: [tagId, tagId, ...] }        — привязка канала к тегам, по URL
// Привязка канал→теги хранится по URL (как избранное), поэтому переживает перезагрузку
// плейлиста и работает одинаково для любого плейлиста, содержащего этот же URL.
//
// Фильтр по тегам (state.activeTagFilter) — три независимых режима на каждый тег:
//   or  — канал проходит, если у него есть ХОТЯ БЫ ОДИН тег из набора «or» (внутри набора — ИЛИ)
//   and — канал проходит, только если у него есть ВСЕ теги из набора «and» (внутри набора — И)
//   not — канал не проходит, если у него есть ЛЮБОЙ тег из набора «not» (исключение)
// Наборы комбинируются через И: канал должен пройти каждый непустой набор одновременно.
//
// Групповое присвоение тегов: long-press / правый клик по каналу включает режим выделения
// (state.tagSelectMode + state.tagSelectedUrls), появляется плавающая панель действий,
// «Теги…» открывает тот же поповер в режиме bulk — применяется ко всем выбранным каналам.

import { state, escapeHtml, STORAGE_KEYS } from './state.js';
import { TAG_GROUPS_MAX_COUNT, TAGS_PER_GROUP_MAX_COUNT } from './constants.js';
import { showStatus } from './ui.js';

const GROUPS_KEY = STORAGE_KEYS.TAG_GROUPS;
const CHANNEL_TAGS_KEY = STORAGE_KEYS.CHANNEL_TAGS;
const LONG_PRESS_MS = 450;
const LONG_PRESS_MOVE_TOLERANCE_PX = 10;

// ─── Хранилище: группы тегов ──────────────────────────────────────────────────

export function getTagGroups() {
  try { return JSON.parse(localStorage.getItem(GROUPS_KEY) || '[]'); } catch { return []; }
}
function saveTagGroups(groups) {
  try { localStorage.setItem(GROUPS_KEY, JSON.stringify(groups)); return true; } catch (e) { console.error('Tags save:', e); return false; }
}

function _genId() {
  return `${Date.now().toString(36)}${Math.random().toString(36).slice(2, 8)}`;
}

export function findTagGroup(groupId) {
  return getTagGroups().find(g => g.id === groupId) || null;
}
export function findTag(tagId) {
  for (const g of getTagGroups()) {
    const t = g.tags.find(t => t.id === tagId);
    if (t) return { ...t, group: g };
  }
  return null;
}

export function addTagGroup(name) {
  const trimmed = (name || '').trim();
  if (!trimmed) return null;
  const groups = getTagGroups();
  if (groups.length >= TAG_GROUPS_MAX_COUNT) return null;
  if (groups.some(g => g.name.toLowerCase() === trimmed.toLowerCase())) return null;
  const group = { id: _genId(), name: trimmed, tags: [] };
  groups.push(group);
  saveTagGroups(groups);
  return group;
}

export function renameTagGroup(groupId, name) {
  const trimmed = (name || '').trim();
  if (!trimmed) return false;
  const groups = getTagGroups();
  const group = groups.find(g => g.id === groupId);
  if (!group) return false;
  group.name = trimmed;
  saveTagGroups(groups);
  return true;
}

/** Удаляет группу тегов вместе со всеми её тегами и отвязывает их от всех каналов. */
export function deleteTagGroup(groupId) {
  const groups = getTagGroups();
  const group = groups.find(g => g.id === groupId);
  if (!group) return false;
  const tagIds = new Set(group.tags.map(t => t.id));
  const next = groups.filter(g => g.id !== groupId);
  saveTagGroups(next);
  _removeTagIdsEverywhere(tagIds);
  return true;
}

export function addTag(groupId, name) {
  const trimmed = (name || '').trim();
  if (!trimmed) return null;
  const groups = getTagGroups();
  const group = groups.find(g => g.id === groupId);
  if (!group) return null;
  if (group.tags.length >= TAGS_PER_GROUP_MAX_COUNT) return null;
  if (group.tags.some(t => t.name.toLowerCase() === trimmed.toLowerCase())) return null;
  const tag = { id: _genId(), name: trimmed };
  group.tags.push(tag);
  saveTagGroups(groups);
  return tag;
}

export function renameTag(groupId, tagId, name) {
  const trimmed = (name || '').trim();
  if (!trimmed) return false;
  const groups = getTagGroups();
  const group = groups.find(g => g.id === groupId);
  const tag = group?.tags.find(t => t.id === tagId);
  if (!tag) return false;
  tag.name = trimmed;
  saveTagGroups(groups);
  return true;
}

/** Удаляет тег из группы и отвязывает его от всех каналов, которым он был назначен. */
export function deleteTag(groupId, tagId) {
  const groups = getTagGroups();
  const group = groups.find(g => g.id === groupId);
  if (!group) return false;
  const idx = group.tags.findIndex(t => t.id === tagId);
  if (idx < 0) return false;
  group.tags.splice(idx, 1);
  saveTagGroups(groups);
  _removeTagIdsEverywhere(new Set([tagId]));
  return true;
}

// ─── Хранилище: привязка канал → теги (по URL, глобально) ───────────────────

function getChannelTagsMap() {
  try { return JSON.parse(localStorage.getItem(CHANNEL_TAGS_KEY) || '{}'); } catch { return {}; }
}
function saveChannelTagsMap(map) {
  try { localStorage.setItem(CHANNEL_TAGS_KEY, JSON.stringify(map)); return true; } catch (e) { console.error('Channel tags save:', e); return false; }
}

// Кеш для чтения: вызывается на каждую строку списка и при фильтрации — ключ кеша сама сырая строка
let _ctRaw = null, _ctMap = {};
export function getChannelTagIds(url) {
  let raw;
  try { raw = localStorage.getItem(CHANNEL_TAGS_KEY) || '{}'; } catch { raw = '{}'; }
  if (raw !== _ctRaw) { _ctRaw = raw; _ctMap = getChannelTagsMap(); }
  return _ctMap[url] || [];
}

export function setChannelTagIds(url, tagIds) {
  const map = getChannelTagsMap();
  if (!tagIds || !tagIds.length) delete map[url];
  else map[url] = [...new Set(tagIds)];
  saveChannelTagsMap(map);
}

export function toggleChannelTag(url, tagId) {
  const map = getChannelTagsMap();
  const list = map[url] || [];
  const idx = list.indexOf(tagId);
  if (idx >= 0) list.splice(idx, 1);
  else list.push(tagId);
  if (list.length) map[url] = list;
  else delete map[url];
  saveChannelTagsMap(map);
  return idx < 0; // true если тег теперь назначен
}

/** Назначает/снимает тег сразу для набора каналов (групповое присвоение).
 *  mode: 'add' — добавить тег всем, 'remove' — снять тег у всех. */
export function bulkSetChannelTag(urls, tagId, mode) {
  const map = getChannelTagsMap();
  for (const url of urls) {
    const list = map[url] || [];
    const idx = list.indexOf(tagId);
    if (mode === 'add' && idx < 0) list.push(tagId);
    if (mode === 'remove' && idx >= 0) list.splice(idx, 1);
    if (list.length) map[url] = list; else delete map[url];
  }
  saveChannelTagsMap(map);
}

/** Возвращает количество каналов, которым назначен данный тег (учитывает только каналы,
 *  когда-либо встречавшиеся в channelTags — не завязано на текущий загруженный плейлист). */
export function getTagChannelCount(tagId) {
  const map = getChannelTagsMap();
  let n = 0;
  for (const url of Object.keys(map)) if (map[url].includes(tagId)) n++;
  return n;
}

/** Возвращает состояние тега относительно набора каналов: 'all' | 'some' | 'none'. */
function _bulkTagState(urls, tagId) {
  let assigned = 0;
  for (const url of urls) if (getChannelTagIds(url).includes(tagId)) assigned++;
  if (assigned === 0) return 'none';
  if (assigned === urls.length) return 'all';
  return 'some';
}

/** Удаляет указанные id тегов из всех привязок каналов (используется при удалении тега/группы). */
function _removeTagIdsEverywhere(tagIdSet) {
  const map = getChannelTagsMap();
  let changed = false;
  for (const url of Object.keys(map)) {
    const filtered = map[url].filter(id => !tagIdSet.has(id));
    if (filtered.length !== map[url].length) {
      changed = true;
      if (filtered.length) map[url] = filtered; else delete map[url];
    }
  }
  if (changed) saveChannelTagsMap(map);
  // Если сейчас активен фильтр по одному из удалённых тегов — снимаем его, чтобы список не «залип»,
  // и обновляем UI (кнопки фильтра/список каналов), если он уже успел отразить старый фильтр.
  const f = state.activeTagFilter;
  const hit = ['or', 'and', 'not'].some(k => f[k].some(id => tagIdSet.has(id)));
  if (hit) {
    setTagFilter({
      or: f.or.filter(id => !tagIdSet.has(id)),
      and: f.and.filter(id => !tagIdSet.has(id)),
      not: f.not.filter(id => !tagIdSet.has(id)),
    });
    _syncTagFilterButtons();
    window.__appModules?.refreshChannelListForTagFilter?.();
    if (_popoverMode === 'filter') document.getElementById('tagPopoverContent').innerHTML = tagFilterPanelHtml();
  }
}

// ─── Фильтр по тегам (state.activeTagFilter: {or, and, not}) ────────────────

export function setTagFilter(filter) {
  state.activeTagFilter = {
    or: [...new Set(filter?.or || [])],
    and: [...new Set(filter?.and || [])],
    not: [...new Set(filter?.not || [])],
  };
}

/** Возвращает текущий режим тега в фильтре: 'or' | 'and' | 'not' | null. */
export function getTagFilterMode(tagId) {
  const f = state.activeTagFilter;
  if (f.and.includes(tagId)) return 'and';
  if (f.not.includes(tagId)) return 'not';
  if (f.or.includes(tagId)) return 'or';
  return null;
}

/** Циклически переключает режим тега в фильтре: выкл → ИЛИ → И → НЕ → выкл. */
export function cycleTagFilterMode(tagId) {
  const f = state.activeTagFilter;
  const cur = getTagFilterMode(tagId);
  const next = { or: f.or.filter(id => id !== tagId), and: f.and.filter(id => id !== tagId), not: f.not.filter(id => id !== tagId) };
  const order = { null: 'or', or: 'and', and: 'not', not: null };
  const nextMode = order[cur === null ? 'null' : cur];
  if (nextMode) next[nextMode].push(tagId);
  setTagFilter(next);
  return nextMode;
}

export function isTagFilterActive() {
  const f = state.activeTagFilter;
  return f.or.length > 0 || f.and.length > 0 || f.not.length > 0;
}

function _filterCount() {
  const f = state.activeTagFilter;
  return f.or.length + f.and.length + f.not.length;
}

/** Канал проходит фильтр согласно правилам И/ИЛИ/НЕ (см. заголовок файла). */
export function channelMatchesTagFilter(url) {
  const f = state.activeTagFilter;
  if (!f.or.length && !f.and.length && !f.not.length) return true;
  const chTags = getChannelTagIds(url);
  if (f.not.length && f.not.some(id => chTags.includes(id))) return false;
  if (f.and.length && !f.and.every(id => chTags.includes(id))) return false;
  if (f.or.length && !f.or.some(id => chTags.includes(id))) return false;
  return true;
}

/** Применяет активный тег-фильтр к произвольному списку каналов. */
export function filterByTags(channels) {
  if (!isTagFilterActive()) return channels;
  return channels.filter(ch => channelMatchesTagFilter(ch.url));
}

// ─── HTML-фрагменты ────────────────────────────────────────────────────────

/** Небольшая кнопка-иконка тега для строки канала в списке — открывает поповер выбора тегов. */
export function tagButtonHtml(url) {
  const escUrl = url.replace(/"/g, '&quot;');
  const count = getChannelTagIds(url).length;
  return `<button class="tag-btn${count ? ' active' : ''}" data-tag-url="${escUrl}" title="Теги канала">`
    + `<svg width="12" height="12" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round"><path d="M20.59 13.41 11 3.83A2 2 0 0 0 9.59 3.24L4 3a1 1 0 0 0-1 1l.24 5.59a2 2 0 0 0 .59 1.41l9.58 9.59a2 2 0 0 0 2.83 0l4.35-4.35a2 2 0 0 0 0-2.83Z"/><circle cx="7.5" cy="7.5" r="1.2" fill="currentColor" stroke="none"/></svg>`
    + (count ? `<span class="tag-btn-count">${count}</span>` : '')
    + `</button>`;
}

/** Строит компактную сетку чипов групп тегов. renderChip(tag) возвращает HTML одного чипа.
 *  Каждая группа и чип помечены data-search атрибутом (имя в нижнем регистре) — по нему
 *  живой поиск в поповере скрывает/показывает элементы без перестройки DOM. */
function _tagGroupsGridHtml(groups, renderChip) {
  return groups.map(g => `
    <div class="tag-picker-group" data-search-group>
      <div class="tag-picker-group-name">${escapeHtml(g.name)}</div>
      ${g.tags.length
        ? `<div class="tag-picker-chips">${g.tags.map(renderChip).join('')}</div>`
        : `<div class="tag-picker-group-empty">Нет тегов</div>`}
    </div>`).join('');
}

/** Строка живого поиска по тегам — фильтрует чипы прямо в открытом поповере без его закрытия. */
function _tagSearchBarHtml(placeholder = 'Поиск тега…') {
  return `<div class="tag-search-bar">
    <svg width="13" height="13" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round"><circle cx="11" cy="11" r="8"/><line x1="21" y1="21" x2="16.65" y2="16.65"/></svg>
    <input type="text" class="tag-search-input" placeholder="${placeholder}" autocomplete="off">
    <button type="button" class="tag-search-clear hidden" title="Очистить поиск">✕</button>
  </div>`;
}

/** Блок быстрого создания тега прямо из поповера — без перехода в настройки.
 *  Если групп несколько, добавляется select для выбора целевой группы. */
function _tagQuickAddHtml() {
  const groups = getTagGroups();
  if (!groups.length) return '';
  const groupSelect = groups.length > 1
    ? `<select class="tag-quickadd-group" title="Группа">${groups.map(g => `<option value="${g.id}">${escapeHtml(g.name)}</option>`).join('')}</select>`
    : `<input type="hidden" class="tag-quickadd-group" value="${groups[0].id}">`;
  return `<div class="tag-quickadd-row">
    ${groupSelect}
    <input type="text" class="tag-quickadd-input" placeholder="Новый тег…" maxlength="60">
    <button type="button" class="tag-quickadd-btn" title="Создать тег">+</button>
  </div>`;
}

/** Содержимое поповера выбора тегов для ОДНОГО канала: компактная сетка с чекбоксами. */
export function tagPickerContentHtml(url) {
  const groups = getTagGroups();
  const assigned = new Set(getChannelTagIds(url));
  if (!groups.length) {
    return `<div class="tag-picker-empty">Тегов пока нет.<br>Создайте первый прямо здесь ↓</div>${_tagQuickAddHtml() || _tagQuickAddEmptyStateHtml()}`;
  }
  const search = groups.reduce((n, g) => n + g.tags.length, 0) > 6 ? _tagSearchBarHtml() : '';
  const grid = _tagGroupsGridHtml(groups, t => `
    <label class="tag-chip${assigned.has(t.id) ? ' checked' : ''}" data-search-chip="${escapeHtml(t.name.toLowerCase())}">
      <input type="checkbox" value="${t.id}" ${assigned.has(t.id) ? 'checked' : ''}>
      <span>${escapeHtml(t.name)}</span>
    </label>`);
  return search + grid + _tagQuickAddHtml();
}

/** Содержимое поповера ГРУППОВОГО присвоения тегов: чип показывает смешанное состояние
 *  (часть выбранных каналов имеет тег, часть — нет) штриховкой; клик циклит all→none. */
export function tagBulkPickerContentHtml(urls) {
  const groups = getTagGroups();
  if (!groups.length) {
    return `<div class="tag-picker-empty">Тегов пока нет.<br>Создайте первый прямо здесь ↓</div>${_tagQuickAddEmptyStateHtml()}`;
  }
  const header = `<div class="tag-bulk-hint">Клик по тегу — назначить всем выбранным, повторный клик — снять со всех.</div>`;
  const search = groups.reduce((n, g) => n + g.tags.length, 0) > 6 ? _tagSearchBarHtml() : '';
  const grid = _tagGroupsGridHtml(groups, t => {
    const st = _bulkTagState(urls, t.id);
    const cls = st === 'all' ? ' checked' : st === 'some' ? ' mixed' : '';
    const count = getTagChannelCount(t.id);
    return `<button type="button" class="tag-chip tag-chip-bulk${cls}" data-bulk-tag-id="${t.id}" data-search-chip="${escapeHtml(t.name.toLowerCase())}">${escapeHtml(t.name)}${count ? `<span class="tag-chip-count">${count}</span>` : ''}</button>`;
  });
  return header + search + grid + _tagQuickAddHtml();
}

/** Содержимое панели фильтрации списка по тегам — чип циклит режимы И/ИЛИ/НЕ (open) кликом. */
export function tagFilterPanelHtml() {
  const groups = getTagGroups();
  if (!groups.length) {
    return `<div class="tag-picker-empty">Тегов пока нет.<br>Создайте первый прямо здесь ↓</div>${_tagQuickAddEmptyStateHtml()}`;
  }
  const count = _filterCount();
  const clearBtn = `<button class="tag-filter-clear${count ? '' : ' tag-filter-clear-disabled'}" id="tagFilterClearBtn" ${count ? '' : 'disabled'}>Сбросить фильтр${count ? ` (${count})` : ''}</button>`;
  const legend = `<div class="tag-filter-legend">Клик по тегу переключает режим: <b class="tfl-or">ИЛИ</b> → <b class="tfl-and">И</b> → <b class="tfl-not">НЕ</b> → выкл</div>`;
  const search = groups.reduce((n, g) => n + g.tags.length, 0) > 6 ? _tagSearchBarHtml() : '';
  const groupsHtml = _tagGroupsGridHtml(groups, t => {
    const mode = getTagFilterMode(t.id);
    const cls = mode ? ` checked mode-${mode}` : '';
    const modeLabel = mode === 'and' ? 'И' : mode === 'not' ? 'НЕ' : mode === 'or' ? 'ИЛИ' : '';
    const cnt = getTagChannelCount(t.id);
    return `<button type="button" class="tag-chip tag-chip-filter${cls}" data-filter-tag-id="${t.id}" data-search-chip="${escapeHtml(t.name.toLowerCase())}">${modeLabel ? `<span class="tag-chip-mode">${modeLabel}</span>` : ''}${escapeHtml(t.name)}${cnt ? `<span class="tag-chip-count">${cnt}</span>` : ''}</button>`;
  });
  return clearBtn + legend + search + groupsHtml + _tagQuickAddHtml();
}

/** Мини-форма создания первой группы+тега, когда групп ещё вообще нет (пустое состояние). */
function _tagQuickAddEmptyStateHtml() {
  return `<div class="tag-quickadd-row tag-quickadd-first">
    <input type="text" class="tag-quickadd-group-name" placeholder="Группа (напр. Жанры)" maxlength="60">
    <input type="text" class="tag-quickadd-input" placeholder="Тег…" maxlength="60">
    <button type="button" class="tag-quickadd-btn" data-first-group="1" title="Создать">+</button>
  </div>`;
}

// ─── Поповер: интерактивное поведение (открытие/закрытие/позиционирование) ───

let _popoverMode = null; // 'channel' | 'filter' | 'bulk' | null
let _popoverChannelUrl = null;
let _popoverAnchor = null;

/** Позиционирует поповер рядом с якорем так, чтобы он всегда оставался в пределах
 *  экрана и никогда не перекрывал сам список каналов: на широких экранах уходит
 *  вбок от дровера (вправо, либо влево если справа не помещается), на узких —
 *  превращается в нижний лист (bottom sheet), прижатый к низу экрана. */
function _positionPopover(anchorEl) {
  const pop = document.getElementById('tagPopover');
  if (!pop || !anchorEl) return;

  const isNarrow = window.innerWidth < 720;
  if (isNarrow) {
    pop.classList.add('tag-popover-sheet');
    pop.style.left = '';
    pop.style.right = '';
    pop.style.top = '';
    pop.style.bottom = '';
    return;
  }
  pop.classList.remove('tag-popover-sheet');

  const rect = anchorEl.getBoundingClientRect();
  const drawer = document.getElementById('navDrawer');
  const drawerRect = drawer ? drawer.getBoundingClientRect() : null;
  const popWidth = 264;
  const margin = 10;

  // Предпочитаем разместить поповер СПРАВА от дровера (списка каналов), чтобы
  // никогда не перекрывать сам список. Если справа не хватает места — слева от дровера.
  let left;
  if (drawerRect && drawerRect.right + margin + popWidth <= window.innerWidth) {
    left = drawerRect.right + margin;
  } else if (drawerRect && drawerRect.left - margin - popWidth >= 0) {
    left = drawerRect.left - margin - popWidth;
  } else {
    // Дровер занимает весь экран (узкий десктоп/планшет) — прижимаем к краю окна,
    // противоположному от точки клика, и всё равно ограничиваем экраном.
    left = rect.left + rect.width / 2 < window.innerWidth / 2
      ? Math.min(window.innerWidth - popWidth - margin, rect.right + margin)
      : Math.max(margin, rect.left - popWidth - margin);
  }
  left = Math.max(margin, Math.min(left, window.innerWidth - popWidth - margin));

  const maxPopH = Math.round(window.innerHeight * 0.6);
  const spaceBelow = window.innerHeight - rect.top;
  const spaceAbove = rect.bottom;
  const openUpward = spaceBelow < maxPopH && spaceAbove > spaceBelow;

  pop.style.left = `${left}px`;
  if (openUpward) {
    pop.style.bottom = `${Math.max(margin, window.innerHeight - rect.bottom)}px`;
    pop.style.top = 'auto';
  } else {
    pop.style.top = `${Math.max(margin, rect.top)}px`;
    pop.style.bottom = 'auto';
  }
}

function _syncTagFilterButtons() {
  const active = isTagFilterActive();
  document.querySelectorAll('.drawer-tagfilter-btn').forEach(btn => btn.classList.toggle('active', active));
}

/** Открывает поповер выбора тегов для конкретного канала (кнопка в строке списка). */
export function openTagPopoverForChannel(url, anchorEl) {
  _popoverMode = 'channel';
  _popoverChannelUrl = url;
  _popoverAnchor = anchorEl;
  document.getElementById('tagPopoverTitle').textContent = 'Теги канала';
  document.getElementById('tagPopoverContent').innerHTML = tagPickerContentHtml(url);
  document.getElementById('tagPopover').classList.remove('hidden');
  _positionPopover(anchorEl);
}

/** Открывает поповер группового присвоения тегов для набора выделенных каналов. */
export function openTagPopoverForBulk(urls, anchorEl) {
  if (!urls.length) return;
  _popoverMode = 'bulk';
  _popoverChannelUrl = null;
  _popoverAnchor = anchorEl;
  document.getElementById('tagPopoverTitle').textContent = `Теги для ${urls.length} каналов`;
  document.getElementById('tagPopoverContent').innerHTML = tagBulkPickerContentHtml(urls);
  document.getElementById('tagPopover').classList.remove('hidden');
  _positionPopover(anchorEl);
}

/** Открывает/закрывает панель фильтрации списка по тегам (кнопка рядом с поиском). */
export function toggleTagFilterPanel(anchorEl) {
  const pop = document.getElementById('tagPopover');
  if (_popoverMode === 'filter' && !pop.classList.contains('hidden')) { closeTagPopover(); return; }
  _popoverMode = 'filter';
  _popoverChannelUrl = null;
  _popoverAnchor = anchorEl;
  document.getElementById('tagPopoverTitle').textContent = 'Фильтр по тегам';
  document.getElementById('tagPopoverContent').innerHTML = tagFilterPanelHtml();
  pop.classList.remove('hidden');
  _positionPopover(anchorEl);
}

export function closeTagPopover() {
  document.getElementById('tagPopover')?.classList.add('hidden');
  document.getElementById('tagPopover')?.classList.remove('tag-popover-sheet');
  _popoverMode = null;
  _popoverChannelUrl = null;
  _popoverAnchor = null;
}

/** Делегированный обработчик кликов/чекбоксов внутри поповера — вызывается один раз при инициализации. */
export function initTagPopoverEvents() {
  const pop = document.getElementById('tagPopover');
  if (!pop) return;

  // Клики/изменения внутри поповера никогда не должны всплывать до document —
  // иначе глобальный "клик вне поповера" (ниже) может закрыть его сразу после
  // выбора одного тега вместо того, чтобы остаться открытым для выбора нескольких.
  pop.addEventListener('mousedown', e => e.stopPropagation());
  pop.addEventListener('pointerdown', e => e.stopPropagation());

  pop.addEventListener('change', e => {
    const cb = e.target.closest('input[type="checkbox"]');
    if (!cb || _popoverMode !== 'channel' || !_popoverChannelUrl) return;
    e.stopPropagation();
    const tagId = cb.value;
    const nowAssigned = toggleChannelTag(_popoverChannelUrl, tagId);
    const chip = cb.closest('.tag-chip');
    chip?.classList.toggle('checked', nowAssigned);
    _pulseChip(chip);
    _refreshTagButton(_popoverChannelUrl);
  });

  pop.addEventListener('click', e => {
    e.stopPropagation();

    if (e.target.closest('#tagFilterClearBtn')) { clearTagFilter(); return; }

    const filterChip = e.target.closest('.tag-chip-filter');
    if (filterChip) {
      const mode = cycleTagFilterMode(filterChip.dataset.filterTagId);
      _syncTagFilterButtons();
      window.__appModules?.refreshChannelListForTagFilter?.();
      _updateFilterChipInPlace(filterChip, mode);
      _updateFilterClearButtonInPlace();
      _pulseChip(filterChip);
      return;
    }
    const bulkChip = e.target.closest('.tag-chip-bulk');
    if (bulkChip) {
      const tagId = bulkChip.dataset.bulkTagId;
      const urls = [...state.tagSelectedUrls];
      const st = _bulkTagState(urls, tagId);
      // all → снять со всех; none/some → назначить всем (доводит смешанное состояние до «всем есть»)
      bulkSetChannelTag(urls, tagId, st === 'all' ? 'remove' : 'add');
      _updateBulkChipInPlace(bulkChip, urls, tagId);
      urls.forEach(_refreshTagButton);
      window.__appModules?.refreshChannelListForTagFilter?.();
      return;
    }

    if (e.target.closest('.tag-search-clear')) {
      const input = pop.querySelector('.tag-search-input');
      if (input) { input.value = ''; _applyTagSearch(pop, ''); input.focus(); }
      return;
    }

    const quickAddBtn = e.target.closest('.tag-quickadd-btn');
    if (quickAddBtn) { _handleQuickAdd(quickAddBtn); return; }
  });

  // Живой поиск — фильтрует чипы по вводу без перестройки DOM и без закрытия поповера.
  pop.addEventListener('input', e => {
    if (e.target.classList.contains('tag-search-input')) {
      e.stopPropagation();
      _applyTagSearch(pop, e.target.value);
    }
  });

  pop.addEventListener('keydown', e => {
    e.stopPropagation();
    if (e.key !== 'Enter') return;
    if (e.target.classList.contains('tag-quickadd-input') || e.target.classList.contains('tag-quickadd-group-name')) {
      e.preventDefault();
      const btn = e.target.closest('.tag-quickadd-row')?.querySelector('.tag-quickadd-btn');
      if (btn) _handleQuickAdd(btn);
    }
  });

  document.addEventListener('click', e => {
    if (pop.classList.contains('hidden')) return;
    if (pop.contains(e.target)) return;
    if (e.target.closest('.tag-btn') || e.target.closest('.drawer-tagfilter-btn') || e.target.closest('.tag-select-action')) return;
    closeTagPopover();
  });
}

/** Живой поиск: скрывает чипы, не совпадающие с запросом, и группы, где не осталось видимых чипов.
 *  Ничего не перестраивает в DOM — только классы видимости, поэтому не сбрасывает скролл/фокус. */
function _applyTagSearch(pop, query) {
  const q = query.trim().toLowerCase();
  const clearBtn = pop.querySelector('.tag-search-clear');
  clearBtn?.classList.toggle('hidden', !q);
  pop.querySelectorAll('[data-search-group]').forEach(group => {
    let anyVisible = false;
    group.querySelectorAll('[data-search-chip]').forEach(chip => {
      const match = !q || chip.dataset.searchChip.includes(q);
      chip.classList.toggle('tag-search-hidden', !match);
      if (match) anyVisible = true;
    });
    group.classList.toggle('tag-search-hidden', !anyVisible);
  });
}

/** Обрабатывает клик по кнопке «+» быстрого создания тега (в т.ч. первой группы+тега сразу). */
function _handleQuickAdd(btn) {
  const row = btn.closest('.tag-quickadd-row');
  if (!row) return;

  // Пустое состояние: групп ещё нет — создаём группу и тег одним действием.
  if (btn.dataset.firstGroup) {
    const groupNameInput = row.querySelector('.tag-quickadd-group-name');
    const tagInput = row.querySelector('.tag-quickadd-input');
    const groupName = groupNameInput?.value.trim();
    const tagName = tagInput?.value.trim();
    if (!groupName) { groupNameInput?.focus(); return; }
    if (!tagName) { tagInput?.focus(); return; }
    const group = addTagGroup(groupName);
    if (!group) { showStatus?.('Группа с таким названием уже есть', 'info'); return; }
    const tag = addTag(group.id, tagName);
    if (!tag) { showStatus?.('Не удалось создать тег', 'info'); return; }
    _rebuildPopoverContentAfterTagCreated();
    return;
  }

  const groupSelect = row.querySelector('.tag-quickadd-group');
  const input = row.querySelector('.tag-quickadd-input');
  const groupId = groupSelect?.value;
  const name = input?.value.trim();
  if (!groupId || !name) { input?.focus(); return; }
  const tag = addTag(groupId, name);
  if (!tag) { showStatus?.('Такой тег уже есть в этой группе', 'info'); input?.focus(); return; }
  _rebuildPopoverContentAfterTagCreated();
}

/** После создания тега прямо из поповера — перерисовывает содержимое поповера в том же
 *  режиме (channel/bulk/filter), чтобы новый тег сразу появился в сетке и был готов к клику.
 *  Полная перерисовка здесь уместна: это редкое действие, а не повторный клик по чипу. */
function _rebuildPopoverContentAfterTagCreated() {
  const content = document.getElementById('tagPopoverContent');
  if (!content) return;
  if (_popoverMode === 'channel' && _popoverChannelUrl) content.innerHTML = tagPickerContentHtml(_popoverChannelUrl);
  else if (_popoverMode === 'bulk') content.innerHTML = tagBulkPickerContentHtml([...state.tagSelectedUrls]);
  else if (_popoverMode === 'filter') { content.innerHTML = tagFilterPanelHtml(); _syncTagFilterButtons(); }
  renderTagsSettingsTab(); // держим менеджер тегов в настройках синхронным, если он уже отрисован
}

/** Точечно обновляет один чип фильтра после смены режима — без перерисовки всей панели,
 *  чтобы не терять скролл-позицию и не мерцать при выборе нескольких тегов подряд. */
function _updateFilterChipInPlace(chip, mode) {
  chip.classList.remove('mode-or', 'mode-and', 'mode-not', 'checked');
  const modeEl = chip.querySelector('.tag-chip-mode');
  modeEl?.remove();
  if (mode) {
    chip.classList.add('checked', `mode-${mode}`);
    const label = mode === 'and' ? 'И' : mode === 'not' ? 'НЕ' : 'ИЛИ';
    chip.insertAdjacentHTML('afterbegin', `<span class="tag-chip-mode">${label}</span>`);
  }
}

function _updateFilterClearButtonInPlace() {
  const btn = document.getElementById('tagFilterClearBtn');
  if (!btn) return;
  const count = _filterCount();
  btn.textContent = `Сбросить фильтр${count ? ` (${count})` : ''}`;
  btn.disabled = !count;
  btn.classList.toggle('tag-filter-clear-disabled', !count);
}

function _updateBulkChipInPlace(chip, urls, tagId) {
  const st = _bulkTagState(urls, tagId);
  chip.classList.toggle('checked', st === 'all');
  chip.classList.toggle('mixed', st === 'some');
  _pulseChip(chip);
}

/** Короткая анимация отклика на чипе при клике — делает переключение заметнее и «живее». */
function _pulseChip(chip) {
  if (!chip) return;
  chip.classList.remove('tag-chip-pulse');
  // Форсируем reflow, чтобы анимация перезапускалась при повторных быстрых кликах
  void chip.offsetWidth;
  chip.classList.add('tag-chip-pulse');
  if (navigator.vibrate) navigator.vibrate(8);
}

function _refreshTagButton(url) {
  document.querySelectorAll(`.tag-btn[data-tag-url="${CSS.escape(url)}"]`).forEach(btn => {
    const count = getChannelTagIds(url).length;
    btn.classList.toggle('active', count > 0);
    const existingBadge = btn.querySelector('.tag-btn-count');
    if (count > 0) {
      if (existingBadge) existingBadge.textContent = String(count);
      else btn.insertAdjacentHTML('beforeend', `<span class="tag-btn-count">${count}</span>`);
    } else {
      existingBadge?.remove();
    }
  });
}

export function clearTagFilter() {
  setTagFilter({ or: [], and: [], not: [] });
  _syncTagFilterButtons();
  const { refreshChannelListForTagFilter } = window.__appModules || {};
  refreshChannelListForTagFilter?.();
  document.getElementById('tagPopoverContent').innerHTML = tagFilterPanelHtml();
}

// ─── Групповое выделение каналов (long-press / правый клик) ─────────────────

/** true, если сейчас активен режим множественного выделения. */
export function isTagSelectMode() {
  return state.tagSelectMode;
}

export function isChannelSelected(url) {
  return state.tagSelectedUrls.has(url);
}

function _renderSelectionBar() {
  let bar = document.getElementById('tagSelectBar');
  const count = state.tagSelectedUrls.size;
  if (!state.tagSelectMode) { bar?.remove(); return; }
  if (!bar) {
    bar = document.createElement('div');
    bar.id = 'tagSelectBar';
    bar.className = 'tag-select-bar';
    document.getElementById('navDrawer')?.appendChild(bar);
  }
  bar.innerHTML = `
    <span class="tag-select-count">Выбрано: ${count}</span>
    <button type="button" class="tag-select-action tag-select-action-primary" id="tagSelectApplyBtn" ${count ? '' : 'disabled'}>Присвоить теги…</button>
    <button type="button" class="tag-select-action" id="tagSelectCancelBtn">Отмена</button>`;
  document.getElementById('tagSelectApplyBtn')?.addEventListener('click', () => {
    if (!state.tagSelectedUrls.size) return;
    openTagPopoverForBulk([...state.tagSelectedUrls], bar.querySelector('#tagSelectApplyBtn'));
  });
  document.getElementById('tagSelectCancelBtn')?.addEventListener('click', exitTagSelectMode);
}

function _refreshChannelItemSelectionState(url) {
  document.querySelectorAll(`.channel-item[data-ch-url="${CSS.escape(url)}"]`).forEach(li => {
    li.classList.toggle('tag-selected', isChannelSelected(url));
  });
}

function _refreshAllChannelItemsSelectionClass() {
  document.querySelectorAll('.channel-item[data-ch-url]').forEach(li => {
    li.classList.toggle('tag-selected', isChannelSelected(li.dataset.chUrl));
    li.classList.toggle('tag-select-mode', state.tagSelectMode);
  });
}

export function enterTagSelectMode(initialUrl) {
  state.tagSelectMode = true;
  if (initialUrl) state.tagSelectedUrls.add(initialUrl);
  document.getElementById('navDrawer')?.classList.add('tag-select-mode');
  _refreshAllChannelItemsSelectionClass();
  _renderSelectionBar();
}

export function exitTagSelectMode() {
  state.tagSelectMode = false;
  state.tagSelectedUrls.clear();
  document.getElementById('navDrawer')?.classList.remove('tag-select-mode');
  _refreshAllChannelItemsSelectionClass();
  document.getElementById('tagSelectBar')?.remove();
  closeTagPopover();
}

export function toggleChannelSelection(url) {
  if (state.tagSelectedUrls.has(url)) state.tagSelectedUrls.delete(url);
  else state.tagSelectedUrls.add(url);
  _refreshChannelItemSelectionState(url);
  _renderSelectionBar();
  if (!state.tagSelectedUrls.size) {
    // Не выходим из режима автоматически — пользователь мог случайно снять последний чекбокс,
    // явный выход только через «Отмена», чтобы не терять режим по ошибке.
  }
}

/** Подключает long-press (touch) и правый клик (мышь) на строке канала для входа
 *  в режим выделения, плюс обычный клик по чекбоксу/строке внутри режима выделения.
 *  Вызывается один раз при инициализации дровера. */
export function initTagSelectEvents() {
  const drawer = document.getElementById('navDrawer');
  if (!drawer) return;

  let pressTimer = null;
  let pressStartXY = null;
  let pressUrl = null;

  const clearPress = () => { clearTimeout(pressTimer); pressTimer = null; pressStartXY = null; pressUrl = null; };

  drawer.addEventListener('contextmenu', e => {
    const li = e.target.closest('.channel-item[data-ch-url]');
    if (!li) return;
    e.preventDefault();
    if (!state.tagSelectMode) enterTagSelectMode(li.dataset.chUrl);
    else toggleChannelSelection(li.dataset.chUrl);
  });

  drawer.addEventListener('touchstart', e => {
    const li = e.target.closest('.channel-item[data-ch-url]');
    if (!li || e.touches.length !== 1) return;
    pressUrl = li.dataset.chUrl;
    pressStartXY = { x: e.touches[0].clientX, y: e.touches[0].clientY };
    pressTimer = setTimeout(() => {
      if (navigator.vibrate) navigator.vibrate(15);
      if (!state.tagSelectMode) enterTagSelectMode(pressUrl);
      else toggleChannelSelection(pressUrl);
      pressTimer = null;
    }, LONG_PRESS_MS);
  }, { passive: true });

  drawer.addEventListener('touchmove', e => {
    if (!pressTimer || !pressStartXY) return;
    const t = e.touches[0];
    const dx = Math.abs(t.clientX - pressStartXY.x);
    const dy = Math.abs(t.clientY - pressStartXY.y);
    if (dx > LONG_PRESS_MOVE_TOLERANCE_PX || dy > LONG_PRESS_MOVE_TOLERANCE_PX) clearPress();
  }, { passive: true });

  drawer.addEventListener('touchend', clearPress, { passive: true });
  drawer.addEventListener('touchcancel', clearPress, { passive: true });

  // Клик по строке/чекбоксу внутри режима выделения — переключает выбор вместо воспроизведения.
  // Обрабатывается с capture:true, чтобы сработать раньше основного click-обработчика дровера.
  drawer.addEventListener('click', e => {
    if (!state.tagSelectMode) return;
    const li = e.target.closest('.channel-item[data-ch-url]');
    if (!li) return;
    if (e.target.closest('.tag-btn') || e.target.closest('.fav-btn') || e.target.closest('.epg-channel-btn')) return;
    e.stopPropagation();
    e.preventDefault();
    toggleChannelSelection(li.dataset.chUrl);
  }, { capture: true });
}

// ─── Вкладка «Теги» в настройках: менеджер групп и тегов ─────────────────────

function _tagGroupCardHtml(group) {
  const escId = group.id.replace(/"/g, '&quot;');
  const tagsHtml = group.tags.length
    ? group.tags.map(t => `
        <span class="tag-manager-chip" data-tag-id="${t.id}">
          <span class="tag-manager-chip-name">${escapeHtml(t.name)}</span>
          <button class="tag-manager-chip-del" data-action="delete-tag" data-group-id="${escId}" data-tag-id="${t.id}" title="Удалить тег">✕</button>
        </span>`).join('')
    : `<span class="tag-manager-empty-hint">Пока нет тегов в этой группе</span>`;
  return `
    <div class="tag-manager-card" data-group-id="${escId}">
      <div class="tag-manager-card-header">
        <input type="text" class="tag-manager-group-name" data-action="rename-group" data-group-id="${escId}" value="${escapeHtml(group.name)}" maxlength="60">
        <button class="tag-manager-del-group" data-action="delete-group" data-group-id="${escId}" title="Удалить группу целиком">Удалить группу</button>
      </div>
      <div class="tag-manager-chips">${tagsHtml}</div>
      <div class="tag-manager-add-row">
        <input type="text" class="tag-manager-add-input" data-action="new-tag-input" data-group-id="${escId}" placeholder="Новый тег…" maxlength="60">
        <button class="tag-manager-add-btn" data-action="add-tag" data-group-id="${escId}">+</button>
      </div>
    </div>`;
}

export function renderTagsSettingsTab() {
  const container = document.getElementById('tagsManagerContent');
  if (!container) return;
  const groups = getTagGroups();
  container.innerHTML = groups.length
    ? groups.map(_tagGroupCardHtml).join('')
    : `<div class="tag-picker-empty">Групп пока нет — добавьте первую выше (например «Жанры» или «Страна»).</div>`;
}

function _addTagFromInput(groupId, inputEl) {
  const name = inputEl.value;
  if (!name.trim()) return;
  const tag = addTag(groupId, name);
  inputEl.value = '';
  if (tag) renderTagsSettingsTab();
  else showStatus?.('Такой тег уже есть в этой группе', 'info');
}

/** Инициализация делегированных обработчиков менеджера тегов — вызывается один раз. */
export function initTagsManagerEvents() {
  const container = document.getElementById('tagsManagerContent');
  if (!container) return;

  container.addEventListener('click', e => {
    const btn = e.target.closest('[data-action]');
    if (!btn) return;
    const { action, groupId, tagId } = btn.dataset;
    if (action === 'delete-group') {
      const group = findTagGroup(groupId);
      if (group && confirm(`Удалить группу «${group.name}» вместе со всеми её тегами? Теги будут сняты со всех каналов.`)) {
        deleteTagGroup(groupId);
        renderTagsSettingsTab();
      }
    } else if (action === 'delete-tag') {
      deleteTag(groupId, tagId);
      renderTagsSettingsTab();
    } else if (action === 'add-tag') {
      const input = container.querySelector(`.tag-manager-add-input[data-group-id="${CSS.escape(groupId)}"]`);
      if (input) _addTagFromInput(groupId, input);
    }
  });

  container.addEventListener('keydown', e => {
    if (e.key !== 'Enter') return;
    const newTagInput = e.target.closest('[data-action="new-tag-input"]');
    if (newTagInput) { e.preventDefault(); _addTagFromInput(newTagInput.dataset.groupId, newTagInput); return; }
    if (e.target.closest('[data-action="rename-group"]')) e.target.blur();
  });

  // Переименование группы — сохраняем по потере фокуса/Enter, не на каждое нажатие клавиши
  container.addEventListener('change', e => {
    const input = e.target.closest('[data-action="rename-group"]');
    if (!input) return;
    if (!renameTagGroup(input.dataset.groupId, input.value)) renderTagsSettingsTab(); // откат при пустом имени
  });
}

export function addTagGroupFromUI() {
  const input = document.getElementById('newTagGroupName');
  if (!input) return;
  const name = input.value;
  if (!name.trim()) return;
  const group = addTagGroup(name);
  input.value = '';
  if (group) renderTagsSettingsTab();
  else showStatus?.('Группа с таким названием уже есть', 'info');
}

document.addEventListener('keydown', e => {
  if (e.key === 'Enter' && e.target.id === 'newTagGroupName') { e.preventDefault(); addTagGroupFromUI(); }
  if (e.key === 'Escape' && state.tagSelectMode) exitTagSelectMode();
});
