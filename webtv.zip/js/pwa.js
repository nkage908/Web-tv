// ─── PWA: регистрация service worker + подсказка «Установить приложение» ───

import { showStatus } from './ui.js';

/** Регистрирует sw.js. Тихо не срабатывает там, где Service Worker недоступен
 *  (например, открытие index.html напрямую с диска по file:// — SW требует
 *  https:// или localhost) — это не ошибка PWA, а ограничение окружения. */
export function registerServiceWorker() {
  if (!('serviceWorker' in navigator)) return;
  window.addEventListener('load', () => {
    navigator.serviceWorker.register('./sw.js').then((reg) => {
      // Если во время текущей сессии подъехал новый sw.js (релиз статики) —
      // просто ставим его в очередь на активацию при следующем полном перезапуске
      // вкладки; принудительно не перезагружаем страницу, чтобы не оборвать
      // воспроизведение живого потока.
      reg.addEventListener('updatefound', () => {
        const installing = reg.installing;
        if (!installing) return;
        installing.addEventListener('statechange', () => {
          if (installing.state === 'installed' && navigator.serviceWorker.controller) {
            showStatus('Доступно обновление — применится при следующем запуске', 'info');
          }
        });
      });
    }).catch((err) => console.error('SW registration failed:', err));
  });
}

// ─── Кнопка «Установить приложение» ────────────────────────────────────────
// beforeinstallprompt — Chromium-специфичное событие (Chrome/Edge/Android);
// Safari/iOS не поддерживает программный промпт вообще — там установка только
// вручную через «Поделиться» → «На экран Домой», о чём и сообщаем таким пользователям.
let _deferredInstallPrompt = null;

window.addEventListener('beforeinstallprompt', (e) => {
  e.preventDefault();
  _deferredInstallPrompt = e;
  document.getElementById('hdrInstallBtn')?.classList.remove('hidden');
});

window.addEventListener('appinstalled', () => {
  _deferredInstallPrompt = null;
  document.getElementById('hdrInstallBtn')?.classList.add('hidden');
  showStatus('Приложение установлено', 'success');
});

function _isStandalone() {
  return window.matchMedia('(display-mode: standalone)').matches || window.navigator.standalone === true;
}

function _isIOS() {
  return /iPad|iPhone|iPod/.test(navigator.userAgent) && !window.MSStream;
}

export function initInstallButton() {
  const btn = document.getElementById('hdrInstallBtn');
  if (!btn || _isStandalone()) return; // уже установлено/открыто как приложение — кнопка не нужна
  if (_isIOS()) {
    // На iOS программного промпта нет — показываем кнопку сразу, по клику даём инструкцию
    btn.classList.remove('hidden');
  }
}

export function promptInstall() {
  if (_deferredInstallPrompt) {
    _deferredInstallPrompt.prompt();
    _deferredInstallPrompt.userChoice.finally(() => { _deferredInstallPrompt = null; });
    return;
  }
  if (_isIOS()) {
    showStatus('Установка: нажмите «Поделиться» → «На экран Домой»', 'info');
    return;
  }
  showStatus('Установка сейчас недоступна в этом браузере', 'info');
}
