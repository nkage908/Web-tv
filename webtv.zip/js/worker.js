// worker.js — Web Worker для парсинга M3U и EPG
// Работает в отдельном потоке, не блокирует UI

// --- Вспомогательные функции ---

// КОПИЯ логики из state.js (классический воркер не умеет импортировать модули) —
// при изменении правьте обе. Подробные комментарии см. в state.js.
const streamTypeRegex = {
  hls:        /\.(m3u8|ts)$|\/hls\/|\/playlist\.[a-z0-9]+$/i,
  dash:       /\.mpd$|\/dash\//i,
  progressive:/\.(mp4|m4v|webm|mkv|avi|mov|flv|ogv)$/i,
  mpegts:     /\/udp\/|\/rtp\/|:\d{4,5}\/udp/i
};

function detectStreamType(url){
  const {hls, dash, progressive, mpegts} = streamTypeRegex;
  const path = String(url||'').trim().split(/[?#|]/)[0];
  if(hls.test(path))        return 'hls';
  if(dash.test(path))       return 'dash';
  if(progressive.test(path)||progressive.test(String(url||'').trim()))return 'progressive';
  if(mpegts.test(path))     return 'mpegts';
  return 'auto';
}

function parseEPGDate(str){
  const m = str?.match(/^(\d{4})(\d{2})(\d{2})(\d{2})(\d{2})(\d{2})(?:\s*([+-]\d{4}))?$/);
  if(!m) return NaN;
  const [,Y,Mo,D,H,Mi,S,off] = m;
  const utcMs = Date.UTC(+Y, +Mo-1, +D, +H, +Mi, +S);
  if(off){
    const sign = off[0] === '-' ? -1 : 1;
    const hh   = parseInt(off.slice(1,3), 10);
    const mm   = parseInt(off.slice(3,5), 10);
    return utcMs - sign*(hh*60+mm)*60000;
  }
  return utcMs;
}

// --- Парсинг M3U ---
function doParseM3U(data){
  const channels   = [];
  const grouped    = {};
  let excludedCount = 0;
  let detectedEPG  = '';

  const lines = data.split('\n');
  if(lines[0]?.startsWith('#EXTM3U')){
    const m = lines[0].match(/url-tvg\s*=\s*"([^"]+)"|url-tvg\s*=\s*([^\s]+)/i);
    if(m) detectedEPG = m[1] || m[2] || '';
  }

  let currentGroup = 'Общее';
  let currentTitle = '';
  let currentTvgId = '';
  let currentLogo  = '';
  const total = lines.length;

  for(let i = 0; i < total; i++){
    // Прогресс каждые 5000 строк
    if(i > 0 && i % 5000 === 0){
      self.postMessage({ type:'m3u_progress', done:i, total });
    }
    const line = lines[i].trim();
    if(line.startsWith('#EXTINF')){
      const groupMatch  = line.match(/group-title="([^"]+)"/);
      const extGrpMatch = lines[i+1]?.startsWith('#EXTGRP:') ? lines[i+1].match(/#EXTGRP:(.*)/) : null;
      currentGroup = extGrpMatch ? extGrpMatch[1].trim() : (groupMatch ? groupMatch[1] : 'Общее');
      const titleMatch  = line.match(/,(.*)$/);
      currentTitle = titleMatch ? titleMatch[1].trim() : 'Без названия';
      const idMatch     = line.match(/tvg-id="([^"]+)"/i);
      currentTvgId = idMatch ? idMatch[1].trim() : '';
      const logoMatch   = line.match(/tvg-logo="([^"]+)"/i);
      currentLogo  = logoMatch ? logoMatch[1].trim() : '';
    } else if(line && !line.startsWith('#')){
      const streamType = detectStreamType(line);
      if(streamType === 'mpegts'){
        excludedCount++;
        continue;
      }
      const entry = { title:currentTitle, url:line, group:currentGroup, tvgId:currentTvgId, logo:currentLogo };
      channels.push(entry);
      if(!grouped[currentGroup]) grouped[currentGroup] = [];
      grouped[currentGroup].push(entry);
    }
  }

  self.postMessage({
    type: 'm3u_done',
    channels,
    grouped,
    detectedEPG,
    excludedCount
  });
}

function doParseEPGXml(text,skipPast){
  const now=Date.now();
  const epgData={};
  let total=0,skipped=0;
  const progRegex=/<programme\b([^>]*)>([\s\S]*?)<\/programme>/gi;
  const attrRegex=/(\w[\w-]*)="([^"]*)"/g;
  const titleRegex=/<title\b[^>]*>([\s\S]*?)<\/title>/i;
  const descRegex=/<desc\b[^>]*>([\s\S]*?)<\/desc>/i;
  let countApprox=0,pos=0;
  while((pos=text.indexOf('<programme',pos))!==-1){countApprox++;pos++;}
  const reportEvery=Math.max(1000,Math.floor(countApprox/20));
  let match;
  progRegex.lastIndex=0;
  while((match=progRegex.exec(text))!==null){
    total++;
    if(total%reportEvery===0)self.postMessage({type:'epg_progress',done:total,total:countApprox});
    const attrsStr=match[1],inner=match[2];
    const attrs={};
    let am;
    attrRegex.lastIndex=0;
    while((am=attrRegex.exec(attrsStr))!==null)attrs[am[1]]=am[2];
    const stopMs=parseEPGDate(attrs.stop);
    if(skipPast&&!isNaN(stopMs)&&stopMs<now){skipped++;continue;}
    const startMs=parseEPGDate(attrs.start);
    const channel=attrs.channel||'';
    const titleM=titleRegex.exec(inner);
    const descM=descRegex.exec(inner);
    const unescape=s=>s.replace(/&amp;/g,'&').replace(/&lt;/g,'<').replace(/&gt;/g,'>').replace(/&quot;/g,'"').replace(/&#39;/g,"'").trim();
    const title=titleM?unescape(titleM[1]):'';
    const desc=descM?unescape(descM[1]):'';
    if(!epgData[channel])epgData[channel]=[];
    epgData[channel].push({start:startMs,stop:stopMs,title,desc});
  }
  for(const ch of Object.keys(epgData))epgData[ch].sort((a,b)=>a.start-b.start);
  const channelKeys=Object.keys(epgData);
  const CHUNK=100;
  for(let i=0;i<channelKeys.length;i+=CHUNK){
    const chunk={};
    for(let j=i;j<Math.min(i+CHUNK,channelKeys.length);j++)chunk[channelKeys[j]]=epgData[channelKeys[j]];
    self.postMessage({type:'epg_chunk',epgData:chunk});
  }
  self.postMessage({type:'epg_done',total,skipped,channels:channelKeys.length});
}

// --- Распаковка gzip в воркере ---
async function decompressGzip(buffer) {
  if (typeof DecompressionStream !== 'undefined') {
    const ds = new DecompressionStream('gzip');
    const writer = ds.writable.getWriter();
    const reader = ds.readable.getReader();
    writer.write(new Uint8Array(buffer));
    writer.close();
    const chunks = [];
    while (true) {
      const { done, value } = await reader.read();
      if (done) break;
      chunks.push(value);
    }
    const totalLen = chunks.reduce((a, c) => a + c.length, 0);
    const merged = new Uint8Array(totalLen);
    let off = 0;
    for (const c of chunks) { merged.set(c, off); off += c.length; }
    return new TextDecoder('utf-8').decode(merged);
  }
  // Критический fallback: понятная ошибка вместо молчаливого краша
  throw new Error('Ваш браузер не поддерживает распаковку GZIP. Используйте формат XML или обновите браузер (Safari 16.4+).');
}

// --- Диспетчер сообщений ---
self.onmessage = async (e) => {
  const { type, payload } = e.data;

  try{
    if(type === 'parse_m3u'){
      doParseM3U(payload.text);

    } else if(type === 'parse_epg_text'){
      doParseEPGXml(payload.text, payload.skipPast);

    } else if(type === 'parse_epg_gz'){
      self.postMessage({ type:'epg_status', message:'🗜️ Распаковка архива...' });
      const text = await decompressGzip(payload.buffer);
      self.postMessage({ type:'epg_status', message:'⚙️ Парсинг XML...' });
      doParseEPGXml(text, payload.skipPast);

    } else {
      self.postMessage({ type:'error', message:`Неизвестный тип задачи: ${type}` });
    }
  } catch(err){
    self.postMessage({ type:'error', message: err.message });
  }
};
