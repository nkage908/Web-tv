let _worker=null;
const _handlers={};
export function onWorkerEvent(type,fn){_handlers[type]=fn;}
export function getWorker(){
  if(!_worker){
    _worker=new Worker(new URL('./worker.js',import.meta.url));
    _worker.onmessage=({data:msg})=>{
      switch(msg.type){
        case 'm3u_progress': _handlers['status']?.(`⚙️ Парсинг плейлиста: ${msg.done} / ${msg.total} строк...`,'loading'); break;
        case 'm3u_done':     _handlers['m3u_done']?.(msg); break;
        case 'epg_status':   _handlers['status']?.(msg.message,'loading'); break;
        case 'epg_progress': _handlers['status']?.(`⚙️ Обработка EPG: ${msg.done} / ${msg.total}...`,'loading'); break;
        case 'epg_chunk':    _handlers['epg_chunk']?.(msg); break;
        case 'epg_done':     _handlers['epg_done']?.(msg); break;
        case 'error':        _handlers['status']?.('❌ '+msg.message,'error'); break;
      }
    };
    _worker.onerror=e=>{console.error('Worker error:',e);_handlers['status']?.('❌ Ошибка воркера: '+e.message,'error');};
  }
  return _worker;
}
