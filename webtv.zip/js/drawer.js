import { state, escapeHtml, isMobile } from './state.js';
import { loadSettings } from './storage.js';
import { _scheduleHeaderHide } from './ui.js';
import { getCurrentEPG, hasEPGData, buildEPGContent, getChannelEPGKey } from './epg.js';
import { isFavourite, toggleFavourite, updateFavSection, toggleFavSection } from './favourites.js';
import { tagButtonHtml, filterByTags, isTagFilterActive, openTagPopoverForChannel, isTagSelectMode, isChannelSelected } from './tags.js';
import { focusFirstIn } from './tv-nav.js';
import {
  EPG_DRAWER_SCROLL_DELAY_MS, EPG_DRAWER_CLOSE_DELAY_MS,
  DRAWER_SWIPE_CLOSE_THRESHOLD_PX, DRAWER_SWIPE_MAX_PX,
  VS_THRESHOLD, VS_OVERSCAN, VS_ROW_HEIGHT_FALLBACK, VS_MAX_HEIGHT_VH,
} from './constants.js';

// ─── Virtual scroll state ────────────────────────────────────────────────────
// One VS instance per group (keyed by group name). Cleared when playlist reloads.
const _vsState = new Map(); // group → { rowHeight, scrollListener }


let _drawerHideTimer = null;
const _getDrawerTimeout = () => loadSettings().menuTimeout || 5000;

/** Каналы группы с учётом активного фильтра по тегам (state.activeTagFilter).
 *  Единая точка правды для всех мест рендера/навигации по списку категории —
 *  индексы virtual scroll считаются относительно ЭТОГО (отфильтрованного) массива. */
function _getGroupChannels(group) {
  return filterByTags(state.groupedChannels[group] || []);
}
export { _getGroupChannels };

export function _scheduleDrawerHide() {
  clearTimeout(_drawerHideTimer);
  _drawerHideTimer = setTimeout(closeDrawer, _getDrawerTimeout());
}

export function _resetDrawerTimer() {
  if (!document.getElementById('navDrawer').classList.contains('open')) return;
  // Не перезапускаем таймер если открыта EPG
  if (!document.getElementById('epgDrawer')?.classList.contains('open')) {
    _scheduleDrawerHide();
  }
  if (isMobile()) {
    document.getElementById('loader')?.classList.add('visible');
    _scheduleHeaderHide();
  }
}

export function openDrawer() {
  document.getElementById('navDrawer').classList.add('open');
  // Не показываем серый overlay если открыта EPG (там blur-оверлей видео)
  if (!document.getElementById('epgDrawer')?.classList.contains('open')) {
    document.getElementById('drawerOverlay').classList.add('show');
  }
  if (state.activeSearchQuery) {
    ['channelSearchDrawer', 'channelSearchDrawerResult'].forEach(id => {
      const el = document.getElementById(id);
      if (el) el.value = state.activeSearchQuery;
    });
    document.getElementById('navDrawer').classList.add('show-search');
  }
  // Не ставим авто-скрытие если открыта EPG
  if (!document.getElementById('epgDrawer')?.classList.contains('open')) {
    _scheduleDrawerHide();
  }
  syncActiveCategory();
  focusFirstIn(document.getElementById('drawerCategoriesContent'));
}

/** Called when EPG ticks change an item's height inside a VS list */
export function vsInvalidateRowHeight(group) {
  const vs = _vsState.get(group);
  if (vs) { vs.rowHeight = null; }
}

/** Re-render hook exposed for player.js via window.__appModules */
export function _vsRenderExport(group, listEl) {
  _vsMeasureRowHeight(group, listEl);
  _vsRender(group, listEl);
}

/** Called when a new playlist is loaded to clear cached row heights */
export function vsInvalidateCache() { _vsState.clear(); }

export function syncActiveCategory() {
  if (!state.currentGroup) return;
  const expandedItem = document.querySelector('.category-item.active');
  if (expandedItem?.dataset?.group === state.currentGroup) {
    // Group already open — scroll playing item into view
    const list = expandedItem.nextElementSibling;
    if (list?.dataset.vsEnabled) {
      const channels = _getGroupChannels(state.currentGroup);
      const idx = channels.findIndex(ch => ch.url === state.currentChannelUrl);
      if (idx >= 0) vsScrollToIndex(state.currentGroup, idx).then(li => li?.classList.contains('playing') || li?.click());
    } else {
      requestAnimationFrame(() => {
        const playing = list?.querySelector('.channel-item.playing');
        (playing || expandedItem).scrollIntoView({ block: 'nearest', behavior: 'smooth' });
      });
    }
    return;
  }
  drawerOpenGroup(state.currentGroup);
  requestAnimationFrame(() => {
    const activeItem = document.querySelector('.category-item.active');
    if (!activeItem) return;
    const list = activeItem.nextElementSibling;
    if (list?.dataset.vsEnabled) {
      const channels = _getGroupChannels(state.currentGroup);
      const idx = channels.findIndex(ch => ch.url === state.currentChannelUrl);
      if (idx >= 0) vsScrollToIndex(state.currentGroup, idx);
      else activeItem.scrollIntoView({ block: 'nearest', behavior: 'smooth' });
    } else {
      const playing = list?.querySelector('.channel-item.playing');
      (playing || activeItem).scrollIntoView({ block: 'nearest', behavior: 'smooth' });
    }
  });
}

export function closeDrawer() {
  clearTimeout(_drawerHideTimer);
  // Если открыта EPG — закрываем её вместе с навигатором
  const epgOpen = document.getElementById('epgDrawer')?.classList.contains('open');
  if (epgOpen) {
    closeEPGDrawer();
    return; // closeEPGDrawer сама закроет navDrawer
  }
  document.getElementById('navDrawer').classList.remove('open', 'show-search');
  document.getElementById('drawerOverlay').classList.remove('show');
}

// ─── Virtual scroll engine ───────────────────────────────────────────────────

/**
 * Returns the row height for a group. If already measured, returns cached value.
 * Otherwise returns the fallback. Call _vsMeasureRowHeight() after first render to refine.
 */
function _vsGetRowHeight(group) {
  return _vsState.get(group)?.rowHeight ?? VS_ROW_HEIGHT_FALLBACK;
}

/**
 * Measure the actual rendered height of the first item in a VS list and cache it.
 */
function _vsMeasureRowHeight(group, listEl) {
  const firstLi = listEl.querySelector('li.channel-item');
  if (!firstLi) return;
  const h = firstLi.getBoundingClientRect().height;
  if (h > 0) {
    const vs = _vsState.get(group) || {};
    vs.rowHeight = Math.ceil(h);
    _vsState.set(group, vs);
  }
}

/**
 * Render the visible window of items into the list.
 * The <ul> has position:relative and a fixed height (capped at VS_MAX_HEIGHT_VH * vh).
 * A spacer div at the bottom sets total scroll height.
 * Rendered <li>s are position:absolute with top = index * rowHeight.
 */
function _vsRender(group, listEl) {
  const channels = _getGroupChannels(group);
  const n = channels.length;
  if (!n) return;

  const rowH = _vsGetRowHeight(group);
  const totalH = n * rowH;
  const scrollTop = listEl.scrollTop;
  const viewH = listEl.clientHeight || Math.min(totalH, window.innerHeight * VS_MAX_HEIGHT_VH);

  const firstVis = Math.floor(scrollTop / rowH);
  const lastVis  = Math.ceil((scrollTop + viewH) / rowH);
  const start = Math.max(0, firstVis - VS_OVERSCAN);
  const end   = Math.min(n - 1, lastVis + VS_OVERSCAN);

  const settings = loadSettings();

  // Build new content: spacer + rendered slice
  // We reuse existing rendered <li>s that are still in range to avoid thrashing the DOM.
  // But for simplicity and correctness (EPG ticks mutate li content), we do a targeted
  // replace: remove items outside [start,end], insert items not yet rendered.
  const rendered = new Map(); // index → li
  listEl.querySelectorAll('li.channel-item[data-vs-index]').forEach(li => {
    const idx = parseInt(li.dataset.vsIndex, 10);
    if (idx >= start && idx <= end) {
      rendered.set(idx, li);
    } else {
      li.remove();
    }
  });

  // Ensure spacer exists and has correct height
  let spacer = listEl.querySelector('.vs-spacer');
  if (!spacer) {
    spacer = document.createElement('div');
    spacer.className = 'vs-spacer';
    listEl.appendChild(spacer);
  }
  spacer.style.height = totalH + 'px';

  // Insert missing items
  const fragment = document.createDocumentFragment();
  for (let i = start; i <= end; i++) {
    if (rendered.has(i)) {
      // Update position in case rowH was re-measured
      rendered.get(i).style.top = i * rowH + 'px';
      continue;
    }
    const li = _vsCreateItem(channels[i], i, rowH, settings);
    fragment.appendChild(li);
  }
  // Insert before spacer so spacer stays last
  listEl.insertBefore(fragment, spacer);
}

function _vsCreateItem(ch, index, rowH, settings) {
  const html = channelItemHtml(ch, settings);
  const tmp = document.createElement('ul');
  tmp.innerHTML = html;
  const li = tmp.firstElementChild;
  li.dataset.vsIndex = index;
  li.style.position = 'absolute';
  li.style.top = index * rowH + 'px';
  li.style.left = '0';
  li.style.right = '0';
  // Preserve playing state
  if (ch.url === state.currentChannelUrl) {
    li.classList.add('playing');
    if (state.currentChannelElement && !document.body.contains(state.currentChannelElement)) {
      state.currentChannelElement = li;
    }
  }
  return li;
}

/**
 * Attach scroll listener that drives virtual rendering. Stored so it can be removed on group close.
 */
function _vsAttach(group, listEl) {
  // Remove any previous listener for this group
  _vsDetach(group, listEl);
  const vs = _vsState.get(group) || {};
  vs.scrollListener = () => _vsRender(group, listEl);
  _vsState.set(group, vs);
  listEl.addEventListener('scroll', vs.scrollListener, { passive: true });
}

function _vsDetach(group, listEl) {
  const vs = _vsState.get(group);
  if (vs?.scrollListener) {
    listEl?.removeEventListener('scroll', vs.scrollListener);
    vs.scrollListener = null;
  }
}

/**
 * Scroll the VS list so that `index` is visible, then re-render.
 * Returns a Promise that resolves once scroll settles and DOM is updated.
 */
export function vsScrollToIndex(group, index) {
  const active = document.querySelector(`.category-item[data-group="${CSS.escape(group)}"]`);
  const listEl = active?.nextElementSibling;
  if (!listEl || !listEl.dataset.vsEnabled) return Promise.resolve(null);

  const rowH = _vsGetRowHeight(group);
  const n = _getGroupChannels(group).length;
  const clampedIdx = Math.max(0, Math.min(n - 1, index));
  const targetTop = clampedIdx * rowH;
  const viewH = listEl.clientHeight;

  // Centre the target row in the viewport
  listEl.scrollTop = Math.max(0, targetTop - viewH / 2 + rowH / 2);
  _vsRender(group, listEl);

  // Return the newly rendered li (may need rAF for DOM to update)
  return new Promise(resolve => requestAnimationFrame(() => {
    const li = listEl.querySelector(`li[data-vs-index="${clampedIdx}"]`);
    resolve(li);
  }));
}

// ─── Fill list (small: direct render; large: virtual scroll) ─────────────────

function _fillGroupList(group, listEl) {
  if (listEl.dataset.filled) return;
  const channels = _getGroupChannels(group);
  const settings = loadSettings();

  if (channels.length >= VS_THRESHOLD) {
    // Virtual scroll mode
    listEl.dataset.filled  = '1';
    listEl.dataset.vsEnabled = '1';

    const maxH = Math.floor(window.innerHeight * VS_MAX_HEIGHT_VH);
    const rowH  = _vsGetRowHeight(group);
    // Cap list height so it doesn't push the drawer to infinity
    listEl.style.maxHeight  = maxH + 'px';
    listEl.style.height     = maxH + 'px';
    listEl.style.overflowY  = 'auto';
    listEl.style.position   = 'relative';

    _vsAttach(group, listEl);
    _vsRender(group, listEl);

    // Measure real row height after first paint and re-render if it changed
    requestAnimationFrame(() => {
      const prevH = _vsGetRowHeight(group);
      _vsMeasureRowHeight(group, listEl);
      if (_vsGetRowHeight(group) !== prevH) _vsRender(group, listEl);
    });
  } else {
    // Standard mode: render all at once
    listEl.innerHTML = channels.map(ch => channelItemHtml(ch, settings)).join('');
    listEl.dataset.filled = '1';
  }
}
export function drawerOpenGroup(group) {
  if (!document.querySelector('.category-item')) return; // categories not yet rendered
  document.querySelectorAll('.category-item').forEach(el => {
    const isSame = el.dataset.group === group;
    const list = el.nextElementSibling;
    if (isSame) {
      const isOpen = el.classList.contains('active');
      el.classList.toggle('active', !isOpen);
      if (!isOpen) {
        _fillGroupList(group, list);
        if (list.dataset.vsEnabled) {
          // VS lists manage their own height; just reveal them
          list.style.maxHeight = list.style.height; // already set by _fillGroupList
        } else {
          list.style.maxHeight = list.scrollHeight + 'px';
        }
        state.currentGroup = group; _showPinnedHeader(group);
      } else {
        // Closing: detach VS listener if present
        if (list.dataset.vsEnabled) {
          _vsDetach(group, list);
          list.removeAttribute('data-vs-enabled');
          list.removeAttribute('data-filled');
          list.style.height = '';
          list.style.overflowY = '';
          list.style.position = '';
          list.innerHTML = '';
        }
        list.style.maxHeight = '0';
        state.currentGroup = null; _hidePinnedHeader();
      }
    } else {
      el.classList.remove('active');
      if (list?.classList.contains('category-channels')) {
        // Also clean up any VS state on other groups being collapsed
        const g = el.dataset.group;
        if (list.dataset.vsEnabled) {
          _vsDetach(g, list);
          list.removeAttribute('data-vs-enabled');
          list.removeAttribute('data-filled');
          list.style.height = '';
          list.style.overflowY = '';
          list.style.position = '';
          list.innerHTML = '';
        }
        list.style.maxHeight = '0';
      }
    }
  });
}

function _showPinnedHeader(group) {
  const title = document.getElementById('drawerCategoriesTitle');
  if (title) title.textContent = group;
}

function _hidePinnedHeader() {
  const title = document.getElementById('drawerCategoriesTitle');
  if (title) title.textContent = 'Группы';
}

export function drawerClearSearch() {
  state.activeSearchQuery = '';
  state.activeSearchList = [];
  ['channelSearchDrawer', 'channelSearchDrawerResult', 'channelSearch'].forEach(id => {
    const el = document.getElementById(id);
    if (el) el.value = '';
  });
  document.getElementById('navDrawer').classList.remove('show-search');
}

export function drawerSearch(value) {
  ['channelSearch', 'channelSearchDrawer', 'channelSearchDrawerResult'].forEach(id => {
    const el = document.getElementById(id);
    if (el && el !== document.activeElement) el.value = value;
  });
  state.activeSearchQuery = value.trim();
  if (!state.activeSearchQuery) {
    state.activeSearchList = [];
    document.getElementById('navDrawer').classList.remove('show-search');
    return;
  }
  const q = state.activeSearchQuery.toLowerCase();
  const byText = state.allChannels.filter(ch => ch.title.toLowerCase().includes(q));
  state.activeSearchList = filterByTags(byText);
  const settings = loadSettings();
  document.getElementById('drawerSearchContent').innerHTML =
    state.activeSearchList.length
      ? `<ul>${state.activeSearchList.map(ch => channelItemHtml(ch, settings)).join('')}</ul>`
      : `<div style="padding:24px 16px;color:var(--text2);text-align:center">Ничего не найдено</div>`;
  document.getElementById('navDrawer').classList.add('show-search');
}

/** Вызывается при изменении фильтра по тегам (панель фильтра, tags.js): обновляет
 *  счётчики и видимость категорий, перерисовывает открытую категорию и активный
 *  поиск, чтобы список каналов сразу отражал новый набор выбранных тегов. */
export function refreshChannelListForTagFilter() {
  const tagActive = isTagFilterActive();
  document.querySelectorAll('.category-item[data-group]').forEach(item => {
    const group = item.dataset.group;
    const count = _getGroupChannels(group).length;
    const countEl = item.querySelector('.category-count');
    if (countEl) countEl.textContent = count;
    const hide = tagActive && count === 0;
    item.style.display = hide ? 'none' : '';
    const list = item.nextElementSibling;
    if (list?.classList.contains('category-channels')) list.style.display = hide ? 'none' : '';
  });
  // Перерисовываем открытую категорию (сбрасываем VS-кеш, т.к. индексы/длина списка поменялись)
  if (state.currentGroup) {
    const activeItem = document.querySelector(`.category-item[data-group="${CSS.escape(state.currentGroup)}"]`);
    const list = activeItem?.nextElementSibling;
    if (list) {
      if (list.dataset.vsEnabled) {
        _vsDetach(state.currentGroup, list);
        delete list.dataset.vsEnabled;
      }
      list.removeAttribute('data-filled');
      list.innerHTML = '';
      _fillGroupList(state.currentGroup, list);
      list.style.maxHeight = list.dataset.vsEnabled ? list.style.height : list.scrollHeight + 'px';
    }
  }
  // Обновляем активный текстовый поиск, если он открыт — комбинация поиск+теги
  if (state.activeSearchQuery) drawerSearch(state.activeSearchQuery);
}

// Состояние до открытия EPG
let _navWasOpenBeforeEPG = false;
let _searchWasActiveBeforeEPG = false;
let _activeEPGTvgId = null; // tvgId канала, для которого открыта EPG

export function openEPGDrawer(tvgId, name) {
  const drawerEl = document.getElementById('epgDrawer');
  const nav = document.getElementById('navDrawer');
  const epgAlreadyOpen = drawerEl.classList.contains('open');

  // Запоминаем состояние до открытия EPG (только при первом открытии)
  if (!epgAlreadyOpen) {
    _navWasOpenBeforeEPG = nav.classList.contains('open');
    _searchWasActiveBeforeEPG = !!state.activeSearchQuery;
  }

  // UX 7: снимаем подсветку с предыдущего канала, ставим на новый
  if (_activeEPGTvgId !== null) {
    document.querySelector(`.epg-channel-btn[data-epg-id="${CSS.escape(_activeEPGTvgId)}"]`)
      ?.closest('.channel-item')?.classList.remove('epg-open-channel');
  }
  _activeEPGTvgId = tvgId;
  document.querySelector(`.epg-channel-btn[data-epg-id="${CSS.escape(tvgId)}"]`)
    ?.closest('.channel-item')?.classList.add('epg-open-channel');

  document.getElementById('epgDrawerTitle').textContent = name;
  document.getElementById('epgDrawerContent').innerHTML = buildEPGContent(tvgId, name);
  drawerEl.classList.remove('hidden');

  // Открываем navDrawer, отменяем авто-скрытие
  nav.classList.add('open');
  document.getElementById('drawerOverlay').classList.remove('show');
  clearTimeout(_drawerHideTimer);

  // Показываем blur-оверлей поверх видео
  document.getElementById('epgVideoBlur')?.classList.add('show');
  document.body.classList.add('epg-active');

  requestAnimationFrame(() => drawerEl.classList.add('open'));

  // Скролл к текущей программе
  const delay = epgAlreadyOpen ? 0 : EPG_DRAWER_SCROLL_DELAY_MS;
  setTimeout(
    () => document.getElementById('epgDrawerContent').querySelector('.epg-now')?.scrollIntoView({ block: 'center' }),
    delay
  );
}

export function closeEPGDrawer() {
  const el = document.getElementById('epgDrawer');
  el.classList.remove('open');

  // UX 7: снимаем подсветку канала
  if (_activeEPGTvgId !== null) {
    document.querySelector(`.epg-channel-btn[data-epg-id="${CSS.escape(_activeEPGTvgId)}"]`)
      ?.closest('.channel-item')?.classList.remove('epg-open-channel');
    _activeEPGTvgId = null;
  }

  // Скрываем blur-оверлей видео
  document.getElementById('epgVideoBlur')?.classList.remove('show');
  document.body.classList.remove('epg-active');

  const nav = document.getElementById('navDrawer');
  clearTimeout(_drawerHideTimer);

  if (_navWasOpenBeforeEPG) {
    // navDrawer был открыт до EPG — оставляем открытым
    // UX 6: восстанавливаем поиск если был активен
    if (_searchWasActiveBeforeEPG && state.activeSearchQuery) {
      nav.classList.add('show-search');
    }
    document.getElementById('drawerOverlay').classList.add('show');
    _scheduleDrawerHide();
  } else {
    // navDrawer открылся только из-за EPG — закрываем его
    nav.classList.remove('open', 'show-search');
    document.getElementById('drawerOverlay').classList.remove('show');
  }

  _navWasOpenBeforeEPG = false;
  _searchWasActiveBeforeEPG = false;
  setTimeout(() => el.classList.add('hidden'), EPG_DRAWER_CLOSE_DELAY_MS);
}

export const renderCategories = () => {
  const groups = Object.keys(state.groupedChannels);
  const favBlock = `<div id="favSection"></div>`;
  const tagActive = isTagFilterActive();
  document.getElementById('drawerCategoriesContent').innerHTML = favBlock + groups.map(group => {
    const count = _getGroupChannels(group).length;
    const escLabel = escapeHtml(group);
    // data-group must store the raw value so CSS.escape() selectors match it correctly.
    // Only escape quotes to avoid breaking the HTML attribute; other chars are safe as-is.
    const escAttr = group.replace(/"/g, '&quot;');
    const hiddenAttr = tagActive && count === 0 ? ' style="display:none"' : '';
    return `<div class="category-item" data-group="${escAttr}" tabindex="-1"${hiddenAttr}><span class="category-label">${escLabel}</span><span class="category-count">${count}</span><span class="category-arrow">›</span></div><ul class="category-channels" style="max-height:0"${hiddenAttr}></ul>`;
  }).join('');
  updateFavSection();
  if (state.currentGroup && state.groupedChannels[state.currentGroup]) {
    const active = document.querySelector(`.category-item[data-group="${CSS.escape(state.currentGroup)}"]`);
    if (active) {
      const l = active.nextElementSibling;
      if (l) {
        _fillGroupList(state.currentGroup, l);
        active.classList.add('active');
        // VS lists manage their own height; non-VS lists expand to scrollHeight
        l.style.maxHeight = l.dataset.vsEnabled ? l.style.height : l.scrollHeight + 'px';
      }
    }
    _showPinnedHeader(state.currentGroup);
  } else if (groups.length > 0) {
    state.currentGroup = groups[0];
  }
};

export const renderChannels = group => drawerOpenGroup(group);
export function refreshCurrentGroup(){
  if(!state.currentGroup)return;
  const active=document.querySelector(`.category-item[data-group="${CSS.escape(state.currentGroup)}"]`);
  if(!active)return;
  const list=active.nextElementSibling;
  if(!list?.classList.contains('category-channels'))return;
  if(list.dataset.vsEnabled){
    // Re-render the current window in-place (EPG data or fav state may have changed)
    _vsRender(state.currentGroup, list);
  }else{
    delete list.dataset.filled;
    _fillGroupList(state.currentGroup,list);
    list.style.maxHeight=list.scrollHeight+'px';
  }
}

export function channelItemHtml(ch, settings = null) {
  const s = settings || loadSettings();
  const nowProg = getCurrentEPG(ch.tvgId, ch.title, s);
  let progressBar = '';
  if (nowProg) {
    const startMs = nowProg.start instanceof Date ? nowProg.start.getTime() : nowProg.start;
    const stopMs = nowProg.stop instanceof Date ? nowProg.stop.getTime() : nowProg.stop;
    const pct = Math.min(100, Math.max(0, Math.round((Date.now() - startMs) / (stopMs - startMs) * 100)));
    const titleEsc2 = escapeHtml(nowProg.title);
    progressBar = `<div class="epg-progress-wrap" title="${titleEsc2}"><div class="epg-progress-bar" style="width:${pct}%"></div></div><div class="channel-current-program">${titleEsc2}</div>`;
  }
  const resolvedEpgKey = hasEPGData(ch, s) ? getChannelEPGKey(ch.tvgId || '', ch.title, s) : null;
  // data-* attributes used with CSS.escape() selectors must store raw values (only quotes escaped)
  const escEpgId = resolvedEpgKey ? resolvedEpgKey.replace(/"/g, '&quot;') : '';
  const escUrl = ch.url.replace(/"/g, '&quot;');
  const epgBtn = resolvedEpgKey
    ? `<button type="button" class="epg-channel-btn" data-epg-id="${escEpgId}" data-epg-name="${escapeHtml(ch.title)}">EPG</button>`
    : '';
  const initials = ch.title.replace(/[^a-zA-Zа-яёА-ЯЁ0-9]/g, '').slice(0, 2).toUpperCase() || '?';
  const logoHtml = ch.logo ? `<img class="ch-logo" src="${escapeHtml(ch.logo)}" alt="" loading="lazy" onerror="this.style.display='none';this.nextElementSibling.style.display='flex'">` : '';
  const avatarStyle = ch.logo ? 'display:none' : 'display:flex';
  const fav = isFavourite(ch.url);
  const favBtn = `<button class="fav-btn${fav ? ' active' : ''}" data-fav-url="${escUrl}" title="${fav ? 'Убрать из избранного' : 'Добавить в избранное'}"><svg width="13" height="13" viewBox="0 0 24 24" fill="${fav ? '#f59e0b' : 'none'}" stroke="${fav ? '#f59e0b' : 'currentColor'}" stroke-width="2" stroke-linecap="round" stroke-linejoin="round"><polygon points="12 2 15.09 8.26 22 9.27 17 14.14 18.18 21.02 12 17.77 5.82 21.02 7 14.14 2 9.27 8.91 8.26 12 2"/></svg></button>`;
  const tagBtn = tagButtonHtml(ch.url);
  const chIndex = s.showChannelNumbers ? state.allChannels.indexOf(ch) : -1;
  const numBadge = chIndex >= 0 ? `<span class="ch-number">${chIndex + 1}</span>` : '';
  const selectMode = isTagSelectMode();
  const selected = selectMode && isChannelSelected(ch.url);
  const selectBox = selectMode
    ? `<span class="ch-select-box${selected ? ' checked' : ''}"><svg width="11" height="11" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="3" stroke-linecap="round" stroke-linejoin="round"><polyline points="20 6 9 17 4 12"/></svg></span>`
    : '';
  const liClass = `channel-item${selectMode ? ' tag-select-mode' : ''}${selected ? ' tag-selected' : ''}`;
  return `<li class="${liClass}" data-ch-url="${escUrl}" tabindex="-1"><div class="channel-title-row">${selectBox}<div class="ch-logo-wrap">${logoHtml}<span class="ch-logo-fallback" style="${avatarStyle}">${initials}</span></div>${epgBtn}${numBadge}<span class="ch-name">${escapeHtml(ch.title)}</span>${tagBtn}${favBtn}</div>${progressBar}</li>`;
}

export function initDrawerEvents() {
  document.getElementById('drawerCategoriesContent')?.addEventListener('click', e => {
    const favItem = e.target.closest('.fav-section-item');
    if (favItem) { toggleFavSection(); return; }
    const item = e.target.closest('.category-item');
    if (item) drawerOpenGroup(item.dataset.group);
  });

  const drawer = document.getElementById('navDrawer');
  if (drawer) {
    drawer.addEventListener('click', e => {
      const epgBtn = e.target.closest('.epg-channel-btn');
      if (epgBtn) { e.stopPropagation(); openEPGDrawer(epgBtn.dataset.epgId, epgBtn.dataset.epgName); return; }

      const favBtn = e.target.closest('.fav-btn');
      if (favBtn) { e.stopPropagation(); toggleFavourite(favBtn.dataset.favUrl); return; }

      const tagBtn = e.target.closest('.tag-btn');
      if (tagBtn) { e.stopPropagation(); openTagPopoverForChannel(tagBtn.dataset.tagUrl, tagBtn); return; }

      const li = e.target.closest('.channel-item[data-ch-url]');
      if (li) {
        const { playStream } = window.__appModules || {};
        playStream?.(li.dataset.chUrl, li.querySelector('.ch-name')?.textContent || '', li);
      }
    });
  }

  document.getElementById('channelSearch')?.addEventListener('input', e => {
    if (e.target.value.trim()) openDrawer();
    syncSearch(e.target.value);
  });
  document.getElementById('channelSearchDrawer')?.addEventListener('input', e => syncSearch(e.target.value));
  document.getElementById('channelSearchDrawerResult')?.addEventListener('input', e => syncSearch(e.target.value));

  document.getElementById('leftEdge')?.addEventListener('mouseenter', openDrawer);

  // Activity inside the drawer (touch/click/scroll/input/focus — включая TV-навигацию) resets the auto-hide countdown,
  // but mouse *movement* inside must NOT restart it — that would fight the mouseenter guard.
  (['touchstart', 'touchmove', 'click', 'scroll', 'input', 'focusin']).forEach(evt => {
    drawer?.addEventListener(evt, _resetDrawerTimer, { passive: true, capture: true });
  });

  // While the pointer is over the drawer, suppress auto-hide entirely.
  // Resume the countdown only after the pointer leaves.
  drawer?.addEventListener('mouseenter', () => {
    if (!isMobile()) clearTimeout(_drawerHideTimer);
  });
  drawer?.addEventListener('mouseleave', () => {
    if (!isMobile() && !document.getElementById('epgDrawer')?.classList.contains('open')) {
      _scheduleDrawerHide();
    }
  });

  const handle = drawer?.querySelector('.drawer-drag-handle');
  if (handle) {
    let startY = 0;
    handle.addEventListener('touchstart', e => { startY = e.touches[0].clientY; }, { passive: true });
    handle.addEventListener('touchmove', e => {
      const dy = e.touches[0].clientY - startY;
      if (dy > 0) drawer.style.transform = `translateY(${Math.min(dy, DRAWER_SWIPE_MAX_PX)}px)`;
    }, { passive: true });
    handle.addEventListener('touchend', e => {
      const dy = e.changedTouches[0].clientY - startY;
      drawer.style.transform = '';
      if (dy > DRAWER_SWIPE_CLOSE_THRESHOLD_PX) closeDrawer();
    }, { passive: true });
  }

  document.getElementById('navDrawer')?.addEventListener('transitionend', () => {
    const open = document.getElementById('navDrawer').classList.contains('open');
    const vc = document.getElementById('videoControls');
    if (open) { const { _vcHideTimer } = window.__appModules || {}; clearTimeout(_vcHideTimer); vc?.classList.add('visible'); }
  });
}

function syncSearch(value) {
  ['channelSearch', 'channelSearchDrawer', 'channelSearchDrawerResult'].forEach(id => {
    const el = document.getElementById(id);
    if (el && el !== document.activeElement) el.value = value;
  });
  drawerSearch(value);
}
