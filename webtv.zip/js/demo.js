// demo.js — режим демонстрации: автоматическое переключение потоков в текущем
// установленном режиме воспроизведения (playMode), с проигрыванием только
// короткого отрезка каждого канала/ролика.
//
// Для «живых» потоков — проигрывается один отрезок фиксированной длительности
// (demoSegmentDuration, сек, задаётся в настройках), после чего плеер переходит
// к следующему шагу по правилам текущего playMode (см. player.js: resolvePlayModeAction).
//
// Для видеороликов (VOD с известной длительностью) — проигрывается заданное число
// фрагментов (demoFragmentsCount) из середины дорожки: средняя треть длительности
// делится на равные промежутки, и с каждой точки проигрывается отрезок той же
// длительности (demoSegmentDuration). Переход между фрагментами — с плавным
// fade out/in (см. _seekWithFade), а не мгновенным скачком.
//
// Правила playMode одинаковы во всех сценариях (ended/ручное переключение/демо):
// «Пауза» не меняет канал и завершает демонстрацию, «Зациклить ролик» не меняет
// канал и бесконечно повторяет показ фрагментов текущего ролика, остальные режимы
// переключают канал с учётом своих границ (категория/плейлист/рандом).
//
// Интерфейс плеера (шапка, панель управления) в этом режиме скрыт — виден только
// полупрозрачный элемент выхода из демонстрации и кратковременная подпись с
// названием (и номером, если включена нумерация) канала при каждом переключении.

import { state } from './state.js';
import { loadSettings } from './storage.js';
import { showStatus } from './ui.js';
import { closeDrawer, closeEPGDrawer } from './drawer.js';
import {
  playStream, getPlayMode, resolvePlayModeAction, restartCurrentVideo,
  setExternalPlaybackControl, fadeVolume, getChannelDisplayLabel, getUserVolume,
} from './player.js';
import {
  DEMO_PARAM_MIN, DEMO_PARAM_MAX,
  FADE_DURATION_MIN_MS, FADE_DURATION_MAX_MS, DEMO_NOW_PLAYING_VISIBLE_MS,
} from './constants.js';

let _active = false;
let _segmentTimer = null;
let _waitCleanup = null; // снимает временные обработчики ожидания метаданных, если демо прервали
let _runToken = 0; // инкрементируется при каждом стопе/рестарте, чтобы отменить «зависшие» асинхронные шаги
let _endedHandler = null; // текущий обработчик 'ended' видео, снимается при каждой смене шага
let _savedVolume = null; // громкость пользователя на момент последнего fade-перехода — для восстановления при резком выходе

export function isDemoActive() {
  return _active;
}

function _clampParam(value, fallback) {
  const n = Number(value);
  if (!Number.isFinite(n)) return fallback;
  return Math.min(DEMO_PARAM_MAX, Math.max(DEMO_PARAM_MIN, Math.round(n)));
}

/** Длительность показа каждого отрезка/фрагмента, сек — задаётся одним значением
 *  в настройках (1-10 сек), без рандомизации. */
function _segmentSeconds() {
  const s = loadSettings();
  return _clampParam(s.demoSegmentDuration, 3);
}

/** Число фрагментов, на которые делится средняя треть видеоролика (VOD), 1-10. */
function _fragmentCount() {
  const s = loadSettings();
  return _clampParam(s.demoFragmentsCount, 3);
}

/** Точки старта фрагментов внутри средней трети дорожки, поделённой на n равных промежутков. */
function _midThirdFragmentStarts(duration, n) {
  const midStart = duration / 3;
  const midEnd = (duration * 2) / 3;
  const span = Math.max(0, midEnd - midStart);
  if (n <= 1) return [midStart + span / 2];
  const step = span / n;
  return Array.from({ length: n }, (_, i) => midStart + step * i + step / 2);
}

function _setDemoUI(on) {
  document.body.classList.toggle('demo-mode', on);
  const btn = document.getElementById('demoExitBtn');
  if (btn) btn.classList.toggle('visible', on);
  if (!on) _hideDemoNowPlaying();
}

let _nowPlayingTimer = null;

/** Ненадолго показывает название (и номер, если включена нумерация) канала/ролика,
 *  на который переключилась демонстрация — в углу экрана поверх видео. */
function _showDemoNowPlaying(url, title) {
  const el = document.getElementById('demoNowPlaying');
  if (!el) return;
  el.textContent = getChannelDisplayLabel(url, title);
  el.classList.add('show');
  clearTimeout(_nowPlayingTimer);
  _nowPlayingTimer = setTimeout(() => el.classList.remove('show'), DEMO_NOW_PLAYING_VISIBLE_MS);
}

function _hideDemoNowPlaying() {
  clearTimeout(_nowPlayingTimer);
  _nowPlayingTimer = null;
  document.getElementById('demoNowPlaying')?.classList.remove('show');
}

/** Закрывает боковую панель каналов и EPG-панель, если они были открыты — в режиме
 *  демонстрации не должно оставаться видимых элементов интерфейса, кроме кнопки выхода.
 *  closeDrawer() сама закрывает EPG-панель, если она была открыта поверх навигатора. */
function _closeUiPanels() {
  if (document.getElementById('navDrawer')?.classList.contains('open')) closeDrawer();
  else if (document.getElementById('epgDrawer')?.classList.contains('open')) closeEPGDrawer();
  document.getElementById('hotkeyHelp')?.remove();
  document.getElementById('settingsOverlay')?.classList.add('hidden');
  window.__appModules?.hideAddPlaylistMenu?.();
}

function _clearSegmentTimer() {
  clearTimeout(_segmentTimer);
  _segmentTimer = null;
}

function _clearWait() {
  if (_waitCleanup) { _waitCleanup(); _waitCleanup = null; }
}

/** Длительность fade-перехода между фрагментами одного ролика — берётся из тех же
 *  настроек, что и обычный fade между каналами (fadeTransition/fadeDuration), чтобы
 *  анимация была визуально единообразной во всём приложении. Если fade выключен в
 *  настройках — переход между фрагментами происходит мгновенно, как раньше. */
function _fragmentFadeDurationMs() {
  const { fadeTransition = true, fadeDuration = 350 } = loadSettings();
  if (!fadeTransition) return 0;
  return Math.min(FADE_DURATION_MAX_MS, Math.max(FADE_DURATION_MIN_MS, fadeDuration));
}

/** Плавно переключает видео на новую позицию: fade-out (изображение и звук) → seek →
 *  дожидается кадра на новой позиции (событие 'seeked') → fade-in. Если fade отключён
 *  в настройках, эквивалентно мгновенному seek без анимации. */
function _seekWithFade(video, targetTime, token, onDone) {
  const dur = _fragmentFadeDurationMs();
  const targetVol = getUserVolume(video);
  _savedVolume = targetVol;
  const doSeek = () => {
    if (!_active || token !== _runToken) return;
    const onSeeked = () => {
      video.removeEventListener('seeked', onSeeked);
      clearTimeout(seekFallback);
      if (!_active || token !== _runToken) return;
      video.play?.().catch(() => {});
      if (dur > 0) {
        video.style.transition = `opacity ${dur}ms ease`;
        video.style.opacity = '1';
        fadeVolume(video, 0, targetVol, dur);
        // Не через onDone fade: смена громкости пользователем отменяет fade и его колбэк — демо бы встало
        setTimeout(() => { if (_active && token === _runToken) onDone(); }, dur);
      } else {
        video.style.opacity = '1';
        video.volume = targetVol;
        onDone();
      }
    };
    video.addEventListener('seeked', onSeeked);
    try { video.currentTime = targetTime; } catch { /* seek может кинуть до готовности медиа — игнорируем */ }
    // Некоторые потоки/форматы не эмитят 'seeked' надёжно — не подвисаем молча
    const seekFallback = setTimeout(onSeeked, 1200);
  };
  if (dur > 0) {
    video.style.transition = `opacity ${dur}ms ease`;
    video.style.opacity = '0';
    fadeVolume(video, video.volume, 0, dur);
    setTimeout(doSeek, dur); // doSeek сам проверяет _active/token
  } else {
    video.style.opacity = '0';
    video.volume = 0;
    doSeek();
  }
}

/** Продвигает демонстрацию к следующему шагу согласно правилам текущего playMode
 *  (см. player.js: resolvePlayModeAction) — то же самое действие, что происходит по
 *  завершении ролика или при ручном переключении, только выполняется автоматически:
 *   - 'Пауза'          → показанный отрезок был последним, демонстрация завершается
 *   - 'Зациклить ролик' → показ фрагментов текущего ролика запускается заново
 *   - остальные режимы  → переход на следующий/случайный канал по правилам режима
 */
function _advance(token) {
  if (!_active || token !== _runToken) return;
  const result = resolvePlayModeAction(1, getPlayMode());
  if (result.action === 'stop') {
    stopDemoMode();
    return;
  }
  if (result.action === 'restart') {
    restartCurrentVideo();
    _waitForPlaybackAndRun(token);
    return;
  }
  const next = result.channel;
  if (!next) { stopDemoMode(); showStatus('⏹ Демонстрация: нет каналов для показа', 'info'); return; }
  const el = document.querySelector(`li[data-ch-url="${CSS.escape(next.url)}"]`);
  if (el) el.click();
  else playStream(next.url, next.title, null);
  _showDemoNowPlaying(next.url, next.title);
  _waitForPlaybackAndRun(token);
}

/** Дожидается, пока видео определится (live/VOD, длительность), затем запускает показ отрезков. */
function _waitForPlaybackAndRun(token) {
  _clearWait();
  const video = document.getElementById('video');
  if (!video) return;

  let done = false;
  const finish = () => {
    if (done) return;
    done = true;
    video.removeEventListener('loadedmetadata', onMeta);
    video.removeEventListener('playing', onMeta);
    clearTimeout(fallbackTimer);
    _waitCleanup = null;
    if (!_active || token !== _runToken) return;
    _runSegmentsForCurrent(token);
  };
  const onMeta = () => finish();
  video.addEventListener('loadedmetadata', onMeta);
  video.addEventListener('playing', onMeta);
  // Страховка: если событие не пришло (ошибка потока, странный формат) — не подвисаем в демо навсегда
  const fallbackTimer = setTimeout(finish, 6000);
  _waitCleanup = () => {
    video.removeEventListener('loadedmetadata', onMeta);
    video.removeEventListener('playing', onMeta);
    clearTimeout(fallbackTimer);
  };
}

/** Решает: живой поток (один случайный отрезок) или VOD (1-3 фрагмента из середины). */
function _runSegmentsForCurrent(token) {
  if (!_active || token !== _runToken) return;
  const video = document.getElementById('video');
  if (!video) return;
  _clearEndedHandler(video);

  const isVod = !state.isLiveStream && video.duration && isFinite(video.duration) && video.duration > 0;
  if (!isVod) {
    _clearSegmentTimer();
    _segmentTimer = setTimeout(() => _advance(token), _segmentSeconds() * 1000);
    return;
  }

  const n = _fragmentCount();
  const starts = _midThirdFragmentStarts(video.duration, n);
  _playFragmentSequence(video, starts, token);
}

function _playFragmentSequence(video, starts, token, idx = 0) {
  if (!_active || token !== _runToken) return;
  if (idx >= starts.length) { _advance(token); return; }
  _clearEndedHandler(video);
  _clearSegmentTimer();
  const targetTime = Math.max(0, Math.min(video.duration - 0.1, starts[idx]));
  _seekWithFade(video, targetTime, token, () => {
    if (!_active || token !== _runToken) return;
    const goToNextFragment = () => {
      _clearSegmentTimer();
      _clearEndedHandler(video);
      _playFragmentSequence(video, starts, token, idx + 1);
    };
    // Ролик может закончиться раньше, чем истечёт таймер отрезка (короткий ролик или
    // seek близко к концу дорожки) — тогда штатное 'ended' сработает первым и должно
    // само продолжить показ, а не оставлять видео замершим на последнем кадре.
    _endedHandler = () => goToNextFragment();
    video.addEventListener('ended', _endedHandler);
    _segmentTimer = setTimeout(goToNextFragment, _segmentSeconds() * 1000);
  });
}

function _clearEndedHandler(video) {
  if (_endedHandler && video) video.removeEventListener('ended', _endedHandler);
  _endedHandler = null;
}

export function startDemoMode() {
  if (_active) return;
  if (!state.currentChannelUrl && !state.allChannels?.length) {
    showStatus('✕ Нет доступных каналов для демонстрации', 'error');
    return;
  }
  _active = true;
  _runToken++;
  setExternalPlaybackControl(true);
  _closeUiPanels();
  _setDemoUI(true);
  showStatus('▶ Демонстрация запущена', 'info');
  if (state.currentChannelUrl) {
    // Уже что-то играет — просто встраиваемся в текущее воспроизведение
    _showDemoNowPlaying(state.currentChannelUrl, state.currentChannelTitle);
    _waitForPlaybackAndRun(_runToken);
  } else {
    // Ничего не играет: должны стартовать первый канал, даже если активный playMode
    // ('Пауза'/'Зациклить ролик') в остальном не подразумевает переключения —
    // без этого демонстрации не с чего было бы начинать показ.
    const first = state.allChannels[0];
    if (!first) { stopDemoMode(); return; }
    const el = document.querySelector(`li[data-ch-url="${CSS.escape(first.url)}"]`);
    if (el) el.click();
    else playStream(first.url, first.title, null);
    _showDemoNowPlaying(first.url, first.title);
    _waitForPlaybackAndRun(_runToken);
  }
}

export function stopDemoMode() {
  if (!_active) return;
  _active = false;
  _runToken++;
  _clearSegmentTimer();
  _clearWait();
  const video = document.getElementById('video');
  _clearEndedHandler(video);
  // Если демо прервали посреди fade-перехода между фрагментами — гарантируем, что
  // видео и звук остаются видимыми/слышимыми, а не «зависают» на промежуточном значении.
  if (video) {
    video.style.transition = '';
    video.style.opacity = '1';
    if (_savedVolume !== null && !video.muted) video.volume = _savedVolume;
    _savedVolume = null;
  }
  setExternalPlaybackControl(false);
  _setDemoUI(false);
  showStatus('⏹ Демонстрация остановлена', 'info');
}

export function toggleDemoMode() {
  if (_active) stopDemoMode();
  else startDemoMode();
}
