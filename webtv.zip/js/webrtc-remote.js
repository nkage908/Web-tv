const RTC_ICE_SERVERS=[{urls:'stun:stun.l.google.com:19302'}];
const RTC_CONNECT_TIMEOUT_MS=4000;
let rtcPc=null,rtcTimeoutId=null,rtcActive=false,rtcSessionId=0,rtcModalOpen=false;
function rtcSend(msg){if(typeof ws!=='undefined'&&ws&&ws.readyState===1)ws.send(JSON.stringify(msg));}
function rtcHandleMessage(msg){
  if(msg.type==='webrtc_offer'&&rtcModalOpen)rtcAcceptOffer(msg.sdp);
  else if(msg.type==='webrtc_ice'&&rtcPc&&msg.candidate)rtcPc.addIceCandidate(msg.candidate).catch(()=>{});
  else if(msg.type==='webrtc_error')rtcFallback();
}
async function rtcAcceptOffer(sdp){
  const session=++rtcSessionId;
  rtcCloseConnection();
  rtcPc=new RTCPeerConnection({iceServers:RTC_ICE_SERVERS});
  rtcPc.onicecandidate=e=>{if(e.candidate)rtcSend({type:'webrtc_ice',candidate:e.candidate.toJSON()});};
  rtcPc.ontrack=e=>{
    if(session!==rtcSessionId)return;
    clearTimeout(rtcTimeoutId);
    rtcActive=true;
    mpStopStream();
    mpVideo.srcObject=e.streams[0];
    mpVideo.muted=true;
    mpStatus.textContent='';
    mpSetModeBadge('p2p');
    // По умолчанию браузер держит консервативный playout-буфер на приёме (обычно
    // ощутимо больше 1с) ради сглаживания сети — для локального p2p-соединения
    // это избыточно и даёт как раз ту самую стабильную задержку в 2-3 секунды.
    // Явно просим минимальный буфер там, где браузер это позволяет (Chromium).
    if(typeof e.receiver?.playoutDelayHint!=='undefined'){
      try{e.receiver.playoutDelayHint=0;}catch{/* не критично, если браузер не поддерживает */}
    }
    mpVideo.play().catch(()=>{mpStatus.textContent='Нажмите ▶ для воспроизведения';});
  };
  rtcPc.onconnectionstatechange=()=>{if(session===rtcSessionId&&['failed','disconnected','closed'].includes(rtcPc?.connectionState)&&rtcActive)rtcFallback();};
  await rtcPc.setRemoteDescription({type:'offer',sdp});
  if(session!==rtcSessionId)return;
  const answer=await rtcPc.createAnswer();
  if(session!==rtcSessionId)return;
  await rtcPc.setLocalDescription(answer);
  if(session!==rtcSessionId)return;
  rtcSend({type:'webrtc_answer',sdp:answer.sdp});
}
function rtcRequestStream(){
  rtcModalOpen=true;
  rtcActive=false;
  ++rtcSessionId;
  rtcSend({type:'webrtc_request'});
  clearTimeout(rtcTimeoutId);
  const session=rtcSessionId;
  rtcTimeoutId=setTimeout(()=>{if(session===rtcSessionId&&!rtcActive)rtcFallback();},RTC_CONNECT_TIMEOUT_MS);
}
function rtcFallback(){
  rtcCloseConnection();
  if(rtcModalOpen&&mpUrl===null&&currentUrl)mpStartStream(currentUrl);
}
function rtcCloseConnection(){
  clearTimeout(rtcTimeoutId);
  rtcActive=false;
  if(rtcPc){rtcPc.close();rtcPc=null;}
  if(mpVideo.srcObject){mpVideo.srcObject=null;}
}
function rtcTeardown(){
  rtcModalOpen=false;
  ++rtcSessionId;
  const wasActive=rtcActive||!!rtcPc;
  rtcCloseConnection();
  if(wasActive)rtcSend({type:'webrtc_stop'});
}
