const WS_PORT=8765;
// Глобальные имена ws / mpUrl / currentUrl / mpVideo / mpStatus / mpStopStream / mpStartStream /
// mpSetModeBadge используются webrtc-remote.js — не переименовывать.
let ws=null,channels=[],groups=[],favs=[],playlists=[],currentUrl=null,activeGroup='',isLive=true,seekStep=15,duration=0;
const $=id=>document.getElementById(id);
const pinScreen=$('pinScreen'),remoteScreen=$('remoteScreen'),pinInput=$('pinInput'),pinError=$('pinError');
const sideMenu=$('sideMenu'),sideOverlay=$('sideOverlay');
const numPanel=$('numPanel'),numOverlay=$('numOverlay'),numInput=$('numInput');
const plPanel=$('plPanel'),plOverlay=$('plOverlay');
const morePanel=$('morePanel'),moreOverlay=$('moreOverlay');
const mpOverlay=$('mpOverlay'),mpModal=$('mpModal'),mpVideo=$('mpVideo'),mpStatus=$('mpStatus');
let mpHls=null,mpUrl=null,mpDriftTimer=null;

// ─── Утилиты ─────────────────────────────────────────────────────────────────
/** Экранирование для innerHTML/атрибутов: названия каналов, группы и плейлисты приходят
 *  из M3U и могут содержать любую разметку — без этого это XSS в странице пульта. */
const esc=s=>String(s??'').replace(/[&<>"']/g,c=>({'&':'&amp;','<':'&lt;','>':'&gt;','"':'&quot;',"'":'&#39;'}[c]));
/** «м:сс», а от часа — «ч:мм:сс» */
function fmtTime(s){
  s=Math.floor(Number(s)||0);if(s<0)s=0;
  const h=Math.floor(s/3600),m=Math.floor(s%3600/60),r=String(s%60).padStart(2,'0');
  return h>0?`${h}:${String(m).padStart(2,'0')}:${r}`:`${m}:${r}`;
}
function fmtBlockTime(s){s=Math.floor(s||0);const h=Math.floor(s/3600),m=Math.ceil((s%3600)/60);return h>0?`${h} ч ${m} мин`:`${m} мин`;}
function vibrate(){navigator.vibrate?.(15);}
/** Широкий экран: список каналов — постоянная колонка справа, а не выдвижная панель (см. remote.css) */
const wideMq=window.matchMedia('(min-width:860px) and (min-height:560px)');
const isWide=()=>wideMq.matches;
const PLAY_MODE_LABELS={pause:'Пауза',loop_video:'Повтор',loop_group:'Группа',loop_playlist:'Плейлист',random_category:'Случ. группа',random_playlist:'Случайно'};
const PLAY_MODE_TITLES={pause:'Остановиться после ролика',loop_video:'Повторять текущий ролик',loop_group:'Повторять текущую группу',loop_playlist:'Повторять весь плейлист',random_category:'Случайный ролик из группы',random_playlist:'Случайный ролик из всего плейлиста'};

// ─── Соединение ──────────────────────────────────────────────────────────────
let reconnectTimer=null,reconnectAttempts=0,manualClose=false,tvOffline=false;
const MAX_RECONNECT=12;
function setConn(kind,text){
  const el=$('conn');
  el.classList.toggle('warn',kind==='warn');
  el.classList.toggle('bad',kind==='bad');
  $('connText').textContent=text;
}
function showBanner(text,withBtn=false){
  $('connBannerText').textContent=text;
  $('connBannerBtn').classList.toggle('hidden',!withBtn);
  $('connBanner').classList.remove('hidden');
}
function hideBanner(){$('connBanner').classList.add('hidden');}
function connect(pin){
  clearTimeout(reconnectTimer);
  if(ws){ws.onclose=ws.onmessage=ws.onerror=null;try{ws.close();}catch{}}
  manualClose=false;
  const proto=location.protocol==='https:'?'wss':'ws';
  const sock=ws=new WebSocket(`${proto}://${location.hostname}:${WS_PORT}`);
  sock.onopen=()=>sock.send(JSON.stringify({type:'hello',role:'remote',pin}));
  sock.onmessage=e=>{
    const msg=JSON.parse(e.data);
    if(msg.type==='joined'){
      localStorage.setItem('remote_pin',pin);
      reconnectAttempts=0;tvOffline=false;hideBanner();setConn('ok','ТВ подключён');
      showRemote();send({cmd:'get_channels'});
    }
    else if(msg.type==='error'){
      // Неверный PIN или блокировка — переподключаться бессмысленно
      manualClose=true;
      localStorage.removeItem('remote_pin');
      showPinScreen();
      pinError.textContent=msg.msg==='blocked'?`Слишком много попыток. Повторите через ${fmtBlockTime(msg.retry_after)}`:'Неверный PIN';
    }
    else if(msg.type==='state'){
      // ТВ вернулся (комната сохраняется, пока пульт в ней) — снимаем баннер и просим список
      if(tvOffline){tvOffline=false;hideBanner();setConn('ok','ТВ подключён');send({cmd:'get_channels'});}
      handleState(msg);
    }
    else if(msg.type==='tv_disconnected'){
      // Раньше выбрасывало на экран PIN. Теперь ждём: ТВ-страница обычно просто перезагружается
      tvOffline=true;setConn('bad','ТВ не в сети');
      showBanner('ТВ отключился. Ждём, пока он вернётся…',true);
    }
    else if(msg.type?.startsWith('webrtc_'))rtcHandleMessage(msg);
  };
  sock.onclose=()=>{
    if(sock!==ws||manualClose)return;
    if(remoteScreen.classList.contains('hidden')){return;}
    // Обрыв связи: пробуем вернуться с сохранённым PIN, не теряя экран пульта
    if(reconnectAttempts>=MAX_RECONNECT){showPinScreen();pinError.textContent='Соединение потеряно';return;}
    reconnectAttempts++;
    setConn('warn','Переподключение…');
    showBanner(`Связь потеряна. Переподключение (${reconnectAttempts}/${MAX_RECONNECT})…`,true);
    reconnectTimer=setTimeout(()=>connect(pin),Math.min(500*reconnectAttempts,5000));
  };
}
function disconnect(){
  manualClose=true;clearTimeout(reconnectTimer);
  if(ws){ws.onclose=null;try{ws.close();}catch{}}
  localStorage.removeItem('remote_pin');
  pinInput.value='';pinError.textContent='';
  showPinScreen();
}
function showRemote(){pinScreen.classList.add('hidden');remoteScreen.classList.remove('hidden');}
function showPinScreen(){
  clearTimeout(reconnectTimer);
  pinScreen.classList.remove('hidden');remoteScreen.classList.add('hidden');
  closeMenu();closeNumPanel();closePlaylists();closeMore();closeMiniPlayer();hideBanner();
  pinInput.focus();
}
function send(cmd){if(ws&&ws.readyState===1)ws.send(JSON.stringify({type:'cmd',...cmd}));}

// ─── Панели ──────────────────────────────────────────────────────────────────
function openMenu(){
  if(isWide()){$('chSearch').focus();return;}
  closeNumPanel();closePlaylists();closeMore();
  sideMenu.classList.add('open');sideOverlay.classList.remove('hidden');
  scrollActiveIntoView();
}
function closeMenu(){sideMenu.classList.remove('open');sideOverlay.classList.add('hidden');}
function openNumPanel(){closeMenu();closePlaylists();closeMore();numInput.value='';numPanel.classList.remove('hidden');numOverlay.classList.remove('hidden');numInput.focus();}
function closeNumPanel(){numPanel.classList.add('hidden');numOverlay.classList.add('hidden')}
function openPlaylists(){closeMenu();closeNumPanel();closeMore();renderPlaylists();plPanel.classList.add('open');plOverlay.classList.remove('hidden')}
function closePlaylists(){plPanel.classList.remove('open');plOverlay.classList.add('hidden')}
function openMore(){closeMenu();closeNumPanel();closePlaylists();morePanel.classList.add('open');moreOverlay.classList.remove('hidden');}
function closeMore(){morePanel.classList.remove('open');moreOverlay.classList.add('hidden');}
function anyOverlayOpen(){
  return !numPanel.classList.contains('hidden')||morePanel.classList.contains('open')||plPanel.classList.contains('open')||
    sideMenu.classList.contains('open')||!mpModal.classList.contains('hidden');
}
function closeAllOverlays(){closeMenu();closeNumPanel();closePlaylists();closeMore();closeMiniPlayer();}

// ─── Мини-плеер (превью) ─────────────────────────────────────────────────────
const mpModeBadge=$('mpModeBadge');
function mpSetModeBadge(mode){
  if(!mode){mpModeBadge.classList.add('hidden');mpModeBadge.textContent='';return;}
  mpModeBadge.classList.remove('hidden');
  mpModeBadge.className='mp-mode-badge '+mode;
  mpModeBadge.textContent=mode==='p2p'?'🔗 P2P':'📡 Прямой поток';
}
function openMiniPlayer(){
  if(!currentUrl){return;}
  closeMenu();closePlaylists();closeNumPanel();closeMore();
  $('mpTitle').textContent=$('nowPlaying').textContent;
  mpOverlay.classList.remove('hidden');mpModal.classList.remove('hidden');
  mpStatus.textContent='Подключение…';
  mpSetModeBadge(null);
  rtcRequestStream();
}
function closeMiniPlayer(){
  if(mpModal.classList.contains('hidden')&&mpOverlay.classList.contains('hidden'))return;
  mpOverlay.classList.add('hidden');mpModal.classList.add('hidden');
  rtcTeardown();
  mpStopStream();
  mpSetModeBadge(null);
}
function mpStopStream(){
  clearInterval(mpDriftTimer);mpDriftTimer=null;
  if(mpHls){mpHls.destroy();mpHls=null;}
  mpVideo.srcObject=null;
  mpVideo.removeAttribute('src');mpVideo.load();
  mpUrl=null;mpStatus.textContent='';
}
function mpStartStream(url){
  mpStopStream();
  mpUrl=url;
  mpStatus.textContent='Загрузка…';
  mpSetModeBadge('direct');
  mpVideo.muted=true;
  const startAt=isLive?0:(duration&&$('timelineFill').style.width?
    parseFloat($('timelineFill').style.width)/100*duration:0);
  const onReady=()=>{
    mpStatus.textContent='';
    if(startAt>0)mpVideo.currentTime=startAt;
    mpVideo.play().catch(()=>{mpStatus.textContent='Нажмите ▶ для воспроизведения';});
    if(!isLive)mpDriftTimer=setInterval(mpCheckDrift,4000);
  };
  if(url.includes('.m3u8')&&window.Hls&&Hls.isSupported()){
    mpHls=new Hls();
    mpHls.loadSource(url);
    mpHls.attachMedia(mpVideo);
    mpHls.on(Hls.Events.MANIFEST_PARSED,onReady);
    mpHls.on(Hls.Events.ERROR,(_,data)=>{if(data.fatal)mpStatus.textContent='Не удалось загрузить поток';});
  }else{
    mpVideo.src=url;
    mpVideo.addEventListener('loadedmetadata',onReady,{once:true});
    mpVideo.addEventListener('error',()=>{mpStatus.textContent='Не удалось загрузить поток';},{once:true});
  }
}
function mpCheckDrift(){
  if(isLive||!duration)return;
  const fillPct=parseFloat($('timelineFill').style.width)||0;
  const tvTime=fillPct/100*duration;
  if(Math.abs(mpVideo.currentTime-tvTime)>5)mpVideo.currentTime=tvTime;
}
const openCard=()=>openMiniPlayer();
$('channelCard').onclick=openCard;
$('channelCard').onkeydown=e=>{if(e.key==='Enter'||e.key===' '){e.preventDefault();e.stopPropagation();openCard();}};
$('mpCloseBtn').onclick=()=>{closeMiniPlayer();vibrate();};
mpOverlay.onclick=closeMiniPlayer;
$('mpPlayBtn').onclick=()=>{send({cmd:'play_pause'});vibrate();};
$('mpNextBtn').onclick=()=>{send(isLive?{cmd:'next'}:{cmd:'seek',val:seekStep});vibrate();};
$('mpPrevBtn').onclick=()=>{send(isLive?{cmd:'prev'}:{cmd:'seek',val:-seekStep});vibrate();};
$('mpMuteBtn').onclick=()=>{send({cmd:'mute'});vibrate();};
$('mpFullscreenBtn').onclick=()=>{
  const el=$('mpVideo');
  if(el.requestFullscreen)el.requestFullscreen().catch(()=>{});
  else if(el.webkitEnterFullscreen)el.webkitEnterFullscreen();
  vibrate();
};
function seekFromTrack(e){
  if(!duration)return;
  const rect=e.currentTarget.getBoundingClientRect();
  const pct=Math.max(0,Math.min(1,(e.clientX-rect.left)/rect.width));
  send({cmd:'seek_to',val:pct*duration});
  vibrate();
}
$('mpTimelineTrack').onclick=seekFromTrack;
$('timelineTrack').onclick=seekFromTrack;
const mpWrap=document.querySelector('.mp-video-wrap');
let _mpTouchX=0,_mpTouchY=0,_mpGestureMode=null,_mpVolStart=0,_mpLastTap=0;
const MP_GESTURE_MIN_PX=16,MP_GESTURE_FULL_RANGE_PX=200,MP_SWIPE_MIN_X=50,MP_SWIPE_MAX_Y=60;
mpWrap.addEventListener('touchstart',e=>{
  const t=e.touches[0];
  _mpTouchX=t.clientX;_mpTouchY=t.clientY;_mpGestureMode=null;
  const now=Date.now();
  if(now-_mpLastTap<300){
    if(!isLive){send({cmd:'seek',val:t.clientX>mpWrap.clientWidth/2?seekStep:-seekStep});vibrate();}
    _mpLastTap=0;return;
  }
  _mpLastTap=now;
},{passive:true});
mpWrap.addEventListener('touchmove',e=>{
  const t=e.touches[0];
  const dx=t.clientX-_mpTouchX,dy=t.clientY-_mpTouchY;
  if(!_mpGestureMode){
    if(Math.abs(dx)<MP_GESTURE_MIN_PX&&Math.abs(dy)<MP_GESTURE_MIN_PX)return;
    if(Math.abs(dy)>Math.abs(dx)){_mpGestureMode='volume';_mpVolStart=+$('volSlider').value;}
    else _mpGestureMode='horizontal';
  }
  if(_mpGestureMode==='volume'){
    const val=Math.max(0,Math.min(100,Math.round(_mpVolStart-dy/MP_GESTURE_FULL_RANGE_PX*100)));
    $('volSlider').value=val;
    send({cmd:'volume',val});
  }
},{passive:true});
mpWrap.addEventListener('touchend',e=>{
  if(_mpGestureMode==='volume'){_mpGestureMode=null;return;}
  if(_mpGestureMode==='horizontal'){
    const t=e.changedTouches[0];
    const dx=t.clientX-_mpTouchX,dy=Math.abs(t.clientY-_mpTouchY);
    _mpGestureMode=null;
    if(Math.abs(dx)<MP_SWIPE_MIN_X||dy>MP_SWIPE_MAX_Y)return;
    send(dx<0?{cmd:'next'}:{cmd:'prev'});
    vibrate();
  }
},{passive:true});
function mpSyncFromState(msg){
  $('mpPlayBtn').textContent=msg.paused?'▶':'⏸';
  $('mpMuteBtn').textContent=msg.muted?'🔈':'🔇';
  const row=$('mpTimelineRow');
  if(msg.isLive||!msg.duration){row.classList.add('hidden');return;}
  row.classList.remove('hidden');
  const pct=msg.currentTime/msg.duration*100;
  $('mpTimelineFill').style.width=`${pct}%`;
  $('mpTimeCur').textContent=fmtTime(msg.currentTime);
  $('mpTimeDur').textContent=fmtTime(msg.duration);
}

// ─── Состояние от ТВ ─────────────────────────────────────────────────────────
/** Список скоростей в селекте фиксирован; если ТВ играет с нестандартной — добавляем пункт, а не оставляем пустым */
function setRateSelect(rate){
  const sel=$('rateSelect');
  const v=String(rate);
  if(![...sel.options].some(o=>+o.value===+rate)){
    const o=document.createElement('option');o.value=v;o.textContent=`${+(+rate).toFixed(2)}×`;
    sel.appendChild(o);
  }
  const opt=[...sel.options].find(o=>+o.value===+rate);
  if(opt)sel.value=opt.value;
}
let _lastActiveUrl=null;
function handleState(msg){
  if(msg.kind==='channels'){channels=msg.channels;groups=msg.groups;favs=msg.favs;playlists=msg.playlists||[];renderTabs();renderChannels();}
  else if(msg.kind==='playback'){
    $('nowPlaying').textContent=msg.title||'—';
    const numEl=$('chNumber');
    if(msg.chNum){numEl.textContent=`№${msg.chNum}`;numEl.classList.remove('hidden');}else numEl.classList.add('hidden');
    $('chNumValue').textContent=msg.chNum?String(msg.chNum):'—';
    $('playBtn').textContent=msg.paused?'▶':'⏸';
    $('volSlider').value=msg.volume;
    $('volValue').textContent=msg.muted?'Выкл':`${msg.volume}%`;
    $('muteIcon').textContent=msg.muted||msg.volume===0?'🔇':(msg.volume<50?'🔉':'🔊');
    $('muteBtn').classList.toggle('active',!!msg.muted);
    setRateSelect(msg.rate);
    const fav=$('favBtn');
    fav.querySelector('.ti').textContent=msg.fav?'★':'☆';
    fav.classList.toggle('active',!!msg.fav);
    $('epgNow').textContent=msg.epgNow?`▶ ${msg.epgNow}`:'';
    $('epgNext').textContent=msg.epgNext?`далее: ${msg.epgNext}`:'';
    const logo=$('chLogo');
    if(msg.logo){logo.src=msg.logo;logo.classList.remove('hidden');}else logo.classList.add('hidden');
    isLive=msg.isLive;
    seekStep=msg.seekStep||15;
    $('prevBtn').textContent=isLive?'⏮':'⏪';
    $('nextBtn').textContent=isLive?'⏭':'⏩';
    $('prevBtn').title=isLive?'Предыдущий канал':`Назад на ${seekStep} с (←)`;
    $('nextBtn').title=isLive?'Следующий канал':`Вперёд на ${seekStep} с (→)`;
    const badge=$('liveBadge');
    badge.classList.toggle('hidden',!msg.url);
    badge.classList.toggle('vod',!isLive);
    badge.textContent=isLive?'● LIVE':'VOD';
    $('timelineRow').classList.toggle('hidden',isLive);
    if(!isLive){
      duration=msg.duration||0;
      const pct=duration?msg.currentTime/duration*100:0;
      $('timelineFill').style.width=`${pct}%`;
      $('timeCur').textContent=fmtTime(msg.currentTime);
      $('timeDur').textContent=fmtTime(duration);
    }
    $('playModeBtn').querySelector('.ti').textContent=msg.playModeIcon||'🔄';
    $('playModeLabel').textContent=PLAY_MODE_LABELS[msg.playMode]||'Режим';
    $('playModeBtn').title=`Режим: ${PLAY_MODE_TITLES[msg.playMode]||''} (нажмите, чтобы сменить)`;
    $('demoBtn').classList.toggle('active',!!msg.demoActive);
    if(!mpModal.classList.contains('hidden'))mpSyncFromState(msg);
    if(!mpModal.classList.contains('hidden')&&msg.url&&msg.url!==currentUrl&&!rtcActive){
      $('mpTitle').textContent=msg.title||'';
      mpStartStream(msg.url);
    }
    currentUrl=msg.url;
    if(msg.fav&&!favs.includes(msg.url))favs.push(msg.url);
    if(!msg.fav)favs=favs.filter(u=>u!==msg.url);
    highlightActive();
    // Канал сменился (в т.ч. с самого ТВ) — подсвечиваем и показываем его в видимом списке
    if(msg.url!==_lastActiveUrl){_lastActiveUrl=msg.url;if(isWide()||sideMenu.classList.contains('open'))scrollActiveIntoView();}
  }
}

// ─── Список каналов / группы / плейлисты ─────────────────────────────────────
function renderTabs(){
  const tabs=$('groupTabs');
  tabs.innerHTML=`<button class="tab${activeGroup===''?' active':''}" data-group="">Все</button>`+
    `<button class="tab${activeGroup==='__fav__'?' active':''}" data-group="__fav__">★ Избранное</button>`+
    groups.map(g=>`<button class="tab${activeGroup===g?' active':''}" data-group="${esc(g)}">${esc(g)}</button>`).join('');
  tabs.querySelectorAll('.tab').forEach(el=>el.onclick=()=>{activeGroup=el.dataset.group;renderTabs();renderChannels();});
}
function renderChannels(){
  const list=$('channelList');
  const q=$('chSearch').value.trim().toLowerCase();
  // Номер канала = позиция в общем плейлисте (как на ТВ и в select_number), а не в отфильтрованном списке
  let items=channels.map((c,i)=>({c,n:i+1}));
  if(activeGroup==='__fav__')items=items.filter(x=>favs.includes(x.c.url));
  else if(activeGroup)items=items.filter(x=>x.c.group===activeGroup);
  if(q)items=items.filter(x=>x.c.title.toLowerCase().includes(q)||String(x.n)===q);
  $('chCount').textContent=channels.length?`${items.length} / ${channels.length}`:'';
  if(!items.length){
    list.innerHTML=`<div class="empty">${channels.length?'Ничего не найдено':'Список каналов пуст — загрузите плейлист на ТВ'}</div>`;
    return;
  }
  list.innerHTML=items.map(({c,n})=>{
    const isFav=favs.includes(c.url);
    return `<div class="ch-item${c.url===currentUrl?' active':''}" data-url="${esc(c.url)}">`+
      `<span class="ch-n">${n}</span>`+
      (c.logo?`<img src="${esc(c.logo)}" alt="" loading="lazy">`:'')+
      `<span class="ch-name">${esc(c.title)}</span>`+
      `<span class="ch-star${isFav?' active':''}" data-fav="${esc(c.url)}" title="Избранное">${isFav?'★':'☆'}</span></div>`;
  }).join('');
  list.querySelectorAll('.ch-item').forEach(el=>el.onclick=e=>{
    if(e.target.dataset.fav)return;
    send({cmd:'select',url:el.dataset.url});vibrate();
  });
  list.querySelectorAll('.ch-star').forEach(el=>el.onclick=e=>{
    e.stopPropagation();
    const url=el.dataset.fav;
    send({cmd:'fav_toggle_url',url});
    if(favs.includes(url))favs=favs.filter(u=>u!==url);else favs.push(url);
    renderChannels();
    vibrate();
  });
}
function scrollActiveIntoView(){
  requestAnimationFrame(()=>$('channelList').querySelector('.ch-item.active')?.scrollIntoView({block:'nearest'}));
}
function renderPlaylists(){
  const list=$('playlistList');
  if(!playlists.length){list.innerHTML='<div class="empty">Нет сохранённых плейлистов</div>';return;}
  list.innerHTML=playlists.map(p=>`<div class="playlist-item" data-id="${esc(p.id)}">${esc(p.name)}</div>`).join('');
  list.querySelectorAll('.playlist-item[data-id]').forEach(el=>el.onclick=()=>{
    send({cmd:'playlist_switch',id:el.dataset.id});
    vibrate();closePlaylists();
  });
}
function highlightActive(){document.querySelectorAll('.ch-item').forEach(el=>el.classList.toggle('active',el.dataset.url===currentUrl));}

// ─── Полный экран пульта / установка ─────────────────────────────────────────
function toggleRcFullscreen(){
  if(document.fullscreenElement)document.exitFullscreen();
  else document.documentElement.requestFullscreen?.().catch(()=>{});
}
let _rcInstallPrompt=null;
const _rcIsStandalone=()=>window.matchMedia('(display-mode: standalone)').matches||window.navigator.standalone===true;
const _rcIsIOS=()=>/iPad|iPhone|iPod/.test(navigator.userAgent)&&!window.MSStream;
window.addEventListener('beforeinstallprompt',e=>{
  e.preventDefault();
  _rcInstallPrompt=e;
  $('rcInstallBtn').classList.remove('hidden');
});
window.addEventListener('appinstalled',()=>{
  _rcInstallPrompt=null;
  $('rcInstallBtn').classList.add('hidden');
});
if(!_rcIsStandalone()&&_rcIsIOS())$('rcInstallBtn').classList.remove('hidden');
function promptRcInstall(){
  if(_rcInstallPrompt){_rcInstallPrompt.prompt();_rcInstallPrompt.userChoice.finally(()=>{_rcInstallPrompt=null;});return;}
  if(_rcIsIOS()){closeMore();showBanner('Установка: «Поделиться» → «На экран Домой»');setTimeout(hideBanner,6000);}
}
if('serviceWorker'in navigator)navigator.serviceWorker.register('../sw.js',{scope:'../'}).catch(()=>{});

// ─── Кнопки ──────────────────────────────────────────────────────────────────
const click=(id,fn)=>{$(id).onclick=e=>{fn(e);};};
const cmdBtn=(id,cmd)=>click(id,()=>{send(typeof cmd==='function'?cmd():cmd);vibrate();});
function connectFromInput(){
  const pin=pinInput.value.trim();
  if(pin.length!==4){pinError.textContent='Введите 4 цифры';return;}
  pinError.textContent='';
  reconnectAttempts=0;
  connect(pin);
}
click('pinBtn',connectFromInput);
pinInput.onkeydown=e=>{if(e.key==='Enter')connectFromInput();};
click('connBannerBtn',disconnect);
cmdBtn('playBtn',{cmd:'play_pause'});
cmdBtn('nextBtn',()=>isLive?{cmd:'next'}:{cmd:'seek',val:seekStep});
cmdBtn('prevBtn',()=>isLive?{cmd:'prev'}:{cmd:'seek',val:-seekStep});
cmdBtn('chUpBtn',{cmd:'prev'});
cmdBtn('chDownBtn',{cmd:'next'});
cmdBtn('muteBtn',{cmd:'mute'});
cmdBtn('fullscreenBtn',{cmd:'fullscreen'});
cmdBtn('favBtn',{cmd:'fav_toggle'});
cmdBtn('playModeBtn',{cmd:'play_mode_cycle'});
cmdBtn('demoBtn',{cmd:'demo_toggle'});
cmdBtn('closePlayerBtn',{cmd:'close_player'});
cmdBtn('tagsBtn',{cmd:'settings_open',tab:'tags'});
cmdBtn('settingsBtn',{cmd:'settings_open'});
cmdBtn('volDownBtn',{cmd:'volume_delta',val:-5});
cmdBtn('volUpBtn',{cmd:'volume_delta',val:5});
click('rcFullscreenBtn',()=>{toggleRcFullscreen();vibrate();});
click('rcInstallBtn',()=>{promptRcInstall();vibrate();});
click('disconnectBtn',disconnect);
$('volSlider').oninput=e=>{send({cmd:'volume',val:+e.target.value});$('volValue').textContent=`${e.target.value}%`;};
click('moreBtn',openMore);click('moreCloseBtn',closeMore);moreOverlay.onclick=closeMore;
$('rateSelect').onchange=e=>send({cmd:'rate',val:+e.target.value});
$('chSearch').oninput=renderChannels;
click('menuBtn',openMenu);click('menuCloseBtn',closeMenu);sideOverlay.onclick=closeMenu;
click('channelNumBtn',openNumPanel);click('chNumBtn',openNumPanel);
click('numCloseBtn',closeNumPanel);numOverlay.onclick=closeNumPanel;
click('numClearBtn',()=>{numInput.value=numInput.value.slice(0,-1);vibrate();});
function submitNumber(){
  const n=+numInput.value;
  if(n>0){send({cmd:'select_number',val:n});vibrate();closeNumPanel();}
}
click('numGoBtn',submitNumber);
numInput.onkeydown=e=>{if(e.key==='Enter')submitNumber();};
numInput.oninput=()=>{numInput.value=numInput.value.replace(/\D/g,'').slice(0,4);};
document.querySelectorAll('.numpad button[data-d]').forEach(el=>el.onclick=()=>{
  if(numInput.value.length<4)numInput.value+=el.dataset.d;
  vibrate();
});
click('playlistsBtn',openPlaylists);click('plCloseBtn',closePlaylists);plOverlay.onclick=closePlaylists;

// ─── Клавиатура (ПК) ─────────────────────────────────────────────────────────
document.addEventListener('keydown',e=>{
  if(remoteScreen.classList.contains('hidden')||e.ctrlKey||e.metaKey||e.altKey)return;
  const tag=(e.target.tagName||'').toLowerCase();
  const typing=tag==='input'||tag==='textarea';
  if(e.key==='Escape'){
    if(anyOverlayOpen()){closeAllOverlays();e.preventDefault();}
    else if(typing)e.target.blur();
    return;
  }
  if(typing||tag==='select')return;
  // На кнопке Пробел/Enter «нажимают» её — не перехватываем, чтобы не сработало дважды
  if(tag==='button'&&(e.key===' '||e.key==='Enter'))return;
  if(/^[0-9]$/.test(e.key)){
    if(numPanel.classList.contains('hidden'))openNumPanel();
    if(numInput.value.length<4)numInput.value+=e.key;
    e.preventDefault();return;
  }
  const act={
    ' ':()=>send({cmd:'play_pause'}),
    ArrowUp:()=>send({cmd:'prev'}),
    ArrowDown:()=>send({cmd:'next'}),
    ArrowLeft:()=>send(isLive?{cmd:'prev'}:{cmd:'seek',val:-seekStep}),
    ArrowRight:()=>send(isLive?{cmd:'next'}:{cmd:'seek',val:seekStep}),
    '+':()=>send({cmd:'volume_delta',val:5}),'=':()=>send({cmd:'volume_delta',val:5}),
    '-':()=>send({cmd:'volume_delta',val:-5}),'_':()=>send({cmd:'volume_delta',val:-5}),
    m:()=>send({cmd:'mute'}),M:()=>send({cmd:'mute'}),ь:()=>send({cmd:'mute'}),
    f:()=>send({cmd:'fullscreen'}),F:()=>send({cmd:'fullscreen'}),а:()=>send({cmd:'fullscreen'}),
    '/':()=>{openMenu();$('chSearch').focus();},
  }[e.key];
  if(act){e.preventDefault();act();}
});

// ─── Старт ───────────────────────────────────────────────────────────────────
const savedPin=localStorage.getItem('remote_pin');
if(savedPin){pinInput.value=savedPin;connect(savedPin);}else pinInput.focus();

// Автоматический fullscreen — только на сенсорных устройствах: на ПК он мешает (вкладка
// внезапно разворачивается по первому же клику), а на телефоне это привычное поведение пульта.
// Fullscreen API требует пользовательского жеста, поэтому ждём первого касания.
if(window.matchMedia('(pointer:coarse)').matches){
  const _rcAutoFsOnFirstInteraction=()=>{
    if(!document.fullscreenElement)document.documentElement.requestFullscreen?.().catch(()=>{});
  };
  document.addEventListener('touchstart',_rcAutoFsOnFirstInteraction,{once:true});
}

// Не даём экрану гаснуть, пока открыта страница пульта (Screen Wake Lock API).
// Браузер сам снимает лок при уходе вкладки в фон — переустанавливаем его при возврате.
let _rcWakeLock=null;
async function _rcRequestWakeLock(){
  if(!('wakeLock'in navigator))return;
  try{
    _rcWakeLock=await navigator.wakeLock.request('screen');
    _rcWakeLock.addEventListener('release',()=>{_rcWakeLock=null;});
  }catch{
    _rcWakeLock=null;
  }
}
document.addEventListener('visibilitychange',()=>{
  if(document.visibilityState==='visible'&&!_rcWakeLock)_rcRequestWakeLock();
});
_rcRequestWakeLock();
