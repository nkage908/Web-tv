// tv-nav.js — Spatial navigation для управления с пульта (Android TV / Google TV и т.п.)
//
// Идея: вместо привычного Tab-порядка ищем среди видимых фокусируемых элементов
// того, кто находится «в нужном направлении» от текущего сфокусированного элемента,
// используя реальную геометрию (getBoundingClientRect). Это стандартный подход
// TV-интерфейсов (аналог CSS spatial navigation / react-tv-space-navigation).
import { loadSettings } from './storage.js';
import { showStatus } from './ui.js';
import { TV_NAV_PERPENDICULAR_PENALTY, TV_NAV_FOCUSABLE_SELECTOR, TV_NAV_RANGE_STEP } from './constants.js';

let _tvModeActive = false;
let _lastFocused = null;

export function isTvModeEnabled() {
  return !!loadSettings().tvMode;
}

export function isTvModeActive() {
  return _tvModeActive;
}

/** Возвращает видимые (не display:none, не скрытые предком, в пределах viewport-иерархии) фокусируемые элементы */
function _getFocusableElements() {
  const all = Array.from(document.querySelectorAll(TV_NAV_FOCUSABLE_SELECTOR));
  const vw = window.innerWidth, vh = window.innerHeight;
  return all.filter(el => {
    if (el.closest('.hidden')) return false;
    const rect = el.getBoundingClientRect();
    if (rect.width === 0 && rect.height === 0) return false;
    // Элементы, сдвинутые за пределы экрана через transform (закрытые дроверы/панели
    // используют translateX/Y вместо display:none), не считаются видимыми
    if (rect.right <= 0 || rect.bottom <= 0 || rect.left >= vw || rect.top >= vh) return false;
    const style = getComputedStyle(el);
    if (style.visibility === 'hidden' || style.display === 'none') return false;
    // Элементы внутри свёрнутых (max-height:0) контейнеров не считаются видимыми
    let node = el.parentElement;
    while (node) {
      const s = getComputedStyle(node);
      if (s.display === 'none' || s.visibility === 'hidden') return false;
      if (node.classList.contains('category-channels') && node.style.maxHeight === '0px') return false;
      node = node.parentElement;
    }
    return true;
  });
}

/** Ищет ближайший фокусируемый элемент в заданном направлении от текущего */
function _findNextFocusTarget(direction) {
  const current = document.activeElement;
  const candidates = _getFocusableElements();
  if (!candidates.length) return null;

  if (!current || current === document.body || !candidates.includes(current)) {
    // Нет валидного текущего фокуса — фокусируем первый видимый элемент
    return candidates[0];
  }

  const curRect = current.getBoundingClientRect();
  const curCenterX = curRect.left + curRect.width / 2;
  const curCenterY = curRect.top + curRect.height / 2;

  let best = null;
  let bestScore = Infinity;

  for (const el of candidates) {
    if (el === current) continue;
    const rect = el.getBoundingClientRect();
    const centerX = rect.left + rect.width / 2;
    const centerY = rect.top + rect.height / 2;
    const dx = centerX - curCenterX;
    const dy = centerY - curCenterY;

    let primary, perpendicular, matchesDirection;
    switch (direction) {
      case 'ArrowRight': primary = dx; perpendicular = dy; matchesDirection = dx > 1; break;
      case 'ArrowLeft':  primary = -dx; perpendicular = dy; matchesDirection = dx < -1; break;
      case 'ArrowDown':  primary = dy; perpendicular = dx; matchesDirection = dy > 1; break;
      case 'ArrowUp':    primary = -dy; perpendicular = dx; matchesDirection = dy < -1; break;
      default: return null;
    }
    if (!matchesDirection) continue;

    const score = primary + Math.abs(perpendicular) * TV_NAV_PERPENDICULAR_PENALTY;
    if (score < bestScore) {
      bestScore = score;
      best = el;
    }
  }
  return best;
}

function _moveFocus(direction) {
  const target = _findNextFocusTarget(direction);
  if (target) {
    target.focus({ preventScroll: false });
    target.scrollIntoView({ block: 'nearest', inline: 'nearest', behavior: 'smooth' });
  }
}

/** Активирует элемент под фокусом (Enter/OK на пульте) */
function _activateFocused() {
  const el = document.activeElement;
  if (!el || el === document.body) return;
  if (el.tagName === 'INPUT' && el.type === 'range') return; // range сам обрабатывает Enter не нужен
  el.click();
}

/** Обработка Left/Right для range-слайдера (громкость), когда он в фокусе */
function _handleRangeArrow(el, direction) {
  const step = parseFloat(el.step) || TV_NAV_RANGE_STEP;
  const min = parseFloat(el.min) || 0;
  const max = parseFloat(el.max) || 100;
  let val = parseFloat(el.value) || 0;
  val = direction === 'ArrowRight' ? Math.min(max, val + step) : Math.max(min, val - step);
  el.value = val;
  el.dispatchEvent(new Event('input', { bubbles: true }));
}

/** Публичная точка входа: обрабатывает keydown, если TV-режим активен.
 *  Возвращает true, если событие обработано (вызывающий код должен остановиться). */
export function handleTvNavKey(e) {
  if (!_tvModeActive) return false;

  const tag = document.activeElement?.tagName;
  const isRange = tag === 'INPUT' && document.activeElement.type === 'range';

  switch (e.key) {
    case 'ArrowUp': case 'ArrowDown':
      e.preventDefault();
      _moveFocus(e.key);
      return true;
    case 'ArrowLeft': case 'ArrowRight':
      e.preventDefault();
      if (isRange) { _handleRangeArrow(document.activeElement, e.key); return true; }
      _moveFocus(e.key);
      return true;
    case 'Enter':
      // Поле ввода номера канала (если когда-либо появится в разметке) обрабатывается нативно —
      // во всех остальных случаях Enter/OK активирует элемент под фокусом.
      if (tag === 'INPUT' && document.activeElement.type !== 'range') return false;
      e.preventDefault();
      _activateFocused();
      return true;
    default:
      return false;
  }
}

/** Включает TV-режим: выставляет видимый фокус, класс на body, слушает фокус-события */
export function enableTvMode() {
  if (_tvModeActive) return;
  _tvModeActive = true;
  document.body.classList.add('tv-mode');
  showStatus('📺 Режим ТВ включён', 'info');
  // Переносим фокус на первый доступный элемент панели плеера
  requestAnimationFrame(() => {
    const target = _lastFocused && document.contains(_lastFocused) ? _lastFocused : _getFocusableElements()[0];
    target?.focus();
  });
  document.addEventListener('focusin', _onFocusIn);
}

export function disableTvMode() {
  if (!_tvModeActive) return;
  _tvModeActive = false;
  document.body.classList.remove('tv-mode');
  document.removeEventListener('focusin', _onFocusIn);
}

function _onFocusIn(e) {
  _lastFocused = e.target;
}

/** Вызывается при старте приложения — применяет сохранённую настройку tvMode */
export function initTvNav() {
  if (isTvModeEnabled()) enableTvMode();
}

export function setTvMode(enabled) {
  if (enabled) enableTvMode(); else disableTvMode();
}

/** Фокусирует первый видимый фокусируемый элемент внутри контейнера (используется при открытии дровера/панелей в TV-режиме) */
export function focusFirstIn(container) {
  if (!_tvModeActive || !container) return;
  requestAnimationFrame(() => {
    const el = container.querySelector(TV_NAV_FOCUSABLE_SELECTOR);
    el?.focus();
  });
}

export { _activateFocused as activateFocused };
