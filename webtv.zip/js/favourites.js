import{state,escapeHtml,STORAGE_KEYS}from'./state.js';
const FAV_KEY=STORAGE_KEYS.FAVOURITES;
export const getFavourites=()=>{try{return JSON.parse(localStorage.getItem(FAV_KEY)||'[]');}catch{return[];}};
const saveFavourites=list=>localStorage.setItem(FAV_KEY,JSON.stringify(list));
// Кеш множества url: isFavourite вызывается на каждую строку списка — парсить localStorage каждый раз дорого.
// Ключ кеша — сама сырая строка, поэтому любые изменения (в т.ч. из другой вкладки/импорта) подхватываются.
let _favRaw=null,_favSet=new Set();
export const isFavourite=url=>{
  let raw;try{raw=localStorage.getItem(FAV_KEY)||'[]';}catch{raw='[]';}
  if(raw!==_favRaw){_favRaw=raw;_favSet=new Set(getFavourites().map(f=>f&&f.url));}
  return _favSet.has(url);
};
export function toggleFavourite(url){
  const list=getFavourites();
  const idx=list.findIndex(f=>f.url===url);
  if(idx>=0){list.splice(idx,1);}
  else{
    const ch=state.allChannels.find(c=>c.url===url);
    if(ch)list.unshift({url:ch.url,title:ch.title,logo:ch.logo||'',group:ch.group||'',tvgId:ch.tvgId||''});
  }
  saveFavourites(list);
  // Обновляем все кнопки с этим url
  document.querySelectorAll(`.fav-btn[data-fav-url="${CSS.escape(url)}"]`).forEach(btn=>{
    btn.classList.toggle('active',idx<0);
    btn.title=idx<0?'Убрать из избранного':'Добавить в избранное';
  });
  // Обновляем кнопку в контролах плеера
  const vcFav=document.getElementById('vcFavBtn');
  if(vcFav&&vcFav.dataset.favUrl===url){
    vcFav.classList.toggle('active',idx<0);
    const icon=document.getElementById('vcFavIcon');
    if(icon){icon.setAttribute('fill',idx<0?'#f59e0b':'none');icon.setAttribute('stroke',idx<0?'#f59e0b':'currentColor');}
  }
  updateFavSection();
  return idx<0;
}
export function updateFavSection(){
  const container=document.getElementById('favSection');
  if(!container)return;
  const list=getFavourites();
  const wasOpen=container.querySelector('.category-item.active')!=null;
  const starIcon=`<svg width="12" height="12" viewBox="0 0 24 24" fill="#f59e0b" stroke="none"><polygon points="12 2 15.09 8.26 22 9.27 17 14.14 18.18 21.02 12 17.77 5.82 21.02 7 14.14 2 9.27 8.91 8.26 12 2"/></svg>`;
  if(!list.length){
    container.innerHTML='';
    return;
  }
  const{channelItemHtml}=window.__appModules||{};
  const html=list.map(ch=>channelItemHtml?channelItemHtml(ch):chHtml(ch)).join('');
  container.innerHTML=`<div class="category-item fav-section-item${wasOpen?' active':''}" data-fav-section="1" tabindex="-1">${starIcon}<span class="category-label">Избранное</span><span class="category-count">${list.length}</span><span class="category-arrow">›</span></div><ul class="category-channels" style="max-height:0">${html}</ul>`;
  if(wasOpen){
    const listEl=container.querySelector('.category-channels');
    requestAnimationFrame(()=>{ if(listEl) listEl.style.maxHeight=listEl.scrollHeight+'px'; });
  }
}
export function toggleFavSection(){
  const container=document.getElementById('favSection');
  if(!container)return;
  const item=container.querySelector('.fav-section-item');
  const list=container.querySelector('.category-channels');
  if(!item||!list)return;
  const isOpen=item.classList.contains('active');
  item.classList.toggle('active',!isOpen);
  list.style.maxHeight=isOpen?'0':list.scrollHeight+'px';
}
// Fallback если channelItemHtml ещё не зарегистрирован
function chHtml(ch){
  const initials=ch.title.replace(/[^a-zA-Zа-яёА-ЯЁ0-9]/g,'').slice(0,2).toUpperCase()||'?';
  const logoHtml=ch.logo?`<img class="ch-logo" src="${escapeHtml(ch.logo)}" alt="" loading="lazy" onerror="this.style.display='none';this.nextElementSibling.style.display='flex'">`:'';
  const avatarStyle=ch.logo?'display:none':'display:flex';
  const escUrl=ch.url.replace(/"/g,'&quot;');
  return`<li class="channel-item" data-ch-url="${escUrl}" tabindex="-1"><div class="channel-title-row"><div class="ch-logo-wrap">${logoHtml}<span class="ch-logo-fallback" style="${avatarStyle}">${initials}</span></div><span class="ch-name">${escapeHtml(ch.title)}</span></div></li>`;
}
