import { STORAGE_KEYS } from './state.js';
import { DEFAULT_SETTINGS, PLAYLISTS_MAX_COUNT, LAST_CHANNEL_TTL_MS } from './constants.js';

// Кеш настроек объявляем до storage, чтобы save мог его обнулять
let _settingsCache = null;

export const storage = {
  save: (key, data) => { try { localStorage.setItem(key, JSON.stringify(data)); if (key === STORAGE_KEYS.SETTINGS) _settingsCache = null; return true; } catch (e) { console.error('Storage save:', e); return false; } },
  load: key => { try { const d = localStorage.getItem(key); return d ? JSON.parse(d) : null; } catch (e) { console.error('Storage load:', e); return null; } },
  remove: key => { try { localStorage.removeItem(key); return true; } catch { return false; } },
  clear: () => { try { Object.values(STORAGE_KEYS).forEach(k => localStorage.removeItem(k)); _settingsCache = null; return true; } catch { return false; } },
};

export const playlistManager = {
  save: (name, url, data) => {
    const playlists = storage.load(STORAGE_KEYS.PLAYLISTS) || {};
    const id = Date.now().toString();
    playlists[id] = { id, name, url, data, created: new Date().toISOString(), lastUsed: new Date().toISOString() };
    if (Object.keys(playlists).length > PLAYLISTS_MAX_COUNT) {
      const oldest = Object.values(playlists).sort((a, b) => new Date(a.lastUsed) - new Date(b.lastUsed))[0];
      delete playlists[oldest.id];
    }
    storage.save(STORAGE_KEYS.PLAYLISTS, playlists);
    return id;
  },
  load: id => {
    const playlists = storage.load(STORAGE_KEYS.PLAYLISTS) || {};
    const p = playlists[id];
    if (p) { p.lastUsed = new Date().toISOString(); storage.save(STORAGE_KEYS.PLAYLISTS, playlists); }
    return p;
  },
  getAll: () => Object.values(storage.load(STORAGE_KEYS.PLAYLISTS) || {}).sort((a, b) => new Date(b.lastUsed) - new Date(a.lastUsed)),
  remove: id => { const p = storage.load(STORAGE_KEYS.PLAYLISTS) || {}; delete p[id]; storage.save(STORAGE_KEYS.PLAYLISTS, p); },
};

export const loadSettings = () => {
  if (_settingsCache) return _settingsCache;
  _settingsCache = { ...DEFAULT_SETTINGS, ...(storage.load(STORAGE_KEYS.SETTINGS) || {}) };
  return _settingsCache;
};

export const saveLastChannel = ch => storage.save(STORAGE_KEYS.LAST_CHANNEL, {
  title: ch.title, url: ch.url, group: ch.group, tvgId: ch.tvgId || '', timestamp: Date.now(),
});

export const loadLastChannel = () => {
  const ch = storage.load(STORAGE_KEYS.LAST_CHANNEL);
  return ch && Date.now() - ch.timestamp < LAST_CHANNEL_TTL_MS ? ch : null;
};
