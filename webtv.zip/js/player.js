import { state, detectStreamType, isMobile, escapeHtml } from './state.js';
import { loadSettings, saveLastChannel, storage } from './storage.js';
import { showStatus, showHeaderMobile, scheduleHeaderHide } from './ui.js';
import { getCurrentEPG } from './epg.js';
import { syncActiveCategory, vsScrollToIndex, _getGroupChannels } from './drawer.js';
import { filterByTags } from './tags.js';
import { STORAGE_KEYS } from './state.js';
import {
  APP_NAME,
  FADE_FALLBACK_MS, FADE_DURATION_MIN_MS, FADE_DURATION_MAX_MS,
  HLS_BACK_BUFFER, HLS_BACK_BUFFER_AUTO, HLS_AUTO_DETECT_TIMEOUT_MS, HLS_MAX_RECOVER_ATTEMPTS,
  MPEGTS_LOAD_TIMEOUT_MS, MPEGTS_VLC_TIP_DELAY_MS,
  MPEGTS_ALT_SOLUTIONS_DELAY_MS, MPEGTS_ALT_SOLUTIONS_INTERVAL_MS,
  PLAY_MODES, PLAY_MODE_ORDER, STREAM_PREFETCH_TIMEOUT_MS,
  PLAYBACK_RATES, PLAYBACK_RATE_DEFAULT,
  STREAM_PREFETCH_MAX_MANIFEST_BYTES, STREAM_PREFETCH_DEDUPE_MS,
} from './constants.js';
import { castCurrentChannelIfActive } from './cast.js';

// ─── Прогрев сети для следующего потока (см. playStream / timeupdate) ─────────
/** url -> время последнего прогрева (мс). Нужен, чтобы не дублировать запрос, если пользователь
 *  быстро листает туда-обратно; запись «протухает» через STREAM_PREFETCH_DEDUPE_MS. */
const _prefetchedAt = new Map();
/** Канал, выбранный в момент старта fade-out (для прогрева сети) — переиспользуется
 *  в обработчике 'ended', чтобы не выбирать другой случайный канал повторно при random-режимах. */
let _plannedNextChannel = null;

/** Лёгкий network-прогрев ТОЛЬКО для HLS-манифестов: параллельно с fade-out открываем
 *  соединение и подгружаем маленький .m3u8, чтобы к реальному hls.loadSource() сервер и
 *  TLS-сессия уже были «тёплыми».
 *  Что намеренно НЕ делается:
 *   - не прогреваются прогрессивные/неопознанные/MPEG-TS URL: это могут быть бесконечные
 *     потоки, и GET на них качал бы данные до таймаута, занимая слот соединения у IPTV-провайдера
 *     (многие ограничивают число соединений на аккаунт или выдают одноразовые ссылки);
 *   - не читается тело, если оно не похоже на небольшой текстовый манифест — оно отменяется;
 *   - прогрев можно отключить в настройках (prefetchNext).
 *  Ошибки (CORS, сеть, таймаут) намеренно проглатываются: это лишь оптимизация. */
async function _prefetchStream(url) {
  if (!url || !loadSettings().prefetchNext) return;
  const path = String(url).split(/[?#|]/)[0];
  if (detectStreamType(url) !== 'hls' || /\.ts$/i.test(path)) return; // только манифесты
  const now = Date.now();
  const last = _prefetchedAt.get(url);
  if (last !== undefined && now - last < STREAM_PREFETCH_DEDUPE_MS) return;
  // Не даём Map расти бесконечно при долгой сессии с большим плейлистом
  if (_prefetchedAt.size > 200) _prefetchedAt.clear();
  _prefetchedAt.set(url, now);
  const controller = new AbortController();
  const timer = setTimeout(() => controller.abort(), STREAM_PREFETCH_TIMEOUT_MS);
  try {
    const res = await fetch(url, { signal: controller.signal, mode: 'cors', credentials: 'omit', cache: 'default' });
    const type = res.headers.get('content-type') || '';
    const len = Number(res.headers.get('content-length'));
    const looksLikeManifest = res.ok && /mpegurl|^text\//i.test(type) && !(len > STREAM_PREFETCH_MAX_MANIFEST_BYTES);
    if (looksLikeManifest) await res.text();
    else await res.body?.cancel();
  } catch {
    // CORS/сетевые ошибки ожидаемы для многих плейлистов — не критично
  } finally {
    clearTimeout(timer);
  }
}

// ─── Режим воспроизведения (кнопка на панели плеера) ──────────────────────────
/** playMode -> { playbackEnd, categoryEnd } — используется существующей логикой ended/getNextChannel.
 *  Для random_* categoryEnd не используется getNextChannel напрямую (см. getRandomChannel),
 *  но сохраняется для совместимости со старыми селектами в настройках. */
const PLAY_MODE_TO_CONFIG = {
  pause:            { playbackEnd: 'stop', categoryEnd: 'stop' },
  loop_video:       { playbackEnd: 'loop', categoryEnd: 'stop' },
  loop_group:       { playbackEnd: 'next', categoryEnd: 'loop' },
  loop_playlist:    { playbackEnd: 'next', categoryEnd: 'next' },
  random_category:  { playbackEnd: 'next', categoryEnd: 'loop' },
  random_playlist:  { playbackEnd: 'next', categoryEnd: 'next' },
};

/** true, если текущий режим — один из «случайных» (по категории или по всему плейлисту) */
export function isRandomMode(mode = getPlayMode()) {
  return mode === 'random_category' || mode === 'random_playlist';
}

/** Возвращает следующий канал согласно текущему playMode: для random_* — случайный
 *  (по категории или по всему плейлисту), иначе — обычный getNextChannel(). */
function _getModeDrivenNextChannel(playMode) {
  if (playMode === 'random_category') return getRandomChannel('category');
  if (playMode === 'random_playlist') return getRandomChannel('playlist');
  return getNextChannel();
}

/** Единая точка входа для «продвижения» плеера, используемая ОДИНАКОВО во всех трёх
 *  сценариях: по завершении ролика (ended), при ручном переключении (стрелки/кнопки/хоткеи)
 *  и в режиме демонстрации (demo.js). Так режимы «Пауза» и «Зациклить ролик» ведут себя
 *  идентично независимо от того, что именно вызвало переключение:
 *   - pause      → { action: 'stop' }    ролик просто останавливается, канал не меняется
 *   - loop_video → { action: 'restart' } тот же ролик начинается заново, канал не меняется
 *   - остальные  → { action: 'switch', channel } обычное переключение канала с учётом
 *                  границ категории/плейлиста или случайного выбора для random-режимов
 *  direction: +1 («вперёд»/следующий) или -1 («назад»/предыдущий). Для 'ended' и демо-режима
 *  всегда используется +1, поскольку понятия «назад» там не существует.
 */
export function resolvePlayModeAction(direction = 1, mode = getPlayMode()) {
  if (mode === 'pause') return { action: 'stop' };
  if (mode === 'loop_video') return { action: 'restart' };
  if (mode === 'random_category') return { action: 'switch', channel: getRandomChannel('category') };
  if (mode === 'random_playlist') return { action: 'switch', channel: getRandomChannel('playlist') };
  const channel = direction < 0 ? getPrevChannel() : getNextChannel();
  return { action: 'switch', channel };
}

/** Перезапускает текущий ролик с начала (режим «Зациклить ролик» — канал не меняется).
 *  Используется единообразно и по завершении ролика (ended), и при ручном/демо-переключении. */
export function restartCurrentVideo() {
  const v = document.getElementById('video');
  if (!v) return;
  v.currentTime = 0;
  v.play().catch(() => {});
}

/** Останавливает воспроизведение текущего ролика на месте, как будто он закончился
 *  (режим «Пауза» — канал не меняется). Используется единообразно во всех сценариях. */
export function stopCurrentVideo() {
  document.getElementById('video')?.pause();
}

export function getPlayMode() {
  return loadSettings().playMode || 'loop_playlist';
}

export function setPlayMode(mode) {
  if (!PLAY_MODES[mode]) return;
  const s = { ...loadSettings(), playMode: mode, ...PLAY_MODE_TO_CONFIG[mode] };
  storage.save(STORAGE_KEYS.SETTINGS, s);
  showStatus(`${PLAY_MODES[mode].icon} ${PLAY_MODES[mode].label}`, 'info');
  updatePlayModeButton();
}

export function cyclePlayMode() {
  const cur = getPlayMode();
  const idx = PLAY_MODE_ORDER.indexOf(cur);
  const next = PLAY_MODE_ORDER[(idx + 1) % PLAY_MODE_ORDER.length];
  setPlayMode(next);
}

export function updatePlayModeButton() {
  const btn = document.getElementById('vcPlayModeBtn');
  const icon = document.getElementById('vcPlayModeIcon');
  if (!btn || !icon) return;
  const mode = getPlayMode();
  const info = PLAY_MODES[mode] || PLAY_MODES.loop_playlist;
  icon.textContent = info.icon;
  btn.title = `Режим: ${info.label} — ${info.hint}`;
}

const cleanupVideo = video => {
  video._mpegtsCleanup?.();
  video._mpegtsCleanup = null;
  // Таймер автоопределения формата (tryMultipleFormats) — иначе он сработает уже на другом канале
  clearTimeout(video._autoDetectTimer);
  video._autoDetectTimer = null;
  video._nativeHls = false;
  _clearHintTimers();
  if (window.hls) { window.hls.destroy(); window.hls = null; }
  video.pause();
  video.removeAttribute('src');
  video.load();
};

// ─── Отложенные подсказки (MPEG-TS / «откройте в VLC») ────────────────────────
/** Подсказки привязаны к конкретному потоку: при смене канала их надо снимать, иначе
 *  «Используйте VLC…» всплывёт уже поверх другого, нормально играющего канала. */
const _hintTimers = new Set();
function _later(fn, ms) {
  const id = setTimeout(() => { _hintTimers.delete(id); fn(); }, ms);
  _hintTimers.add(id);
  return id;
}
function _clearHintTimers() {
  _hintTimers.forEach(clearTimeout);
  _hintTimers.clear();
}

// ─── Громкость пользователя и отмена отложенного перехода ─────────────────────
/** Громкость, которую выставил пользователь (0..1). video.volume во время fade-переходов
 *  временно меняется (до 0), поэтому читать «целевую» громкость из него нельзя —
 *  иначе после fade-out звук «залипает» на нуле. null — пользователь ещё ничего не менял. */
let _userVolume = null;
export function setUserVolume(vol) { _userVolume = Math.max(0, Math.min(1, vol)); }
export function getUserVolume(video = document.getElementById('video')) {
  return _userVolume ?? video?.volume ?? 1;
}

/** Поколение запуска: инкрементируется на каждый playStream/closePlayer. Все отложенные
 *  шаги перехода (doPlay, fadeIn, страховочные таймеры) сравнивают своё поколение с текущим
 *  и молча выходят, если уже устарели. */
let _playGen = 0;
/** Снимает таймеры и слушатели незавершённого перехода предыдущего playStream */
let _cancelPendingTransition = () => {};

export function closePlayer() {
  const video = document.getElementById('video');
  // Отменяем отложенный doPlay/fadeIn, активные fade и запланированный авто-переход —
  // иначе поток «воскреснет» после закрытия плеера
  _playGen++;
  _cancelPendingTransition();
  _fadeVolumeToken++;
  _fadeOutScheduled = false;
  _plannedNextChannel = null;
  stopEPGPlayerTick();
  if (video) {
    cleanupVideo(video);
    video.style.transition = '';
    video.style.opacity = '1';
    video.volume = getUserVolume(video);
  }
  state.isLiveStream = false;
  tickEPGPlayerBar(); // скроет EPG-полосу
  state.currentChannelElement?.classList.remove('playing');
  state.currentChannelElement = null;
  state.currentChannelUrl = null;
  state.currentChannelTitle = '';
  updateVCNowPlaying('');
  document.title = APP_NAME;
  showStatus('⏹ Проигрыватель закрыт', 'info');
}

let _fadeVolumeToken = 0;
export const fadeVolume = (video, fromVol, toVol, dur, onDone) => {
  const token = ++_fadeVolumeToken;
  const start = performance.now();
  const tick = now => {
    if (token !== _fadeVolumeToken) return;
    const t = Math.min(1, (now - start) / dur);
    video.volume = Math.max(0, Math.min(1, fromVol + (toVol - fromVol) * t));
    if (t < 1) requestAnimationFrame(tick);
    else { video.volume = toVol; onDone?.(); }
  };
  requestAnimationFrame(tick);
};

export const playStream = (url, title = '', channelElement = null) => {
  const video = document.getElementById('video');
  const streamType = detectStreamType(url);
  showStatus(`▼ ${title}...`, 'loading');
  state.currentChannelElement?.classList.remove('playing');
  state.currentChannelUrl = url;
  state.currentChannelTitle = title;
  // Если идёт трансляция на Chromecast, зеркалим переключение канала на приёмник —
  // no-op, если каст не активен.
  castCurrentChannelIfActive();
  // Ручной переход на канал, отличный от запланированного при fade-out (пользователь успел
  // переключить раньше, чем сработал 'ended') — сбрасываем план, иначе 'ended' воспроизведёт
  // устаревший запланированный канал вместо того, что реально идёт сейчас.
  if (_plannedNextChannel && _plannedNextChannel.url !== url) _plannedNextChannel = null;
  // Optimistic: treat HLS/unknown as live until proven otherwise by HLS.js manifest
  state.isLiveStream = (streamType === 'hls' || streamType === 'auto');

  const channel = state.allChannels.find(ch => ch.url === url);
  if (channel) {
    saveLastChannel(channel);
    if (channel.group && state.currentGroup !== channel.group) {
      state.currentGroup = channel.group;
    }
  }
  if (document.getElementById('navDrawer')?.classList.contains('open')) syncActiveCategory();

  let resolvedEl = channelElement ?? document.querySelector(`li[data-ch-url="${CSS.escape(url)}"]`);
  if (resolvedEl) {
    resolvedEl.classList.add('playing');
    state.currentChannelElement = resolvedEl;
    resolvedEl.scrollIntoView({ block: 'nearest', behavior: 'smooth' });
  } else if (channel?.group) {
    // Channel may be in a VS list but its row isn't rendered yet — scroll to it
    const grpChannels = _getGroupChannels(channel.group);
    const vsIdx = grpChannels.findIndex(ch => ch.url === url);
    if (vsIdx >= 0) {
      vsScrollToIndex(channel.group, vsIdx).then(li => {
        // К моменту резолва пользователь мог уже переключиться — не подсвечиваем чужую строку
        if (li && state.currentChannelUrl === url) {
          li.classList.add('playing');
          state.currentChannelElement = li;
        }
      });
    }
  }
  updateVCNowPlaying(title, url);
  _updateRateButtonVisibility(false);
  vcUpdateRateButton();
  startEPGPlayerTick();
  if (isMobile()) showHeaderMobile();
  _resetDrawerTimer();
  const { fadeTransition = true, fadeDuration = 350 } = loadSettings();
  const dur = Math.min(FADE_DURATION_MAX_MS, Math.max(FADE_DURATION_MIN_MS, fadeDuration));
  // Целевая громкость (getUserVolume) — ВСЕГДА пользовательская, а не текущий video.volume: тот может
  // быть посреди fade или уже затухшим до 0 (авто-переход по 'ended'), а при mute не должен теряться.
  // Запоминаем громкость до любого затухания, если пользователь её ещё не задавал явно
  // (иначе после fade-out «пользовательской» громкости неоткуда было бы взять)
  if (_userVolume === null && !_fadeOutScheduled) _userVolume = video.volume;
  // Отменяем незавершённый переход предыдущего вызова (таймеры, слушатели) и помечаем новое поколение
  _cancelPendingTransition();
  const gen = ++_playGen;
  // Fade-out уже отыгран штатным timeupdate-обработчиком (авто-переход по 'ended') —
  // повторное затухание не нужно, сразу переключаемся
  const alreadyFaded = _fadeOutScheduled;
  const doPlay = () => {
    if (gen !== _playGen) return;
    _fadeOutScheduled = false;
    cleanupVideo(video);
    try {
      switch (streamType) {
        case 'hls':         playHLS(video, url); break;
        case 'mpegts':      playMPEGTS(video, url); break;
        case 'progressive': playProgressive(video, url); break;
        case 'dash':
          // DASH (dash.js) не подключён: не тратим HLS_AUTO_DETECT_TIMEOUT_MS на заведомо
          // неподходящую HLS-попытку. Safari/Chromium иногда играют .mpd нативно — пробуем напрямую,
          // а при отказе обработчик 'error' на <video> покажет «формат не поддерживается».
          showStatus('⚠️ DASH не поддерживается плеером, пробую напрямую', 'info');
          playProgressive(video, url); break;
        default:            tryMultipleFormats(video, url);
      }
      document.title = `${title} — ${APP_NAME}`;
    } catch (error) {
      console.error('Error playing stream:', error);
      showStatus('Ошибка воспроизведения', 'error');
    }
  };
  const fadeIn = () => {
    video.style.transition = `opacity ${dur}ms ease`;
    video.style.opacity = '0';
    video.volume = 0;
    let revealed = false;
    let fallbackTimer = null;
    const detach = () => {
      video.removeEventListener('loadeddata', reveal);
      video.removeEventListener('playing', reveal);
      clearTimeout(fallbackTimer);
    };
    // Показываем картинку и поднимаем звук ровно один раз — по готовности потока
    // или по страховочному таймеру, смотря что наступит раньше
    function reveal() {
      if (revealed || gen !== _playGen) return;
      revealed = true;
      detach();
      video.style.opacity = '1';
      // Громкость читаем сейчас: пользователь мог изменить её, пока канал загружался
      fadeVolume(video, 0, getUserVolume(video), dur);
    }
    video.addEventListener('loadeddata', reveal);
    video.addEventListener('playing', reveal);
    fallbackTimer = setTimeout(reveal, dur + FADE_FALLBACK_MS);
    _cancelPendingTransition = () => { revealed = true; detach(); };
  };
  const hasActive = video.src && !video.src.endsWith(location.href);
  if (fadeTransition && hasActive && !alreadyFaded) {
    video.style.transition = `opacity ${dur}ms ease`;
    video.style.opacity = '0';
    fadeVolume(video, video.volume, 0, dur);
    // Прогреваем сеть для нового URL параллельно с затуханием (см. _prefetchStream). Только здесь:
    // без fade-out прогрев не даёт выигрыша по времени и лишь дублировал бы запрос плеера;
    // при авто-переходе URL уже прогрет в момент старта fade-out (timeupdate).
    _prefetchStream(url);
    // doPlay запускается таймером, а не колбэком fadeVolume: любой vcSetVolume/changeVolume
    // во время затухания отменяет fade (и его onDone) — переключение тогда зависало бы
    const t = setTimeout(() => { doPlay(); if (gen === _playGen) fadeIn(); }, dur);
    _cancelPendingTransition = () => clearTimeout(t);
  } else if (fadeTransition) {
    fadeIn();
    doPlay();
  } else {
    _fadeVolumeToken++; // гасим возможный незавершённый fade
    video.style.opacity = '1';
    video.volume = getUserVolume(video);
    doPlay();
  }
};

/** Обрабатывает фатальную ошибку hls.js по рекомендованному самим hls.js паттерну:
 *  сетевые сбои лечатся startLoad() (переоткрыть соединение), ошибки медиа-буфера —
 *  recoverMediaError() (пересобрать буфер на месте, без потери текущего hls-инстанса).
 *  Ограничено HLS_MAX_RECOVER_ATTEMPTS попытками на каждый тип по отдельности — при
 *  превышении или для прочих фатальных ошибок откатываемся на progressive-fallback. */
const handleHlsFatalError = (video, url, data) => {
  const hls = window.hls;
  if (!hls) return;
  hls._recoverAttempts ??= { network: 0, media: 0 };
  const attempts = hls._recoverAttempts;
  if (data.type === Hls.ErrorTypes.NETWORK_ERROR && attempts.network < HLS_MAX_RECOVER_ATTEMPTS) {
    attempts.network++;
    showStatus(`⚠️ Сбой сети, переподключение… (${attempts.network}/${HLS_MAX_RECOVER_ATTEMPTS})`, 'info');
    // Экспоненциальная пауза 0.5с → 1с → 2с: мгновенные повторы сгорали бы за миллисекунды
    // на одном и том же сбое. Если за это время канал сменили — инстанс уже не текущий.
    setTimeout(() => { if (window.hls === hls) hls.startLoad(); }, 500 * 2 ** (attempts.network - 1));
    return;
  }
  if (data.type === Hls.ErrorTypes.MEDIA_ERROR && attempts.media < HLS_MAX_RECOVER_ATTEMPTS) {
    attempts.media++;
    showStatus(`⚠️ Восстановление потока… (${attempts.media}/${HLS_MAX_RECOVER_ATTEMPTS})`, 'info');
    hls.recoverMediaError();
    return;
  }
  showStatus('Ошибка HLS', 'error');
  // Освобождаем <video> от hls.js до progressive-фолбэка — иначе два механизма
  // (MSE и прямой src) борются за один элемент
  hls.destroy();
  if (window.hls === hls) window.hls = null;
  playProgressive(video, url);
};

const playHLS = (video, url) => {
  if (Hls.isSupported()) {
    window.hls = new Hls({ enableWorker: true, lowLatencyMode: true, backBufferLength: HLS_BACK_BUFFER });
    window.hls.loadSource(url);
    window.hls.attachMedia(video);
    window.hls.on(Hls.Events.MANIFEST_PARSED, () => {
      _announceNowPlaying();
      const level = window.hls.levels?.[window.hls.currentLevel >= 0 ? window.hls.currentLevel : 0];
      state.isLiveStream = level?.details?.live !== false; // default true if details not yet available
      tickEPGPlayerBar();
      video.play().catch(console.error);
    });
    window.hls.on(Hls.Events.LEVEL_LOADED, (event, data) => {
      const wasLive = state.isLiveStream;
      state.isLiveStream = !!data.details?.live;
      if (wasLive !== state.isLiveStream) tickEPGPlayerBar();
    });
    window.hls.on(Hls.Events.LEVEL_SWITCHED, (_, data) => {
      const lvl = window.hls.levels?.[data.level];
      if (!lvl) return;
      const parts = [];
      if (lvl.height) parts.push(`${lvl.height}p`);
      if (lvl.bitrate) parts.push(`${(lvl.bitrate / 1000).toFixed(0)} kbps`);
      if (parts.length) showStatus(`📺 ${parts.join(' · ')}`, 'info');
    });
    // Поток снова отдаёт данные — списываем накопленные попытки восстановления,
    // чтобы будущий одиночный сбой не упирался сразу в лимит из-за старой серии.
    window.hls.on(Hls.Events.FRAG_LOADED, () => {
      if (window.hls?._recoverAttempts) window.hls._recoverAttempts = { network: 0, media: 0 };
    });
    window.hls.on(Hls.Events.ERROR, (event, data) => {
      console.error('HLS Error:', data);
      if (!data.fatal) return;
      handleHlsFatalError(video, url, data);
    });
  } else if (video.canPlayType('application/vnd.apple.mpegurl')) {
    video._nativeHls = true; // см. _syncLiveFlagFromDuration: событий hls.js здесь нет
    video.src = url;
    video.play()
      .then(() => _announceNowPlaying())
      .catch(_onPlayRejected);
  } else {
    playProgressive(video, url);
  }
};

const playMPEGTS = (video, url) => {
  showStatus('⚠️ MPEG-TS не поддерживается', 'error');
  _later(() => showStatus('💡 Используйте VLC плеер или конвертируйте в HLS', 'info'), MPEGTS_VLC_TIP_DELAY_MS);
  video.src = url;
  let done = false;
  const cleanup = () => {
    if (done) return;
    done = true;
    clearTimeout(loadTimeout);
    video.removeEventListener('loadedmetadata', onMeta);
    video.removeEventListener('canplay', onCanPlay);
    video.removeEventListener('timeupdate', onTime);
    video.removeEventListener('error', onError);
  };
  const onMeta = () => _announceNowPlaying();
  const onCanPlay = () => {
    _announceNowPlaying();
    video.play().catch(e => { console.error('Play error:', e); showStatus('Ошибка запуска: ' + e.message, 'error'); cleanup(); });
  };
  const onTime = () => { if (video.currentTime > 0) { _announceNowPlaying(); cleanup(); } };
  const onError = e => {
    console.error('MPEG-TS error:', e); cleanup();
    showStatus('❌ Поток не поддерживается браузером', 'error');
    _later(() => showAlternativeSolutions(url), MPEGTS_ALT_SOLUTIONS_DELAY_MS);
  };
  video.addEventListener('loadedmetadata', onMeta);
  video.addEventListener('canplay', onCanPlay);
  video.addEventListener('timeupdate', onTime);
  video.addEventListener('error', onError);
  const loadTimeout = setTimeout(() => {
    if (!done && video.readyState < 2) {
      cleanup();
      showStatus('⏱️ Нет ответа', 'error');
      _later(() => showAlternativeSolutions(url), MPEGTS_ALT_SOLUTIONS_DELAY_MS);
    }
  }, MPEGTS_LOAD_TIMEOUT_MS);
  video._mpegtsCleanup = cleanup;
};

/** Отказ video.play(): AbortError — штатная отмена (src сменили/канал переключили), не ошибка;
 *  NotAllowedError — автозапуск заблокирован политикой браузера, нужен жест пользователя. */
const _onPlayRejected = error => {
  if (error?.name === 'AbortError') return;
  console.error('Playback error:', error);
  if (error?.name === 'NotAllowedError') showStatus('▶ Нажмите «Воспроизвести» для запуска', 'info');
  else showStatus('Ошибка', 'error');
};

const playProgressive = (video, url) => {
  state.isLiveStream = false;
  video.src = url; video.load();
  video.play()
    .then(() => _announceNowPlaying())
    .catch(_onPlayRejected);
};

const tryMultipleFormats = (video, url) => {
  if (/udp\/|rtp\/|:\d{4,5}\/udp/.test(url)) { playMPEGTS(video, url); return; }
  if (Hls.isSupported()) {
    // Работаем с локальной ссылкой, а не с window.hls: к моменту срабатывания таймера/колбэка
    // глобальная переменная может уже указывать на hls-инстанс другого канала.
    const hls = new Hls({ enableWorker: true, lowLatencyMode: true, backBufferLength: HLS_BACK_BUFFER_AUTO });
    window.hls = hls;
    hls.loadSource(url); hls.attachMedia(video);
    let hlsAttempted = false;
    const fallback = () => {
      if (hlsAttempted) return;
      hlsAttempted = true;
      hls.destroy();
      if (window.hls === hls) window.hls = null;
      playProgressive(video, url);
    };
    hls.on(Hls.Events.MANIFEST_PARSED, () => {
      if (hlsAttempted) return;
      hlsAttempted = true;
      clearTimeout(video._autoDetectTimer);
      _announceNowPlaying();
      const level = hls.levels?.[hls.currentLevel >= 0 ? hls.currentLevel : 0];
      state.isLiveStream = level?.details?.live !== false; // default true if details not yet available
      tickEPGPlayerBar();
      video.play().catch(console.error);
    });
    hls.on(Hls.Events.LEVEL_LOADED, (event, data) => {
      const wasLive = state.isLiveStream;
      state.isLiveStream = !!data.details?.live;
      if (wasLive !== state.isLiveStream) tickEPGPlayerBar();
    });
    hls.on(Hls.Events.FRAG_LOADED, () => {
      if (hls._recoverAttempts) hls._recoverAttempts = { network: 0, media: 0 };
    });
    // До первого успешного MANIFEST_PARSED формат ещё не подтверждён как рабочий HLS —
    // при ошибке сразу пробуем progressive-fallback, восстановление тут не имеет смысла.
    // После — тот же recoverMediaError/startLoad паттерн, что и в playHLS.
    hls.on(Hls.Events.ERROR, (event, data) => {
      if (!data.fatal) return;
      if (!hlsAttempted) { fallback(); return; }
      handleHlsFatalError(video, url, data);
    });
    // Таймер хранится на <video>, чтобы cleanupVideo() мог его снять при смене канала
    video._autoDetectTimer = setTimeout(() => { if (!hlsAttempted) fallback(); }, HLS_AUTO_DETECT_TIMEOUT_MS);
  } else {
    playProgressive(video, url);
  }
};

const showAlternativeSolutions = url => {
  [
    `🔧 Откройте в VLC: vlc://${url}`,
    '🌐 Или скопируйте URL в VLC Media Player',
    '⚙️ Настройте сервер для конвертации в HLS',
    '📱 Используйте специализированное IPTV приложение',
  ].forEach((s, i) => _later(() => showStatus(s, 'info'), i * MPEGTS_ALT_SOLUTIONS_INTERVAL_MS));
};

// -- Video controls UI --

/** Формирует подпись канала для статус-уведомлений и панели «сейчас играет»:
 *  «№N Название», если в настройках включена нумерация каналов, иначе просто «Название».
 *  Номер — порядковая позиция канала в общем плейлисте (1-based), как и в списке каналов дровера. */
export function getChannelDisplayLabel(url, title) {
  const label = title || APP_NAME;
  if (!loadSettings().showChannelNumbers || !url) return label;
  const idx = state.allChannels.findIndex(ch => ch.url === url);
  return idx >= 0 ? `№${idx + 1} ${label}` : label;
}

/** Показывает статус «сейчас играет» с учётом номера канала (если включён в настройках).
 *  Используется во всех обработчиках готовности потока, чтобы не дублировать формирование подписи. */
function _announceNowPlaying() {
  showStatus(getChannelDisplayLabel(state.currentChannelUrl, state.currentChannelTitle) || 'Готово', 'success');
}

function updateVCNowPlaying(title, url = '') {
  const el = document.getElementById('vcNowPlaying');
  if (el) el.textContent = getChannelDisplayLabel(url, title);
  document.title = title ? `${title} — ${APP_NAME}` : APP_NAME;
  const vcFav = document.getElementById('vcFavBtn');
  if (vcFav) {
    vcFav.dataset.favUrl = url;
    const { isFavourite: isFav } = window.__appModules || {};
    const active = isFav?.(url) ?? false;
    vcFav.classList.toggle('active', active);
    const icon = document.getElementById('vcFavIcon');
    if (icon) { icon.setAttribute('fill', active ? '#f59e0b' : 'none'); icon.setAttribute('stroke', active ? '#f59e0b' : 'currentColor'); }
  }
}

export function vcTogglePlay() {
  const v = document.getElementById('video');
  if (v.paused) { v.play().catch(() => {}); showStatus('▶ Воспроизведение', 'info'); }
  else { v.pause(); showStatus('⏸ Пауза', 'info'); }
}

function vcUpdatePlayBtn() {
  const icon = document.getElementById('vcPlayIcon');
  if (!icon) return;
  const v = document.getElementById('video');
  icon.innerHTML = v.paused
    ? '<polygon points="5 3 19 12 5 21 5 3"/>'
    : '<rect x="6" y="4" width="4" height="16"/><rect x="14" y="4" width="4" height="16"/>';
}

export function vcSetVolume(val) {
  const v = document.getElementById('video');
  _fadeVolumeToken++;
  v.volume = val / 100; v.muted = val === 0;
  setUserVolume(v.volume);
  vcUpdateVolumeIcon();
}

export function vcUpdateVolumeIcon() {
  const v = document.getElementById('video');
  const icon = document.getElementById('vcVolumeIcon');
  const slider = document.getElementById('vcVolSlider');
  if (!icon) return;
  const vol = v.muted ? 0 : v.volume;
  if (slider) slider.value = Math.round(vol * 100);
  if (vol === 0) icon.innerHTML = '<polygon points="11 5 6 9 2 9 2 15 6 15 11 19 11 5"/><line x1="23" y1="9" x2="17" y2="15"/><line x1="17" y1="9" x2="23" y2="15"/>';
  else if (vol < 0.5) icon.innerHTML = '<polygon points="11 5 6 9 2 9 2 15 6 15 11 19 11 5"/><path d="M15.54 8.46a5 5 0 0 1 0 7.07"/>';
  else icon.innerHTML = '<polygon points="11 5 6 9 2 9 2 15 6 15 11 19 11 5"/><path d="M15.54 8.46a5 5 0 0 1 0 7.07"/><path d="M19.07 4.93a10 10 0 0 1 0 14.14"/>';
}

// ─── Скорость воспроизведения (VOD) ────────────────────────────────────────────
function _fmtRateLabel(rate) {
  return `${rate}x`;
}

export function vcCurrentPlaybackRate() {
  return document.getElementById('video')?.playbackRate ?? PLAYBACK_RATE_DEFAULT;
}

export function vcSetPlaybackRate(rate) {
  const v = document.getElementById('video');
  if (!v) return;
  v.playbackRate = rate;
  state.playbackRate = rate;
  showStatus(`${_fmtRateLabel(rate)} скорость`, 'info');
  vcUpdateRateButton();
  vcClosePlaybackRateMenu();
}

export function vcResetPlaybackRate() {
  const v = document.getElementById('video');
  if (v) v.playbackRate = PLAYBACK_RATE_DEFAULT;
  state.playbackRate = PLAYBACK_RATE_DEFAULT;
  vcUpdateRateButton();
}

/** Применяет сохранённую скорость к новому ролику. Вызывать нужно ПОСЛЕ загрузки метаданных:
 *  video.load() (cleanupVideo) по спецификации сбрасывает playbackRate к defaultPlaybackRate,
 *  поэтому выставление скорости в начале playStream() пропадало. Для live скорость всегда 1 —
 *  кнопка скорости для него скрыта, и «застрявшее» 2x пользователь сменить бы не смог. */
export function vcRestorePlaybackRate() {
  const v = document.getElementById('video');
  if (!v) return;
  const isVod = v.duration && isFinite(v.duration) && !state.isLiveStream;
  const target = isVod ? (state.playbackRate ?? PLAYBACK_RATE_DEFAULT) : PLAYBACK_RATE_DEFAULT;
  if (v.playbackRate !== target) v.playbackRate = target;
  vcUpdateRateButton();
}

export function vcUpdateRateButton() {
  const label = document.getElementById('vcRateLabel');
  const btn = document.getElementById('vcRateBtn');
  if (!label || !btn) return;
  const rate = vcCurrentPlaybackRate();
  label.textContent = `${rate}x`;
  btn.classList.toggle('active', rate !== PLAYBACK_RATE_DEFAULT);
}

function _rateMenuHtml() {
  const cur = vcCurrentPlaybackRate();
  return PLAYBACK_RATES.map(r =>
    `<button type="button" class="vc-rate-option${r === cur ? ' active' : ''}" onclick="vcSetPlaybackRate(${r})">${_fmtRateLabel(r)}</button>`
  ).join('');
}

export function vcTogglePlaybackRateMenu() {
  const menu = document.getElementById('vcRateMenu');
  if (!menu) return;
  if (!menu.classList.contains('hidden')) { vcClosePlaybackRateMenu(); return; }
  menu.innerHTML = _rateMenuHtml();
  menu.classList.remove('hidden');
  document.addEventListener('click', _onRateMenuOutsideClick, true);
}

export function vcClosePlaybackRateMenu() {
  document.getElementById('vcRateMenu')?.classList.add('hidden');
  document.removeEventListener('click', _onRateMenuOutsideClick, true);
}

function _onRateMenuOutsideClick(e) {
  if (e.target.closest('#vcRateWrap')) return;
  vcClosePlaybackRateMenu();
}

/** Кнопки скорости и перемотки видны только для VOD (не live) и когда доступна
 *  длительность — синхронизируется с видимостью seekbar в vcUpdateSeekbar(). */
function _updateRateButtonVisibility(hasDuration) {
  const wrap = document.getElementById('vcRateWrap');
  if (wrap) wrap.classList.toggle('hidden', !hasDuration);
  if (!hasDuration) vcClosePlaybackRateMenu();
  document.getElementById('vcSeekBackBtn')?.classList.toggle('hidden', !hasDuration);
  document.getElementById('vcSeekFwdBtn')?.classList.toggle('hidden', !hasDuration);
}

/** «м:сс», а от часа и выше — «ч:мм:сс» (раньше фильм показывал «125:03»). */
export function fmtTime(sec) {
  if (isNaN(sec) || !isFinite(sec) || sec < 0) return '0:00';
  const total = Math.floor(sec);
  const h = Math.floor(total / 3600);
  const m = Math.floor((total % 3600) / 60);
  const s = String(total % 60).padStart(2, '0');
  return h > 0 ? `${h}:${String(m).padStart(2, '0')}:${s}` : `${m}:${s}`;
}

/** Нативный HLS (Safari/старый iOS) не даёт событий hls.js, поэтому live/VOD определяем по duration:
 *  конечная — VOD, Infinity — live. Без этого VOD остаётся «оптимистичным live» навсегда:
 *  нет ни seekbar, ни кнопки скорости. Только для потоков, запущенных именно нативно. */
function _syncLiveFlagFromDuration(v) {
  if (!v._nativeHls) return;
  if (v.duration === Infinity) state.isLiveStream = true;
  else if (v.duration > 0 && isFinite(v.duration)) state.isLiveStream = false;
}

export function vcUpdateSeekbar(e) {
  const v = document.getElementById('video');
  _syncLiveFlagFromDuration(v);
  const hasDuration = v.duration && isFinite(v.duration) && !state.isLiveStream;
  document.getElementById('vcSeekbar')?.classList.toggle('hidden', !hasDuration);
  _updateRateButtonVisibility(hasDuration);
  // For live streams: update EPG bar immediately on metadata change
  if (state.isLiveStream) {
    // timeupdate приходит ~4 раза в секунду, а полоса EPG меняется раз в минуты —
    // на нём обновляем не чаще раза в секунду; остальные события (метаданные, play) — сразу
    const now = Date.now();
    if (e?.type !== 'timeupdate' || now - _lastLiveEpgTick > 1000) { _lastLiveEpgTick = now; tickEPGPlayerBar(); }
    return;
  }
  // Hide EPG bar when VOD is playing
  document.getElementById('vcEpgSeekbar')?.classList.add('hidden');
  const pct = v.currentTime / v.duration * 100;
  const fill = document.getElementById('vcProgressFill');
  const thumb = document.getElementById('vcProgressThumb');
  const tCur = document.getElementById('vcTimeCurrent');
  const tDur = document.getElementById('vcTimeDuration');
  if (fill) fill.style.width = pct + '%';
  if (thumb) thumb.style.left = pct + '%';
  if (tCur) tCur.textContent = fmtTime(v.currentTime);
  if (tDur) tDur.textContent = fmtTime(v.duration);
  const buf = document.getElementById('vcProgressBuf');
  if (buf && v.buffered.length > 0) buf.style.width = v.buffered.end(v.buffered.length - 1) / v.duration * 100 + '%';
}

export function vcSeekClick(e) {
  const v = document.getElementById('video');
  if (!v.duration || !isFinite(v.duration)) return;
  const bar = document.getElementById('vcProgress');
  const rect = bar.getBoundingClientRect();
  v.currentTime = Math.max(0, Math.min(1, (e.clientX - rect.left) / rect.width)) * v.duration;
}

function vcSeekDrag(clientX) {
  const v = document.getElementById('video');
  if (!v.duration || !isFinite(v.duration)) return;
  const rect = document.getElementById('vcProgress').getBoundingClientRect();
  v.currentTime = Math.max(0, Math.min(1, (clientX - rect.left) / rect.width)) * v.duration;
}

export function toggleMute() {
  const v = document.getElementById('video');
  v.muted = !v.muted;
  showStatus(v.muted ? '🔇 Звук выключен' : '🔊 Звук включён', 'info');
}

export function changeVolume(delta) {
  const v = document.getElementById('video');
  _fadeVolumeToken++;
  v.muted = false;
  // База — пользовательская громкость, а не video.volume (он может быть посреди fade)
  v.volume = Math.max(0, Math.min(1, getUserVolume(v) + delta));
  setUserVolume(v.volume);
  showStatus(`🔊 Громкость: ${Math.round(v.volume * 100)}%`, 'info');
}

export function seekVideo(seconds) {
  const v = document.getElementById('video');
  if (v.duration && !isNaN(v.duration)) v.currentTime = Math.max(0, Math.min(v.duration, v.currentTime + seconds));
}

export function applyFullscreenUI(inFS) {
  document.body.classList.toggle('fullscreen', inFS);
  const icon = document.getElementById('fsIcon');
  if (!icon) return;
  icon.innerHTML = inFS
    ? '<polyline points="4 14 10 14 10 20"/><polyline points="20 10 14 10 14 4"/><line x1="10" y1="20" x2="21" y2="9"/><line x1="4" y1="14" x2="15" y2="3"/>'
    : '<polyline points="15 3 21 3 21 9"/><polyline points="9 21 3 21 3 15"/><line x1="21" y1="3" x2="14" y2="10"/><line x1="3" y1="21" x2="10" y2="14"/>';
}

export function toggleFullscreen() {
  if (document.fullscreenElement || document.body.classList.contains('fullscreen')) {
    if (document.fullscreenElement) document.exitFullscreen().catch(() => {});
    else applyFullscreenUI(false);
    return;
  }
  // iPhone Safari не даёт requestFullscreen на documentElement (метода нет — вызов бросил бы
  // TypeError мимо .catch) — тогда включаем псевдо-полноэкранный режим через CSS-класс
  const el = document.documentElement;
  const req = el.requestFullscreen || el.webkitRequestFullscreen;
  if (!req) { applyFullscreenUI(true); return; }
  try { Promise.resolve(req.call(el)).catch(() => applyFullscreenUI(true)); }
  catch { applyFullscreenUI(true); }
}

let _lastLiveEpgTick = 0;
let _fadeOutScheduled = false;
// Пока true — штатные timeupdate/ended-обработчики авто-переключения (fade-out на конце
// ролика, playbackEnd:'next'/'loop') не срабатывают: демонстрационный режим (demo.js)
// сам управляет тем, когда и на какой канал переключаться, и сикает video.currentTime
// в произвольные точки ролика — штатная логика «конца видео» в этом случае неприменима
// и конфликтует с таймерами demo.js.
let _externalPlaybackControl = false;
export function setExternalPlaybackControl(on) { _externalPlaybackControl = !!on; if (on) _fadeOutScheduled = false; }

export function initVideoEvents() {
  const v = document.getElementById('video');
  v.addEventListener('timeupdate', vcUpdateSeekbar);
  v.addEventListener('durationchange', vcUpdateSeekbar);
  v.addEventListener('play', () => { vcUpdatePlayBtn(); vcUpdateSeekbar(); scheduleHeaderHide(); });
  v.addEventListener('pause', () => { vcUpdatePlayBtn(); showHeaderMobile(); });
  v.addEventListener('volumechange', vcUpdateVolumeIcon);
  v.addEventListener('loadedmetadata', vcUpdateSeekbar);
  v.addEventListener('loadedmetadata', vcRestorePlaybackRate);
  v.addEventListener('ratechange', vcUpdateRateButton);
  v.addEventListener('timeupdate', () => {
    if (_externalPlaybackControl) return;
    const { playbackEnd = 'stop', fadeTransition = true, fadeDuration = 350, playMode } = loadSettings();
    if (!fadeTransition || playbackEnd === 'stop' || playbackEnd === 'loop') return;
    if (!v.duration || !isFinite(v.duration)) return;
    const dur = Math.min(FADE_DURATION_MAX_MS, Math.max(FADE_DURATION_MIN_MS, fadeDuration));
    const timeLeft = (v.duration - v.currentTime) * 1000;
    // Пользователь перемотал назад уже ПОСЛЕ старта fade-out — иначе ролик доигрывал бы
    // невидимым и без звука. Запас в 400 мс — гистерезис против дрожания на границе.
    if (_fadeOutScheduled && timeLeft > dur + 500) {
      _fadeOutScheduled = false;
      _plannedNextChannel = null;
      _fadeVolumeToken++;
      v.style.opacity = '1';
      v.volume = getUserVolume(v);
    }
    if (!_fadeOutScheduled && timeLeft <= dur + 100) {
      _fadeOutScheduled = true;
      if (_userVolume === null) _userVolume = v.volume;
      const actualDur = Math.min(timeLeft, dur);
      v.style.transition = `opacity ${actualDur}ms ease`;
      v.style.opacity = '0';
      fadeVolume(v, v.muted ? 0 : v.volume, 0, actualDur);
      // Прогреваем сеть для следующего трека прямо в момент старта fade-out, а не когда
      // fade-out уже завершится и playStream() будет вызван — так буферизация начинается
      // на dur миллисекунд раньше, и переключение ощущается более плавным.
      // Канал фиксируется здесь же (а не выбирается заново в 'ended'), чтобы для random-режимов
      // прогревался именно тот URL, который реально будет воспроизведён.
      if (playbackEnd === 'next') {
        _plannedNextChannel = _getModeDrivenNextChannel(playMode);
        if (_plannedNextChannel) _prefetchStream(_plannedNextChannel.url);
      }
    }
  });
  v.addEventListener('ended', () => {
    // Флаг _fadeOutScheduled здесь НЕ сбрасываем заранее: playStream по нему понимает,
    // что fade-out уже отыгран, и не добавляет второе затухание (его сбросит doPlay).
    const resetFade = () => {
      _fadeOutScheduled = false;
      // После штатного fade-out картинка прозрачна, звук на нуле — вернуть, если переключаться некуда
      v.style.opacity = '1';
      v.volume = getUserVolume(v);
    };
    if (_externalPlaybackControl) { _fadeOutScheduled = false; return; }
    const { playbackEnd = 'stop', playMode } = loadSettings();
    if (playbackEnd === 'loop') { resetFade(); restartCurrentVideo(); }
    else if (playbackEnd === 'next') {
      const next = _plannedNextChannel || _getModeDrivenNextChannel(playMode);
      _plannedNextChannel = null;
      if (next) playStream(next.url, next.title);
      else resetFade();
    } else resetFade();
  });
  v.addEventListener('error', e => {
    if (e.target.src && !e.target.src.includes('blob:') && e.target.error) {
      const msgs = { 1: 'Воспроизведение прервано пользователем', 2: 'Ошибка сети при загрузке потока', 3: 'Ошибка декодирования медиафайла', 4: 'Медиа формат не поддерживается браузером' };
      const msg = msgs[e.target.error.code] || 'Неизвестная ошибка воспроизведения';
      const url = e.target.src.toLowerCase();
      if (!url.includes('udp') && !url.includes('mpegts')) showStatus(msg, 'error');
    }
  });
  // Seek drag
  let dragging = false;
  const bar = () => document.getElementById('vcProgress');
  document.addEventListener('mousedown', e => { if (!bar() || !e.target.closest('#vcProgress')) return; dragging = true; vcSeekDrag(e.clientX); });
  document.addEventListener('mousemove', e => { if (dragging) vcSeekDrag(e.clientX); });
  document.addEventListener('mouseup', () => { dragging = false; });
  document.addEventListener('touchstart', e => { if (!bar() || !e.target.closest('#vcProgress')) return; dragging = true; vcSeekDrag(e.touches[0].clientX); }, { passive: true });
  document.addEventListener('touchmove', e => { if (dragging) vcSeekDrag(e.touches[0].clientX); }, { passive: true });
  document.addEventListener('touchend', () => { dragging = false; });
}

// EPG progress tick
// Кеш url→channel для быстрого поиска в tick без allChannels.find()
let _chByUrl = null;
export function invalidateChannelCache() { _chByUrl = null; }

export function tickEPGProgressBars() {
  if (!document.getElementById('navDrawer')?.classList.contains('open')) return;
  const items = document.querySelectorAll('[data-ch-url]');
  if (!items.length) return;
  if (!_chByUrl) _chByUrl = new Map(state.allChannels.map(ch => [ch.url, ch]));
  const nowMs = Date.now();
  const settings = loadSettings();
  items.forEach(item => {
    const ch = _chByUrl.get(item.dataset.chUrl);
    if (!ch) return;
    const prog = getCurrentEPG(ch.tvgId, ch.title, settings);
    if (!prog) {
      item.querySelector('.epg-progress-wrap')?.remove();
      item.querySelector('.channel-current-program')?.remove();
      return;
    }
    const startMs = prog.start instanceof Date ? prog.start.getTime() : prog.start;
    const stopMs = prog.stop instanceof Date ? prog.stop.getTime() : prog.stop;
    const span = stopMs - startMs;
    const pct = span > 0 ? Math.min(100, Math.max(0, Math.round((nowMs - startMs) / span * 100))) : 0;
    let bar = item.querySelector('.epg-progress-bar');
    if (!bar) {
      const titleEsc = escapeHtml(prog.title);
      const wrap = document.createElement('div');
      wrap.className = 'epg-progress-wrap';
      wrap.title = prog.title;
      wrap.innerHTML = `<div class="epg-progress-bar" style="width:${pct}%"></div>`;
      const label = document.createElement('div');
      label.className = 'channel-current-program';
      label.textContent = prog.title;
      const titleRow = item.querySelector('.channel-title-row');
      item.insertBefore(wrap, titleRow ? titleRow.nextSibling : null);
      item.insertBefore(label, wrap.nextSibling);
      // If this item is inside a VS list, invalidate its cached row height so the
      // taller items get correct absolute positioning on the next render pass.
      const vsListEl = item.closest('ul[data-vs-enabled]');
      if (vsListEl && item.dataset.vsIndex !== undefined) {
        const group = vsListEl.closest('.drawer-screen, #navDrawer')
          ?.querySelector('.category-item.active')?.dataset.group;
        if (group) {
          // Force re-measure on next animation frame
          requestAnimationFrame(() => {
            const { vsInvalidateRowHeight, _vsRenderExport } = window.__appModules || {};
            vsInvalidateRowHeight?.(group);
            _vsRenderExport?.(group, vsListEl);
          });
        }
      }
    } else {
      bar.style.width = pct + '%';
      const label = item.querySelector('.channel-current-program');
      if (label && label.textContent !== prog.title) label.textContent = prog.title;
    }
  });
}

// EPG progress bar for live player
let _epgPlayerTimer = null;

export function tickEPGPlayerBar() {
  const v = document.getElementById('video');
  const epgBar = document.getElementById('vcEpgSeekbar');
  if (!epgBar) return;

  // Only show for live streams
  if (!state.isLiveStream) {
    epgBar.classList.add('hidden');
    return;
  }

  const ch = state.allChannels.find(c => c.url === state.currentChannelUrl);
  if (!ch) { epgBar.classList.add('hidden'); return; }

  const settings = loadSettings();
  const prog = getCurrentEPG(ch.tvgId, ch.title, settings);
  if (!prog) {
    epgBar.classList.add('hidden');
    return;
  }

  const nowMs = Date.now();
  const startMs = prog.start instanceof Date ? prog.start.getTime() : prog.start;
  const stopMs  = prog.stop  instanceof Date ? prog.stop.getTime()  : prog.stop;
  const span = stopMs - startMs;
  const pct = span > 0 ? Math.min(100, Math.max(0, (nowMs - startMs) / span * 100)) : 0;
  const minsLeft = Math.max(0, Math.round((stopMs - nowMs) / 60000));
  const timeStr = minsLeft >= 60
    ? `${Math.floor(minsLeft / 60)}ч ${minsLeft % 60}м`
    : `${minsLeft} мин`;

  const fill  = document.getElementById('vcEpgProgressFill');
  const title = document.getElementById('vcEpgTitle');
  const left  = document.getElementById('vcEpgTimeLeft');
  if (fill)  fill.style.width = pct.toFixed(1) + '%';
  if (title) title.textContent = prog.title;
  if (left)  left.textContent  = timeStr;

  epgBar.classList.remove('hidden');
}

export function startEPGPlayerTick() {
  stopEPGPlayerTick();
  tickEPGPlayerBar();
  _epgPlayerTimer = setInterval(tickEPGPlayerBar, 15000);
}

export function stopEPGPlayerTick() {
  clearInterval(_epgPlayerTimer);
  _epgPlayerTimer = null;
}

/** Возвращает случайный канал.
 *  scope='playlist' — случайный из всего плейлиста (state.allChannels);
 *  scope='category' — случайный из каналов текущей категории (или всего плейлиста, если категория не определена). */
export function getRandomChannel(scope = 'playlist') {
  const curUrl = state.currentChannelUrl || state.currentChannelElement?.dataset?.chUrl;
  let pool = filterByTags(state.allChannels);
  if (scope === 'category') {
    const catUrls = _getCategoryUrls(curUrl);
    if (catUrls.length) {
      pool = catUrls.map(u => state.allChannels.find(ch => ch.url === u)).filter(Boolean);
    }
  }
  if (!pool?.length) return null;
  // Исключаем текущий URL заранее: цикл «крутить, пока не другой» зависал на пуле,
  // где все записи — дубли текущего URL
  const others = pool.filter(ch => ch.url !== curUrl);
  if (!others.length) return pool[0];
  return others[Math.floor(Math.random() * others.length)];
}

export function getNextChannel() {
  const curUrl = state.currentChannelUrl || state.currentChannelElement?.dataset?.chUrl;
  if (!curUrl) return null;
  const { categoryEnd = 'stop' } = loadSettings();
  if (categoryEnd === 'next') {
    const list = filterByTags(state.allChannels);
    const idx = list.findIndex(ch => ch.url === curUrl);
    // Текущий канал скрыт фильтром тегов — «вперёд» ведёт к первому видимому, а не в никуда
    if (idx < 0) return list[0] || null;
    // Зацикливаем весь плейлист: после последнего канала переходим к первому
    return list[idx + 1] || list[0] || null;
  }
  const catUrls = _getCategoryUrls(curUrl);
  const catIdx = catUrls.indexOf(curUrl);
  if (catIdx >= 0 && catIdx < catUrls.length - 1)
    return state.allChannels.find(ch => ch.url === catUrls[catIdx + 1]) || null;
  if (categoryEnd === 'stop') return null;
  if (categoryEnd === 'loop')
    return catUrls.length ? state.allChannels.find(ch => ch.url === catUrls[0]) || null : null;
  return null;
}

export function getPrevChannel() {
  const curUrl = state.currentChannelUrl || state.currentChannelElement?.dataset?.chUrl;
  if (!curUrl) return null;
  const { categoryEnd = 'stop' } = loadSettings();
  if (categoryEnd === 'next') {
    const list = filterByTags(state.allChannels);
    const idx = list.findIndex(ch => ch.url === curUrl);
    if (idx < 0) return list[list.length - 1] || null;
    // Зацикливаем весь плейлист: перед первым каналом переходим к последнему
    return list[idx - 1] || list[list.length - 1] || null;
  }
  const catUrls = _getCategoryUrls(curUrl);
  const catIdx = catUrls.indexOf(curUrl);
  if (catIdx > 0)
    return state.allChannels.find(ch => ch.url === catUrls[catIdx - 1]) || null;
  if (categoryEnd === 'stop') return null;
  if (categoryEnd === 'loop')
    return catUrls.length ? state.allChannels.find(ch => ch.url === catUrls[catUrls.length - 1]) || null : null;
  return null;
}

function _getCategoryUrls(curUrl) {
  const domList = state.currentChannelElement?.closest('ul');
  // For VS lists, domList only contains the rendered window — always use groupedChannels
  if (domList && !domList.dataset.vsEnabled) {
    const lis = domList.querySelectorAll('li[data-ch-url]');
    if (lis.length) return Array.from(lis, el => el.dataset.chUrl);
  }
  const group = state.currentGroup || state.allChannels.find(ch => ch.url === curUrl)?.group;
  return _getGroupChannels(group).map(ch => ch.url);
}

function _resetDrawerTimer() {
  const f = window.__appModules?._resetDrawerTimer;
  if (f) f();
  // else: appModules not yet initialised, skip silently (early init calls before DOMContentLoaded)
}
