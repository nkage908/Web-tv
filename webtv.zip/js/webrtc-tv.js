const ICE_SERVERS=[{urls:'stun:stun.l.google.com:19302'}];
let pc=null,send=null,sessionId=0;
export function initWebrtcTv(sendFn){send=sendFn;}
export function handleWebrtcMessage(msg){
  if(msg.type==='webrtc_request')startOffer();
  else if(msg.type==='webrtc_answer'&&pc)pc.setRemoteDescription({type:'answer',sdp:msg.sdp});
  else if(msg.type==='webrtc_ice'&&pc&&msg.candidate)pc.addIceCandidate(msg.candidate).catch(()=>{});
  else if(msg.type==='webrtc_stop')stopOffer();
}
async function startOffer(){
  stopOffer();            // stopOffer увеличивает sessionId — вызываем ДО получения своего номера
  const session=++sessionId;
  const video=document.getElementById('video');
  if(!video||!video.captureStream){send({type:'webrtc_error',msg:'capture_unsupported'});return;}
  // Явный FPS вместо захвата "по изменению кадра" — иначе браузер отдаёт кадры
  // неравномерно, и приёмник вынужден сглаживать рывки буфером на приёме,
  // что и создаёт заметную стабильную задержку в 2-3 секунды.
  const stream=video.captureStream(30);
  if(!stream.getTracks().length){send({type:'webrtc_error',msg:'no_tracks'});return;}
  pc=new RTCPeerConnection({iceServers:ICE_SERVERS});
  stream.getTracks().forEach(t=>pc.addTrack(t,stream));
  pc.onicecandidate=e=>{if(session===sessionId&&e.candidate)send({type:'webrtc_ice',candidate:e.candidate.toJSON()});};
  pc.onconnectionstatechange=()=>{if(session===sessionId&&['failed','closed','disconnected'].includes(pc?.connectionState))stopOffer();};
  const offer=await pc.createOffer();
  if(session!==sessionId)return;
  await pc.setLocalDescription(offer);
  if(session!==sessionId)return;
  send({type:'webrtc_offer',sdp:offer.sdp});
}
function stopOffer(){
  ++sessionId;
  if(pc){pc.close();pc=null;}
}
