export const state={
  isLiveStream:false,
  playlistData:[],
  groupedChannels:{},
  playbackRate:1,
  allChannels:[],
  epgData:{},
  epgIndex:new Map(),
  currentChannelElement:null,
  currentChannelUrl:null,
  currentChannelTitle:'',
  currentGroup:null,
  activeSearchQuery:'',
  activeSearchList:[],
  // Фильтр по тегам с тремя режимами на каждый тег:
  //   or  — показать канал, если есть ХОТЯ БЫ ОДИН тег из этого набора (объединяются между собой)
  //   and — показать канал, только если есть ВСЕ теги из этого набора
  //   not — скрыть канал, если есть ЛЮБОЙ тег из этого набора
  activeTagFilter:{ or:[], and:[], not:[] },
  // Режим множественного выделения каналов (long-press/правый клик) — для группового присвоения тегов
  tagSelectMode:false,
  tagSelectedUrls:new Set(),
};
export const STORAGE_KEYS={
  PLAYLISTS:'iptv_playlists',
  LAST_CHANNEL:'iptv_last_channel',
  SETTINGS:'iptv_settings',
  FAVOURITES:'iptv_favourites',
  TAG_GROUPS:'iptv_tag_groups',
  CHANNEL_TAGS:'iptv_channel_tags',
};
// Тип потока определяется по ПУТИ URL (без query/hash и без «|Заголовок=…» в стиле Kodi),
// с привязкой расширения к концу пути. Раньше regex искал «.ts» где угодно в строке
// (в т.ч. в домене вроде tv.tsn.ca) и не понимал `video.mp4?token=…`.
// ВАЖНО: логика продублирована в worker.js (классический воркер не умеет импортировать
// модули) — при изменении правьте обе копии.
export const streamTypeRegex={
  hls:/\.(m3u8|ts)$|\/hls\/|\/playlist\.[a-z0-9]+$/i,
  dash:/\.mpd$|\/dash\//i,
  progressive:/\.(mp4|m4v|webm|mkv|avi|mov|flv|ogv)$/i,
  // Сюда попадают только UDP/RTP-прокси. Прямые *.ts относятся к hls (см. выше) намеренно:
  // worker.js отбрасывает mpegts-каналы при разборе плейлиста, и перенос .ts сюда молча
  // удалил бы такие каналы у пользователей.
  mpegts:/\/udp\/|\/rtp\/|:\d{4,5}\/udp/i,
};
const _urlPath=url=>String(url||'').trim().split(/[?#|]/)[0];
export const isMobile=()=>!window.matchMedia('(hover: hover)').matches;
export const detectStreamType=url=>{
  const{hls,dash,progressive,mpegts}=streamTypeRegex;
  const path=_urlPath(url);
  if(hls.test(path))return'hls';
  if(dash.test(path))return'dash';
  // Расширение либо в конце пути (video.mp4?token=…), либо в самом конце строки (api?file=a.mp4)
  if(progressive.test(path)||progressive.test(String(url||'').trim()))return'progressive';
  if(mpegts.test(path))return'mpegts';
  return'auto';
};
export const escapeHtml = s => String(s || '').replace(/[&<>"']/g, c => ({
  '&': '&amp;',
  '<': '&lt;',
  '>': '&gt;',
  '"': '&quot;',
  "'": '&#39;'
}[c]));

