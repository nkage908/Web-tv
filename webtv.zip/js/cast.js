// ─── Chromecast (Google Cast) ──────────────────────────────────────────────
// Кастуем ИСХОДНЫЙ url потока (m3u8/mp4 и т.п.), а не то, что видит hls.js —
// приёмник (Chromecast) сам запрашивает и парсит плейлист на своей стороне,
// он не умеет получать уже декодированный в браузере через MSE поток.
//
// Требования на стороне сервера потока: CORS должен разрешать запросы от
// receiver-приложения Chromecast (и обычно отдельно — заголовки Range для
// сегментов). Если поток отдаётся без CORS вообще, трансляция на ТВ не
// заработает, даже если в браузере всё играет нормально — это ограничение
// самого Cast-протокола, а не этого плеера.

import { state, detectStreamType } from './state.js';
import { showStatus } from './ui.js';

const CAST_RECEIVER_APP_ID = 'CC1AD845'; // Default Media Receiver (не требует своего receiver-приложения)

let castAvailable = false;
let castSession = null;

/** Возвращает MIME-подсказку для Cast'а исходя из типа потока. Cast сам
 *  умеет разбирать HLS (application/x-mpegurl) и DASH; для обычных
 *  прогрессивных файлов передаём их тип впрямую. */
function _castContentType(url) {
  const type = detectStreamType(url);
  if (type === 'hls') return 'application/x-mpegurl';
  if (type === 'dash') return 'application/dash+xml';
  if (/\.mp4($|\?)/i.test(url)) return 'video/mp4';
  if (/\.webm($|\?)/i.test(url)) return 'video/webm';
  return 'application/x-mpegurl'; // разумный дефолт для живых IPTV-плейлистов
}

/** Инициализация Cast SDK — вызывается колбэком, который грузит сама
 *  библиотека Google после window.__onGCastApiAvailable. */
function _initCastApi() {
  const context = cast.framework.CastContext.getInstance();
  context.setOptions({
    receiverApplicationId: CAST_RECEIVER_APP_ID,
    autoJoinPolicy: chrome.cast.AutoJoinPolicy.ORIGIN_SCOPED,
  });

  context.addEventListener(
    cast.framework.CastContextEventType.SESSION_STATE_CHANGED,
    (event) => {
      const State = cast.framework.SessionState;
      if (event.sessionState === State.SESSION_STARTED || event.sessionState === State.SESSION_RESUMED) {
        castSession = context.getCurrentSession();
        _updateCastButtonState(true);
        // Если сессия только что установилась и у нас уже что-то играет — сразу кастуем
        if (state.currentChannelUrl) _loadCurrentIntoCast();
      } else if (event.sessionState === State.SESSION_ENDED) {
        castSession = null;
        _updateCastButtonState(false);
      }
    }
  );

  castAvailable = true;
  document.getElementById('vcCastBtn')?.classList.remove('hidden');
}

/** Google грузит cast_sender.js асинхронно и сам вызывает этот глобальный
 *  колбэк, как только API готов — имя функции фиксировано их SDK. */
window.__onGCastApiAvailable = function (isAvailable) {
  if (isAvailable) _initCastApi();
};

/** Подключаем сам скрипт SDK лениво: не тратим время загрузки страницы на
 *  библиотеку, если ей никто не воспользуется в этой сессии (десктоп Chrome
 *  без Cast-совместимых устройств рядом — обычный случай для многих пользователей). */
export function initCastLazy() {
  if (!/Chrome|CriOS/.test(navigator.userAgent) || /Edg\//.test(navigator.userAgent)) {
    // Cast Sender SDK формально грузится и в других браузерах, но реально
    // работает (кнопка что-то находит) только в Chrome/Chromium — не тратим
    // ресурсы на заведомо неработающий сценарий.
    return;
  }
  const s = document.createElement('script');
  s.src = 'https://www.gstatic.com/cv/js/sender/v1/cast_sender.js?loadCastFramework=1';
  s.async = true;
  document.head.appendChild(s);
}

function _updateCastButtonState(isCasting) {
  const btn = document.getElementById('vcCastBtn');
  if (!btn) return;
  btn.classList.toggle('vc-casting', isCasting);
  btn.title = isCasting ? 'Транслируется на ТВ (нажмите, чтобы отключить)' : 'Транслировать на ТВ (Chromecast)';
}

/** Грузит текущий канал в уже открытую Cast-сессию. Вызывается и при клике
 *  на кнопку каста, и автоматически при смене канала во время активного каста
 *  (см. хук в player.js), чтобы трансляция на ТВ следовала за переключениями
 *  так же, как это происходит в самом браузере. */
function _loadCurrentIntoCast() {
  if (!castSession || !state.currentChannelUrl) return;
  const mediaInfo = new chrome.cast.media.MediaInfo(state.currentChannelUrl, _castContentType(state.currentChannelUrl));
  mediaInfo.metadata = new chrome.cast.media.GenericMediaMetadata();
  mediaInfo.metadata.title = state.currentChannelTitle || 'WEB Play';
  mediaInfo.streamType = state.isLiveStream ? chrome.cast.media.StreamType.LIVE : chrome.cast.media.StreamType.BUFFERED;

  const request = new chrome.cast.media.LoadRequest(mediaInfo);
  castSession.loadMedia(request).catch((err) => {
    console.error('Cast loadMedia error:', err);
    showStatus('Не удалось начать трансляцию на ТВ', 'error');
  });
}

/** Хук для player.js: если каст активен и пользователь переключил канал,
 *  зеркалим переключение на приёмник. No-op, если сессии нет — тогда просто
 *  ничего не делаем, обычное воспроизведение в браузере не затрагивается. */
export function castCurrentChannelIfActive() {
  if (castSession) _loadCurrentIntoCast();
}

export function isCastingActive() {
  return !!castSession;
}

/** Обработчик кнопки в панели плеера. Первый клик без активной сессии
 *  открывает системный пикер устройств Chromecast (это делает framework
 *  сам — requestSession показывает диалог выбора); последующий клик по уже
 *  кастящей кнопке завершает сессию. */
export function toggleCast() {
  if (!castAvailable) {
    showStatus('Chromecast недоступен в этом браузере', 'error');
    return;
  }
  const context = cast.framework.CastContext.getInstance();
  if (castSession) {
    context.endCurrentSession(true);
    return;
  }
  context.requestSession()
    .then(() => {
      // castSession и загрузка текущего канала произойдут в обработчике
      // SESSION_STATE_CHANGED выше (SESSION_STARTED) — не дублируем здесь,
      // иначе loadMedia уйдёт на приёмник дважды подряд.
    })
    .catch((err) => {
      // Пользователь просто закрыл диалог выбора устройства — не ошибка
      if (err !== 'cancel') console.error('Cast requestSession error:', err);
    });
}
