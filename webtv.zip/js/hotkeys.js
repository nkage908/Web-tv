import { state } from './state.js';
import { showStatus } from './ui.js';
import { openDrawer, closeDrawer, closeEPGDrawer, vsScrollToIndex, _getGroupChannels } from './drawer.js';
import { hideSettings, showSettings } from './settings.js';
import { playStream, seekVideo, toggleMute, changeVolume, toggleFullscreen, getNextChannel, getPrevChannel, getRandomChannel, getPlayMode, vcTogglePlay, restartCurrentVideo, stopCurrentVideo, vcClosePlaybackRateMenu } from './player.js';
import { HOTKEY_DRAWER_SCROLL_DELAY_MS, HOTKEY_SEARCH_FOCUS_DELAY_MS, HOTKEY_CHANNEL_NUMBER_DELAY_MS } from './constants.js';
import { loadSettings } from './storage.js';
import { isTvModeActive, handleTvNavKey } from './tv-nav.js';

export function getVisibleChannels() {
  if (state.activeSearchList.length) {
    const rendered = Array.from(document.querySelectorAll('#drawerSearchContent li[data-ch-url]'));
    if (rendered.length) return rendered;
    return state.activeSearchList.map(ch => {
      const li = document.createElement('li');
      li.dataset.chUrl = ch.url;
      return li;
    });
  }
  if (state.currentGroup && state.groupedChannels[state.currentGroup]) {
    const categoryEl = document.querySelector(`.category-item[data-group="${CSS.escape(state.currentGroup)}"]`);
    const list = categoryEl?.nextElementSibling;
    if (!list) return [];
    // For VS lists return the full channel list as virtual proxies; for normal lists return DOM items
    if (list.dataset.vsEnabled) {
      return _getGroupChannels(state.currentGroup).map((ch, i) => {
        const rendered = list.querySelector(`li[data-vs-index="${i}"]`);
        if (rendered) return rendered;
        // Proxy: a detached li carrying just data-ch-url for index lookups
        const proxy = document.createElement('li');
        proxy.dataset.chUrl = ch.url;
        proxy.dataset.vsProxy = '1';
        proxy.dataset.vsIndex = String(i);
        return proxy;
      });
    }
    return Array.from(list.querySelectorAll('li[data-ch-url]'));
  }
  return [];
}

export function navigateChannel(direction) {
  // Режимы «Пауза» и «Зациклить ролик» не переключают канал ни по завершении ролика,
  // ни вручную, ни автоматически — стрелки/кнопки «След./Пред.» в этих режимах действуют
  // на текущий ролик так же, как если бы он сам закончился (см. player.js: resolvePlayModeAction).
  const playMode = getPlayMode();
  if (playMode === 'pause') { stopCurrentVideo(); return; }
  if (playMode === 'loop_video') { restartCurrentVideo(); return; }
  // Рандом-режим: и «вперёд», и «назад» при ручном переключении дают случайный канал
  // (по категории или по всему плейлисту, в зависимости от выбранного режима), а не последовательный.
  if (playMode === 'random_category' || playMode === 'random_playlist') {
    const scope = playMode === 'random_category' ? 'category' : 'playlist';
    const ch = getRandomChannel(scope);
    if (!ch) return;
    const el = document.querySelector(`li[data-ch-url="${CSS.escape(ch.url)}"]`);
    if (el) { el.click(); el.scrollIntoView({ block: 'nearest', behavior: 'smooth' }); }
    else playStream(ch.url, ch.title, null);
    return;
  }
  if (state.activeSearchList.length) {
    const idx = state.activeSearchList.findIndex(ch => ch.url === (state.currentChannelUrl || ''));
    const next = idx + direction;
    if (next < 0 || next >= state.activeSearchList.length) return;
    const ch = state.activeSearchList[next];
    const el = document.querySelector(`li[data-ch-url="${CSS.escape(ch.url)}"]`);
    if (el) { el.click(); el.scrollIntoView({ block: 'nearest', behavior: 'smooth' }); }
    else playStream(ch.url, ch.title, null);
    return;
  }
  const items = getVisibleChannels();
  if (!items?.length) {
    // Список текущей группы ещё не отрисован (например, после автовозобновления, пока дровер не открывали) —
    // переключаем по данным, а не по DOM, иначе стрелки и кнопки пульта «молчат»
    // — идём по каналам текущей группы (как и при навигации по DOM), за её краем — обычная логика next/prev
    const grp = state.currentGroup ? _getGroupChannels(state.currentGroup) : [];
    const gi = grp.findIndex(c => c.url === state.currentChannelUrl);
    const inGroup = gi >= 0 ? grp[gi + direction] : null;
    const ch0 = inGroup || (direction > 0 ? getNextChannel() : getPrevChannel());
    if (ch0) playStream(ch0.url, ch0.title, null);
    return;
  }
  // Try to find current position by playing class first, then by URL match (needed for VS proxy items)
  let cur = items.findIndex(el => el.classList.contains('playing'));
  if (cur === -1 && state.currentChannelUrl) {
    cur = items.findIndex(el => el.dataset.chUrl === state.currentChannelUrl);
  }
  if (cur === -1) cur = direction > 0 ? -1 : items.length;
  const nextIdx = cur + direction;
  if (nextIdx >= 0 && nextIdx < items.length) {
    const target = items[nextIdx];
    if (target.dataset.vsProxy) {
      // Item not in DOM yet — scroll VS list to it, then play once it's rendered
      const vsIdx = parseInt(target.dataset.vsIndex, 10);
      const ch = _getGroupChannels(state.currentGroup)[vsIdx];
      if (!ch) return;
      vsScrollToIndex(state.currentGroup, vsIdx).then(li => {
        if (li) { li.click(); }
        else playStream(ch.url, ch.title, null);
      });
    } else {
      target.click();
      target.scrollIntoView({ block: 'nearest', behavior: 'smooth' });
    }
    return;
  }
  const ch = direction > 0 ? getNextChannel() : getPrevChannel();
  if (!ch) return;
  const el = document.querySelector(`li[data-ch-url="${CSS.escape(ch.url)}"]`);
  if (el) { el.click(); el.scrollIntoView({ block: 'nearest', behavior: 'smooth' }); }
  else playStream(ch.url, ch.title, null);
}

export function toggleHotkeyHelp() {
  let overlay = document.getElementById('hotkeyHelp');
  if (overlay) { overlay.remove(); return; }
  overlay = document.createElement('div');
  overlay.id = 'hotkeyHelp';
  overlay.onclick = () => overlay.remove();
  overlay.innerHTML = `<div class="hotkey-modal"><h3>⌨️ Горячие клавиши</h3><table class="hotkey-table">
    <tr><td><kbd>↑</kbd> / <kbd>↓</kbd></td><td>Предыдущий / следующий канал</td></tr>
    <tr><td><kbd>←</kbd> / <kbd>→</kbd></td><td>Перемотка −N с / +N с (настраивается)</td></tr>
    <tr><td><kbd>Space</kbd></td><td>Пауза / воспроизведение</td></tr>
    <tr><td><kbd>L</kbd></td><td>Список каналов (дровер)</td></tr>
    <tr><td><kbd>G</kbd></td><td>Группы каналов</td></tr>
    <tr><td><kbd>S</kbd></td><td>Настройки</td></tr>
    <tr><td><kbd>F</kbd> / <kbd>F11</kbd></td><td>Полноэкранный режим</td></tr>
    <tr><td><kbd>Find</kbd> (слэш /)</td><td>Поиск канала</td></tr>
    <tr><td><kbd>M</kbd></td><td>Выключить / включить звук</td></tr>
    <tr><td><kbd>Shift</kbd>+<kbd>1</kbd>–<kbd>9</kbd></td><td>Перемотка к 10%–90% ролика</td></tr>
    <tr><td><kbd>0</kbd>–<kbd>9</kbd></td><td>Ввод номера канала/ролика в плейлисте (Enter — сразу)</td></tr>
    <tr><td><kbd>B</kbd></td><td>Добавить/убрать из избранного</td></tr>
    <tr><td><kbd>+</kbd> / <kbd>-</kbd></td><td>Громкость +N% / −N% (настраивается)</td></tr>
    <tr><td><kbd>Esc</kbd></td><td>Закрыть диалог / выйти из полноэкрана</td></tr>
    <tr><td><kbd>?</kbd></td><td>Эта подсказка</td></tr>
  </table><p style="margin:8px 0 0;opacity:0.6;font-size:12px">В «Режиме ТВ» (Настройки → Интерфейс) стрелки перемещают фокус между кнопками и списком каналов, OK/Enter — выбор, Назад — выход. Поддерживаются медиа-клавиши пульта (Play/Pause/Stop/⏮/⏭).</p><p style="margin:8px 0 0;opacity:0.5;font-size:12px">Нажмите в любом месте, чтобы закрыть</p></div>`;
  document.body.appendChild(overlay);
}

// ─── Ввод номера канала цифрами ────────────────────────────────────────────
let _channelNumberBuf = '';
let _channelNumberTimer = null;

function _playChannelByNumber(num) {
  const list = state.allChannels;
  if (!list?.length) return;
  const idx = num - 1;
  const ch = list[idx];
  if (!ch) { showStatus(`✕ Канал №${num} не найден`, 'error'); return; }
  const el = document.querySelector(`li[data-ch-url="${CSS.escape(ch.url)}"]`);
  if (el) { el.click(); el.scrollIntoView({ block: 'nearest', behavior: 'smooth' }); }
  else playStream(ch.url, ch.title, null);
}

function _resetChannelNumberInput() {
  clearTimeout(_channelNumberTimer);
  _channelNumberTimer = null;
  _channelNumberBuf = '';
}

function _handleChannelNumberDigit(digit) {
  _channelNumberBuf += digit;
  showStatus(`№ ${_channelNumberBuf}_`, 'info');
  clearTimeout(_channelNumberTimer);
  _channelNumberTimer = setTimeout(() => {
    const num = parseInt(_channelNumberBuf, 10);
    _resetChannelNumberInput();
    if (num > 0) _playChannelByNumber(num);
  }, HOTKEY_CHANNEL_NUMBER_DELAY_MS);
}

// Медиа-клавиши пульта (стандартные значения KeyboardEvent.key, W3C UI Events;
// Android TV/Google TV транслирует их в браузер именно так)
const MEDIA_PLAY_PAUSE_KEYS = new Set(['MediaPlayPause', 'MediaPlay', 'MediaPause']);
const MEDIA_STOP_KEYS = new Set(['MediaStop']);
const MEDIA_NEXT_KEYS = new Set(['MediaTrackNext', 'ChannelUp']);
const MEDIA_PREV_KEYS = new Set(['MediaTrackPrevious', 'ChannelDown']);
const MEDIA_FF_KEYS = new Set(['MediaFastForward']);
const MEDIA_REW_KEYS = new Set(['MediaRewind']);
// Коды кнопки «Назад» на разных TV-платформах, помимо стандартного Escape/Backspace
const TV_BACK_KEYS = new Set(['BrowserBack', 'GoBack']);

export function initKeyboard() {
  document.addEventListener('keydown', e => {
    const tag = document.activeElement?.tagName;
    const inInput = tag === 'INPUT' || tag === 'TEXTAREA' || tag === 'SELECT';

    // ─── Кнопка «Назад» пульта (в дополнение к Escape) ───────────────────────
    const isBackKey = e.key === 'Escape' || TV_BACK_KEYS.has(e.key) || (e.key === 'Backspace' && !inInput);
    if (isBackKey) {
      if (e.key !== 'Escape') e.preventDefault();
      if (window.isDemoActive?.()) { window.stopDemoMode?.(); return; }
      const help = document.getElementById('hotkeyHelp');
      if (help) { help.remove(); return; }
      if (!document.getElementById('vcRateMenu')?.classList.contains('hidden')) { vcClosePlaybackRateMenu(); return; }
      if (!document.getElementById('settingsOverlay').classList.contains('hidden')) { hideSettings(); return; }
      if (!document.getElementById('introOverlay').classList.contains('hidden')) { window.__appModules?.hideAddPlaylistMenu?.(); return; }
      if (document.getElementById('epgDrawer').classList.contains('open')) { closeEPGDrawer(); return; }
      if (document.getElementById('navDrawer').classList.contains('open')) { closeDrawer(); return; }
      if (document.fullscreenElement) { document.exitFullscreen(); return; }
      if (_channelNumberBuf) { _resetChannelNumberInput(); return; }
      return;
    }

    // ─── Режим демонстрации: интерфейс скрыт, разрешён только выход (Esc/Назад выше) ──
    if (window.isDemoActive?.()) return;

    // ─── Медиа-клавиши пульта ─────────────────────────────────────────────
    if (MEDIA_PLAY_PAUSE_KEYS.has(e.key)) { e.preventDefault(); vcTogglePlay(); return; }
    if (MEDIA_STOP_KEYS.has(e.key)) { e.preventDefault(); document.getElementById('video')?.pause(); return; }
    if (MEDIA_NEXT_KEYS.has(e.key)) { e.preventDefault(); navigateChannel(+1); return; }
    if (MEDIA_PREV_KEYS.has(e.key)) { e.preventDefault(); navigateChannel(-1); return; }
    if (MEDIA_FF_KEYS.has(e.key)) { e.preventDefault(); seekVideo(+(loadSettings().seekStep ?? 10)); return; }
    if (MEDIA_REW_KEYS.has(e.key)) { e.preventDefault(); seekVideo(-(loadSettings().seekStep ?? 10)); return; }

    // ─── TV-режим: фокус-навигация стрелками и OK/Enter ──────────────────
    if (isTvModeActive() && !inInput) {
      if (handleTvNavKey(e)) return;
    }

    if (inInput) return;
    // Сочетания с Ctrl/Meta/Alt — браузерные (Ctrl+F, Ctrl+S, Ctrl+± …), не перехватываем
    if (e.ctrlKey || e.metaKey || e.altKey) return;
    // Shift+1..9 — перемотка к 10%-90% ролика (было просто 1..9).
    // Используем e.code (физическая клавиша), а не e.key: на многих раскладках (например, русской)
    // Shift+цифра даёт символ (!, ", № …), а не саму цифру, и e.key тогда не совпадёт с /^[1-9]$/.
    if (e.shiftKey && /^Digit[1-9]$/.test(e.code)) {
      const n = parseInt(e.code.slice(5), 10);
      const v = document.getElementById('video');
      if (v.duration && isFinite(v.duration)) {
        v.currentTime = v.duration * (n / 10);
        showStatus(`⏩ ${n * 10}%`, 'info');
      }
      return;
    }
    // 0..9 без модификаторов — накопление номера канала/ролика в плейлисте
    if (!e.shiftKey && !e.ctrlKey && !e.altKey && !e.metaKey && /^Digit[0-9]$/.test(e.code)) {
      _handleChannelNumberDigit(e.code.slice(5));
      return;
    }
    // Enter — подтвердить ввод номера немедленно, не дожидаясь таймаута
    if (e.key === 'Enter' && _channelNumberBuf) {
      e.preventDefault();
      const num = parseInt(_channelNumberBuf, 10);
      _resetChannelNumberInput();
      if (num > 0) _playChannelByNumber(num);
      return;
    }
    // Буквы и знаки берём по физической клавише (e.code), чтобы работало на любой раскладке (в т.ч. русской)
    let key = e.key;
    if (/^Key[A-Z]$/.test(e.code)) key = e.code.slice(3).toLowerCase();
    else if (e.code === 'Slash') key = e.shiftKey ? '?' : '/';
    else if (e.code === 'Equal' || e.code === 'NumpadAdd') key = '+';
    else if (e.code === 'Minus' || e.code === 'NumpadSubtract') key = '-';
    switch (key) {
      // В TV-режиме стрелки уже обработаны выше (spatial navigation), сюда не попадут
      case 'ArrowUp':    e.preventDefault(); navigateChannel(-1); break;
      case 'ArrowDown':  e.preventDefault(); navigateChannel(+1); break;
      case 'ArrowLeft':  e.preventDefault(); seekVideo(-(loadSettings().seekStep ?? 10)); break;
      case 'ArrowRight': e.preventDefault(); seekVideo(+(loadSettings().seekStep ?? 10)); break;
      case ' ':          e.preventDefault(); vcTogglePlay(); break;
      case 'l':
        if (document.getElementById('navDrawer').classList.contains('open')) closeDrawer();
        else openDrawer();
        break;
      case 'g':
        openDrawer();
        setTimeout(() => document.getElementById('drawerCategoriesContent')?.scrollTo({ top: 0, behavior: 'smooth' }), HOTKEY_DRAWER_SCROLL_DELAY_MS);
        break;
      case 's': showSettings(); break;
      case '/':
        e.preventDefault();
        openDrawer();
        setTimeout(() => document.getElementById('channelSearchDrawer')?.focus(), HOTKEY_SEARCH_FOCUS_DELAY_MS);
        break;
      case 'f': case 'F11':
        if (e.key === 'F11') e.preventDefault();
        toggleFullscreen(); break;
      case 'm': toggleMute(); break;
      case 'b': window.vcToggleFav?.(); break;
      case '+': changeVolume(+(loadSettings().volumeStep ?? 10) / 100); break;
      case '-':           changeVolume(-(loadSettings().volumeStep ?? 10) / 100); break;
      case '?':           toggleHotkeyHelp(); break;
    }
  });
}
