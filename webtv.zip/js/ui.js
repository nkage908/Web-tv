import { isMobile } from './state.js';
import {
  STATUS_HIDE_INFO_MS, STATUS_HIDE_DEFAULT_MS,
  PANEL_HIDE_LOADER_MS, PANEL_HIDE_DEFAULT_MS,
} from './constants.js';

const hideTimers = { categoryList: null, channelList: null, loader: null };
let _statusTimer = null;

export function showStatus(message, type = 'info') {
  const el = document.getElementById('statusIndicator');
  el.textContent = message;
  clearTimeout(_statusTimer);
  el.className = `show status-${type}`;
  if (type !== 'loading') {
    _statusTimer = setTimeout(
      () => el.classList.remove('show'),
      type === 'info' ? STATUS_HIDE_INFO_MS : STATUS_HIDE_DEFAULT_MS
    );
  }
}

export const showPanel = id => {
  if (isMobile()) return;
  const el = document.getElementById(id);
  if (el) el.classList.add(id === 'loader' ? 'visible' : 'show');
  clearTimeout(hideTimers[id]);
};

export const hidePanel = id => {
  if (isMobile()) return;
  clearTimeout(hideTimers[id]);
  hideTimers[id] = setTimeout(() => {
    const el = document.getElementById(id);
    if (el) el.classList.remove(id === 'loader' ? 'visible' : 'show');
  }, id === 'loader' ? PANEL_HIDE_LOADER_MS : PANEL_HIDE_DEFAULT_MS);
};

export const keepPanelVisible = id => { if (!isMobile()) clearTimeout(hideTimers[id]); };

let _headerHideTimer = null;

export function _scheduleHeaderHide() {
  clearTimeout(_headerHideTimer);
  const v = document.getElementById('video');
  _headerHideTimer = setTimeout(() => {
    // Не скрываем хедер если открыта EPG-панель
    if (document.getElementById('epgDrawer')?.classList.contains('open')) return;
    if (v.src && !v.paused) document.getElementById('loader')?.classList.remove('visible');
  }, _getMenuTimeout());
}

function _getMenuTimeout() {
  const { loadSettings } = window.__appModules || {};
  return loadSettings?.().menuTimeout || 5000;
}

export function showHeaderMobile() {
  if (!isMobile()) return;
  document.getElementById('loader')?.classList.add('visible');
  _scheduleHeaderHide();
}

export function scheduleHeaderHide() {
  _scheduleHeaderHide();
}
