import{state,escapeHtml}from'./state.js';
import{loadSettings}from'./storage.js';
import{showStatus}from'./ui.js';
import{getWorker}from'./worker-bridge.js';
import{updateFavSection}from'./favourites.js';

// Применяет смещение часового пояса EPG к Date-объекту
// Возвращает новый Date сдвинутый на (offset - localOffset) часов
function shiftEPGDate(date, offsetHours) {
  if (offsetHours === null) return date; // авто — не трогаем
  const localOffsetMs = new Date().getTimezoneOffset() * 60000; // в мс (отриц. для UTC+)
  const targetOffsetMs = -offsetHours * 3600000; // UTC+3 → -3*3600000
  const diff = targetOffsetMs - localOffsetMs; // насколько сдвинуть
  return new Date(date.getTime() + diff);
}

// Получаем числовой offset из настроек (null = авто)
function getEPGOffsetHours(settings) {
  const s = settings || loadSettings();
  if (!s.epgTimezone || s.epgTimezone === 'auto') return null;
  return parseFloat(s.epgTimezone);
}
// Кеш HTML телепрограммы: ключ = tvgId + дата, инвалидируется при новых EPG-данных
const _epgContentCache = new Map();

export function onEPGChunk({epgData:chunk}){
  for(const[ch,progs]of Object.entries(chunk)){
    state.epgData[ch]=progs.map(p=>({start:new Date(p.start),stop:new Date(p.stop),title:p.title,desc:p.desc}));
    state.epgIndex.set(ch.toLowerCase(),ch);
  }
}
export function onEPGParsed({total,skipped,channels}){
  _epgContentCache.clear();
  showStatus(`✅ EPG: ${channels} каналов, ${total-skipped} программ${skipped>0?` (${skipped} прошедших пропущено)`:''}`,'success');
  window.refreshCurrentGroup?.();
  window.__appModules?.startEPGPlayerTick?.();
  updateFavSection();
}
export async function loadEPG(url,useCORS=true){
  showStatus('📥 Загрузка EPG...','loading');
  state.epgData={};state.epgIndex=new Map();
  try{
    const settings=loadSettings();
    const isGzip=/\.gz(\?|$)/i.test(url);
    if(isGzip){
      showStatus('📡 Получение архива EPG...','loading');
      let buffer;
      try{
        const r=await fetch(url,{mode:'cors'});
        if(!r.ok)throw new Error(`HTTP ${r.status}`);
        buffer=await r.arrayBuffer();
      }catch(err){
        if(useCORS){
          showStatus('🔄 Попытка через CORS-прокси...','loading');
          const r2=await fetch(`https://api.allorigins.win/raw?url=${encodeURIComponent(url)}`);
          if(!r2.ok)throw new Error('CORS-прокси недоступен');
          buffer=await r2.arrayBuffer();
        }else throw err;
      }
      getWorker().postMessage({type:'parse_epg_gz',payload:{buffer,skipPast:!settings.epgIncludePast}},[buffer]);
    }else{
      showStatus('📡 Получение данных EPG...','loading');
      let text=await fetchTextWithCORS(url,useCORS);
      if(typeof text==='object')text=text.contents||text.data||JSON.stringify(text);
      showStatus('⚙️ Парсинг EPG...','loading');
      getWorker().postMessage({type:'parse_epg_text',payload:{text,skipPast:!settings.epgIncludePast}});
    }
  }catch(e){
    console.error('EPG error',e);
    showStatus('❌ Ошибка загрузки EPG: '+e.message,'error');
  }
}
export async function loadEPGFromFile(file){
  showStatus('📂 Чтение файла EPG...','loading');
  state.epgData={};state.epgIndex=new Map();
  try{
    const settings=loadSettings();
    const isGzip=file.name.endsWith('.gz')||file.type==='application/gzip'||file.type==='application/x-gzip';
    if(isGzip){
      const buffer=await file.arrayBuffer();
      getWorker().postMessage({type:'parse_epg_gz',payload:{buffer,skipPast:!settings.epgIncludePast}},[buffer]);
    }else{
      const reader=new FileReader();
      reader.onerror=()=>showStatus('❌ Ошибка чтения файла EPG','error');
      reader.onload=e=>{
        try{
          showStatus('⚙️ Парсинг EPG...','loading');
          getWorker().postMessage({type:'parse_epg_text',payload:{text:e.target.result,skipPast:!settings.epgIncludePast}});
        }catch(err){
          console.error('EPG file parse error',err);
          showStatus('❌ Ошибка EPG: '+err.message,'error');
        }
      };
      reader.readAsText(file);
    }
  }catch(e){
    console.error('EPG file error',e);
    showStatus('❌ Ошибка загрузки EPG: '+e.message,'error');
  }
}
function findEPGKeyByName(name){
  if(!name||!state.epgIndex.size)return null;
  const low=name.toLowerCase();
  if(state.epgIndex.has(low))return state.epgIndex.get(low);
  for(const[k,v]of state.epgIndex){
    if(k.length<3||low.length<3)continue;
    if(k.includes(low)||low.includes(k))return v;
  }
  return null;
}
export function getChannelEPGKey(channelId,channelName='',settings=null){
  const s=settings||loadSettings();
  if(s.epgMatchBy==='name'&&channelName)return findEPGKeyByName(channelName)||channelId;
  // Режим «по id»: если для id нет данных — пробуем сопоставить по названию (как и hasEPGData)
  if(channelId&&state.epgData[channelId]?.length)return channelId;
  return(channelName&&findEPGKeyByName(channelName))||channelId;
}
export function getCurrentEPG(channelId,channelName='',settings=null){
  if(!channelId&&!channelName)return null;
  const s=settings||loadSettings();
  const offsetHours=getEPGOffsetHours(s);
  // Время программ при показе сдвигается на diff (см. buildEPGContent) — значит «сейчас» сравниваем с ними
  // в обратном сдвиге, чтобы плеер и список показывали одну и ту же передачу
  const nowEPG=offsetHours===null?new Date():new Date(Date.now()-(shiftEPGDate(new Date(0),offsetHours).getTime()));
  // Use the same key-resolution logic as buildEPGContent and hasEPGData
  const epgKey=getChannelEPGKey(channelId,channelName,s);
  let programs=state.epgData[epgKey];
  // Fallback: try the other matching mode if primary lookup failed
  if(!programs?.length&&channelName&&s.epgMatchBy!=='name'){
    const key=findEPGKeyByName(channelName);
    if(key)programs=state.epgData[key];
  }
  if(!programs?.length)return null;
  return programs.find(p=>p.start<=nowEPG&&p.stop>nowEPG)||null;
}
export function hasEPGData(ch,settings=null){
  if(!state.epgIndex.size)return false;
  const s=settings||loadSettings();
  const key=getChannelEPGKey(ch.tvgId||'',ch.title,s);
  if(key&&state.epgData[key]?.length)return true;
  // Fallback: try name match even if mode is 'id'
  const nameKey=findEPGKeyByName(ch.title);
  return!!(nameKey&&state.epgData[nameKey]?.length);
}
export function buildEPGContent(channelId,channelName){
  // Кешируем по ключу канала + текущие сутки (контент меняется раз в минуту максимум,
  // но cache сбрасывается при новой EPG-загрузке, так что устаревание не критично)
  const settings=loadSettings();
  const epgKey=getChannelEPGKey(channelId,channelName,settings);
  const offsetHours=getEPGOffsetHours(settings);
  const cacheKey=epgKey+'|'+Math.floor(Date.now()/60000)+'|'+(offsetHours??'auto'); // пересчёт раз в минуту: «сейчас идёт» и прогресс
  const minute=Math.floor(Date.now()/60000);
  if(_epgCacheMinute!==minute){_epgContentCache.clear();_epgCacheMinute=minute;} // не копим ключи прошлых минут
  if(_epgContentCache.has(cacheKey))return _epgContentCache.get(cacheKey);
  const list=state.epgData[epgKey]||[];
  const now=new Date();
  if(!list.length)return`<p style="padding:24px 16px;color:var(--text2);text-align:center">Нет данных EPG для этого канала</p>`;
  const byDate={};
  list.forEach(p=>{
    const rawStart=p.start instanceof Date&&!isNaN(p.start)?p.start:new Date(p.start);
    const rawStop=p.stop instanceof Date&&!isNaN(p.stop)?p.stop:new Date(p.stop);
    // Сдвигаем для отображения
    const start=offsetHours===null?rawStart:shiftEPGDate(rawStart,offsetHours);
    const stop=offsetHours===null?rawStop:shiftEPGDate(rawStop,offsetHours);
    const dk=start.toLocaleDateString('ru-RU',{year:'numeric',month:'2-digit',day:'2-digit'});
    (byDate[dk]||(byDate[dk]=[])).push({...p,_start:start,_stop:stop});
  });
  const nowDisplay=now; // программы уже сдвинуты для показа, сравниваем с реальным «сейчас»
  const todayKey=nowDisplay.toLocaleDateString('ru-RU',{year:'numeric',month:'2-digit',day:'2-digit'});
  const formatHeader=dk=>{
    const[d,m,y]=dk.split('.');
    const date=new Date(+y,+m-1,+d);
    const isToday=dk===todayKey;
    const tom=new Date(nowDisplay);tom.setDate(tom.getDate()+1);
    const yest=new Date(nowDisplay);yest.setDate(yest.getDate()-1);
    const dayMonth=date.toLocaleDateString('ru-RU',{day:'numeric',month:'long'});
    const weekday=date.toLocaleDateString('ru-RU',{weekday:'long'});
    let label=`${dayMonth}, ${weekday}`;
    if(isToday)label=`Сегодня — ${dayMonth}`;
    else if(date.toDateString()===tom.toDateString())label=`Завтра — ${dayMonth}`;
    else if(date.toDateString()===yest.toDateString())label=`Вчера — ${dayMonth}`;
    return{label,isToday};
  };
  const dateKeys=Object.keys(byDate);
  let html='';
  if(dateKeys.length>1){
    html+=`<div class="epg-date-nav">`+dateKeys.map(dk=>{
      const{label,isToday}=formatHeader(dk);
      return`<button class="epg-date-tab${isToday?' active':''}" data-date="${dk}">${label}</button>`;
    }).join('')+`</div>`;
  }
  html+=`<div class="epg-days-container">`;
  dateKeys.forEach(dk=>{
    const{label,isToday}=formatHeader(dk);
    html+=`<div class="epg-date-section" data-date="${dk}"><div class="epg-date-header${isToday?' epg-date-today':''}">${label}</div>`;
    byDate[dk].forEach(p=>{
      const isNow=p._start<=nowDisplay&&p._stop>nowDisplay;
      const timeStr=`${p._start.toLocaleTimeString([],{hour:'2-digit',minute:'2-digit'})} – ${p._stop.toLocaleTimeString([],{hour:'2-digit',minute:'2-digit'})}`;
      const descHtml=p.desc?`<div class="epg-item-desc">${escapeHtml(p.desc)}</div>`:'';
      let progressHtml='';
      if(isNow){
        const startMs=p._start.getTime(),stopMs=p._stop.getTime();
        const nowMs2=nowDisplay.getTime();
        const pct=Math.min(100,Math.max(0,Math.round((nowMs2-startMs)/(stopMs-startMs)*100)));
        const minsLeft=Math.max(0,Math.round((stopMs-nowMs2)/60000));
        const timeLeftStr=minsLeft>=60?`${Math.floor(minsLeft/60)} ч ${minsLeft%60} мин`:`${minsLeft} мин`;
        progressHtml=`<div class="epg-item-progress"><div class="epg-item-progress-bar" style="width:${pct}%"></div></div><div class="epg-item-time-left">▶ осталось ${timeLeftStr}</div>`;
      }
      html+=`<div class="epg-item${isNow?' epg-current epg-now':''}"><div class="epg-item-header"><span class="epg-time">${timeStr}</span><span class="epg-title">${escapeHtml(p.title)}</span></div>${descHtml}${progressHtml}</div>`;
    });
    html+=`</div>`;
  });
  html+=`</div>`;
  _epgContentCache.set(cacheKey,html);
  return html;
}
export function epgScrollToDate(dateKey){
  ['epgDrawerContent','channelListContent'].forEach(id=>{
    const sec=document.getElementById(id)?.querySelector(`[data-date="${dateKey}"]`);
    if(sec)sec.scrollIntoView({block:'start',behavior:'smooth'});
  });
  document.querySelectorAll('.epg-date-tab').forEach(btn=>{
    btn.classList.toggle('active',btn.dataset.date===dateKey);
  });
}
// Делегируем клики по вкладкам EPG через event delegation
document.addEventListener('click',e=>{
  const btn=e.target.closest('.epg-date-tab');
  if(btn&&btn.dataset.date)epgScrollToDate(btn.dataset.date);
});
async function fetchTextWithCORS(url,useCORS){
  try{
    const r=await fetch(url,{mode:'cors',headers:{'Accept':'text/plain,application/xml,*/*'}});
    if(!r.ok)throw new Error(`HTTP ${r.status}`);
    return await r.text();
  }catch(error){
    const isFetchError=error instanceof TypeError||String(error.message).match(/fetch|network|failed|load/i);
    if(useCORS&&isFetchError){
      const proxies=[
        `https://api.allorigins.win/get?url=${encodeURIComponent(url)}`,
        `https://corsproxy.io/?${encodeURIComponent(url)}`,
      ];
      for(const p of proxies){
        try{
          const proxyRes=await fetch(p);
          if(!proxyRes.ok)continue;
          const ct=proxyRes.headers.get('content-type')||'';
          if(ct.includes('application/json')){const d=await proxyRes.json();return d.contents||d.data||'';}
          return await proxyRes.text();
        }catch(e){console.warn('EPG proxy failed:',p,e);}
      }
    }
    throw error;
  }
}
