import{state,STORAGE_KEYS}from'./state.js';
import{storage,loadSettings}from'./storage.js';
import{showStatus}from'./ui.js';
import{loadEPG,loadEPGFromFile}from'./epg.js';
import{renderSavedPlaylists}from'./playlist.js';
import{setUserVolume}from'./player.js';
import{updateFavSection}from'./favourites.js';
import{focusFirstIn}from'./tv-nav.js';
import{renderTagsSettingsTab,closeTagPopover}from'./tags.js';
export function showSettings(tab='ui'){
  closeTagPopover();
  document.getElementById('settingsOverlay').classList.remove('hidden');
  loadSettingsToUI();
  _activateTab(tab);
  focusFirstIn(document.getElementById('settingsOverlay'));
}
function _activateTab(name){
  document.querySelectorAll('.settings-tab').forEach(b=>b.classList.toggle('active',b.dataset.tab===name));
  document.querySelectorAll('.settings-panel').forEach(p=>p.classList.toggle('active',p.dataset.panel===name));
  if(name==='tags')renderTagsSettingsTab();
}
document.addEventListener('DOMContentLoaded',()=>{
  document.querySelector('.settings-tabs')?.addEventListener('click',e=>{
    const tab=e.target.closest('.settings-tab');
    if(tab)_activateTab(tab.dataset.tab);
  });
  // Если импортированы настройки, пока модал открыт — обновляем поля формы
  document.addEventListener('web7tv:settings-imported',()=>{
    if(!document.getElementById('settingsOverlay').classList.contains('hidden'))loadSettingsToUI();
  });
});
export function hideSettings(){
  document.getElementById('settingsOverlay').classList.add('hidden');
}
export function toggleEPGUrlField(){
  document.getElementById('epgUrlContainer').style.display=
    document.getElementById('settingEnableEPG').checked?'block':'none';
}
export function toggleFadeDurationField(){
  const el = document.getElementById('fadeDurationContainer');
  if (el) el.style.display = document.getElementById('settingFadeTransition').checked ? 'flex' : 'none';
}
export function saveSettings(){
  const g=id=>document.getElementById(id);
  const settings={
    theme:g('settingTheme').value,
    videoFit:g('settingVideoFit').value,
    fontSize:g('settingFontSize').value,
    autoplay:g('settingAutoplay').checked,
    menuTimeout:parseInt(g('settingMenuTimeout').value)||5000,
    volume:Math.min(100,Math.max(0,Number.isNaN(parseInt(g('settingVolume').value))?70:parseInt(g('settingVolume').value))),
    seekStep:Math.min(300,Math.max(1,parseInt(g('settingSeekStep').value)||10)),
    volumeStep:Math.min(50,Math.max(1,parseInt(g('settingVolumeStep').value)||5)),
    autoLoadPlaylist:g('settingAutoLoadPlaylist').checked,
    enableEPG:g('settingEnableEPG').checked,
    epgUrl:g('settingEPGUrl').value.trim(),
    epgUseCORS:g('settingEPGUseCORS').checked,
    epgMatchBy:g('settingEPGMatch').value,
    epgIncludePast:g('settingEPGIncludePast').checked,
    epgTimezone:g('settingEPGTimezone').value,
    playbackEnd:g('settingPlaybackEnd').value,
    categoryEnd:g('settingCategoryEnd').value,
    fadeTransition:g('settingFadeTransition').checked,
    fadeDuration:Math.min(2000,Math.max(50,parseInt(g('settingFadeDuration').value)||350)),
    prefetchNext:g('settingPrefetchNext').checked,
    showChannelNumbers:g('settingShowChannelNumbers').checked,
    tvMode:g('settingTvMode').checked,
    demoSegmentDuration:Math.min(10,Math.max(1,parseInt(g('settingDemoSegmentDuration').value)||3)),
    demoFragmentsCount:Math.min(10,Math.max(1,parseInt(g('settingDemoFragmentsCount').value)||3)),
  };
  // Синхронизируем кнопку режима на панели плеера с выбором в настройках
  // Если выбранная пара «по окончании» всё ещё соответствует текущему режиму (в т.ч. random_*, которые дают
  // те же пары, что loop_group/loop_playlist) — режим не трогаем, иначе «Сохранить» сбрасывал бы рандом
  const curMode=loadSettings().playMode;
  const sameAsCur=curMode&&({..._MODE_TO_ENDS,random_category:'next|loop',random_playlist:'next|next'})[curMode]===`${settings.playbackEnd}|${settings.categoryEnd}`;
  settings.playMode=sameAsCur?curMode:(_deriveModeFromEndSettings(settings.playbackEnd,settings.categoryEnd)||curMode||'loop_playlist');
  storage.save(STORAGE_KEYS.SETTINGS,settings);
  applySettings(settings);
  window.updatePlayModeButton?.();
  window.setTvMode?.(settings.tvMode);
  const epgFile=g('settingEPGFile').files[0];
  if(settings.enableEPG){
    if(epgFile)loadEPGFromFile(epgFile);
    else if(settings.epgUrl)loadEPG(settings.epgUrl,settings.epgUseCORS);
  }
  hideSettings();
  showStatus('Настройки сохранены','success');
}
const _MODE_TO_ENDS={pause:'stop|stop',loop_video:'loop|stop',loop_group:'next|loop',loop_playlist:'next|next'};
function _deriveModeFromEndSettings(playbackEnd,categoryEnd){
  const key=`${playbackEnd}|${categoryEnd}`;
  const found=Object.entries(_MODE_TO_ENDS).find(([,v])=>v===key);
  // random_category/random_playlist дают те же пары значений, что loop_group/loop_playlist —
  // намеренно не выводим их из селектов формы, чтобы не переключать в рандом автоматически.
  return found ? found[0] : null;
}
function loadSettingsToUI(){
  const s=loadSettings();
  const g=id=>document.getElementById(id);
  g('settingTheme').value=s.theme;
  g('settingVideoFit').value=s.videoFit;
  g('settingFontSize').value=s.fontSize||'normal';
  g('settingAutoplay').checked=s.autoplay;
  g('settingMenuTimeout').value=s.menuTimeout;
  g('settingVolume').value=s.volume??70;
  g('settingSeekStep').value=s.seekStep??15;
  g('settingVolumeStep').value=s.volumeStep??5;
  g('settingAutoLoadPlaylist').checked=s.autoLoadPlaylist;
  g('settingEnableEPG').checked=s.enableEPG;
  g('settingEPGUrl').value=s.epgUrl||'';
  g('settingEPGUseCORS').checked=s.epgUseCORS||false;
  g('settingEPGMatch').value=s.epgMatchBy||'id';
  g('settingEPGIncludePast').checked=s.epgIncludePast||false;
  g('settingEPGTimezone').value=s.epgTimezone||'auto';
  g('settingPlaybackEnd').value=s.playbackEnd||'stop';
  g('settingCategoryEnd').value=s.categoryEnd||'stop';
  g('settingFadeTransition').checked=s.fadeTransition??true;
  g('settingFadeDuration').value=s.fadeDuration??350;
  g('settingPrefetchNext').checked=s.prefetchNext??true;
  g('settingShowChannelNumbers').checked=s.showChannelNumbers||false;
  g('settingTvMode').checked=s.tvMode||false;
  g('settingDemoSegmentDuration').value=s.demoSegmentDuration??3;
  g('settingDemoFragmentsCount').value=s.demoFragmentsCount??3;
  toggleFadeDurationField();
  toggleEPGUrlField();
}
// Коэффициенты масштаба относительно базового размера (14px = 1.0).
// Применяются глобально через CSS-переменную --ui-font-scale ко всем font-size в style.css (см. calc(...)).
const FONT_SIZE_SCALE_MAP = { small: 12/14, normal: 1, large: 16/14, xlarge: 19/14 };

export function applySettings(s){
  document.body.classList.toggle('light-theme',s.theme==='light');
  // Размер шрифта — масштабируем весь UI-текст пропорционально (см. calc(Npx * var(--ui-font-scale)) в style.css)
  const fontScale = FONT_SIZE_SCALE_MAP[s.fontSize] ?? 1;
  document.documentElement.style.setProperty('--ui-font-scale', fontScale);
  const v=document.getElementById('video');
  v.style.objectFit=s.videoFit;
  v.muted=false;
  const vol=Math.max(0,Math.min(100,s.volume??70))/100;
  v.volume=vol;
  setUserVolume(vol);
}
export function clearAllData(){
  if(!confirm('Удалить все сохраненные плейлисты и данные?'))return;
  storage.clear();
  state.playlistData=[];
  state.groupedChannels={};
  state.allChannels=[];
  state.epgData={};
  state.epgIndex=new Map();
  state.currentGroup=null;
  state.currentChannelElement=null;
  state.currentChannelUrl=null;
  state.currentChannelTitle='';
  state.activeSearchQuery='';state.activeSearchList=[];
  state.activeTagFilter={or:[],and:[],not:[]};
  document.getElementById('drawerCategoriesContent').innerHTML='';
  document.getElementById('drawerSearchContent').innerHTML='';
  const v=document.getElementById('video');
  v.pause();v.removeAttribute('src');
  if(window.hls){window.hls.destroy();window.hls=null;}
  renderSavedPlaylists();
  updateFavSection();
  document.getElementById('introOverlay').classList.remove('hidden');
  document.getElementById('mainContent').classList.add('blurred');
  showStatus('Все данные удалены','info');
}
