// ─── Экспорт / импорт настроек, избранного и тегов ─────────────────────────
// Плейлисты и EPG сюда намеренно НЕ входят — они либо привязаны к конкретному
// источнику (URL/файл), либо слишком объёмны для ручного переноса; экспортируем
// только то, что реально имеет смысл переносить между браузерами/устройствами:
// настройки, избранное и теги (группы + привязки канал→тег).

import { STORAGE_KEYS } from './state.js';
import { storage, loadSettings } from './storage.js';
import { showStatus } from './ui.js';
import { updateFavSection } from './favourites.js';
import { renderTagsSettingsTab } from './tags.js';
import { applySettings } from './settings.js';

const EXPORT_FORMAT_VERSION = 1;
const tagIdRemap = new Map(); // id тега из файла → id существующего тега с тем же именем (merge)

function _readRaw(key, fallback) {
  try {
    const v = localStorage.getItem(key);
    if (!v) return fallback;
    const parsed = JSON.parse(v);
    // Подстраховка от повреждённых данных в самом хранилище (не от импорта —
    // это защищает merge-логику ниже от .map/.filter на не-массиве/не-объекте).
    if (Array.isArray(fallback) && !Array.isArray(parsed)) return fallback;
    if (!Array.isArray(fallback) && typeof fallback === 'object' && (typeof parsed !== 'object' || parsed === null || Array.isArray(parsed))) return fallback;
    return parsed;
  } catch {
    return fallback;
  }
}

/** Собирает единый JSON-объект для выгрузки. Каждый раздел читается напрямую
 *  из localStorage по тем же ключам, что используют settings.js/favourites.js/
 *  tags.js — так экспорт не рассинхронизируется с их внутренним форматом хранения. */
export function buildExportData() {
  return {
    app: 'WEB Play',
    formatVersion: EXPORT_FORMAT_VERSION,
    exportedAt: new Date().toISOString(),
    settings: _readRaw(STORAGE_KEYS.SETTINGS, {}),
    favourites: _readRaw(STORAGE_KEYS.FAVOURITES, []),
    tagGroups: _readRaw(STORAGE_KEYS.TAG_GROUPS, []),
    channelTags: _readRaw(STORAGE_KEYS.CHANNEL_TAGS, {}),
  };
}

export function exportDataToFile() {
  const data = buildExportData();
  const blob = new Blob([JSON.stringify(data, null, 2)], { type: 'application/json' });
  const url = URL.createObjectURL(blob);
  const a = document.createElement('a');
  const stamp = new Date().toISOString().slice(0, 10);
  a.href = url;
  a.download = `web7tv-settings-${stamp}.json`;
  document.body.appendChild(a);
  a.click();
  a.remove();
  setTimeout(() => URL.revokeObjectURL(url), 1000); // сразу после click() часть браузеров обрывает скачивание
  showStatus('Настройки экспортированы', 'success');
}

/** Валидирует, что распарсенный JSON выглядит как наш экспорт, а не случайный
 *  файл — проверяем только структуру полей, не версию (см. importData). */
function _looksLikeExport(obj) {
  if (!obj || typeof obj !== 'object') return false;
  const okShape = (v, type) => v === undefined || (type === 'array' ? Array.isArray(v) : typeof v === type);
  return okShape(obj.settings, 'object') && okShape(obj.favourites, 'array') &&
         okShape(obj.tagGroups, 'array') && okShape(obj.channelTags, 'object');
}

/** mode: 'merge' — добавляет/дополняет поверх текущих данных (избранное и теги
 *  объединяются по url/id без дублей, настройки импортированного файла перекрывают
 *  только явно присутствующие в нём ключи); 'replace' — полностью заменяет каждый
 *  из четырёх разделов содержимым файла. */
export function importDataFromObject(obj, mode = 'merge') {
  if (!_looksLikeExport(obj)) {
    showStatus('Файл не похож на экспорт настроек WEB Play', 'error');
    return false;
  }

  tagIdRemap.clear();
  if (obj.settings && Object.keys(obj.settings).length) {
    const merged = mode === 'replace' ? obj.settings : { ...loadSettings(), ...obj.settings };
    storage.save(STORAGE_KEYS.SETTINGS, merged);
    applySettings(loadSettings()); // применяем тему/шрифт/видео/громкость сразу, не дожидаясь перезагрузки
  }

  if (obj.favourites) {
    let favs = obj.favourites;
    if (mode === 'merge') {
      const current = _readRaw(STORAGE_KEYS.FAVOURITES, []);
      const seen = new Set(current.map(f => f.url));
      const incoming = obj.favourites.filter(f => f && typeof f.url === 'string' && f.url && !seen.has(f.url));
      favs = [...current, ...incoming];
    } else {
      favs = obj.favourites.filter(f => f && typeof f.url === 'string' && f.url);
    }
    storage.save(STORAGE_KEYS.FAVOURITES, favs);
  }

  if (obj.tagGroups) {
    // Отбрасываем группы без имени и подчищаем их теги — дальше код полагается
    // на то, что у каждой группы есть name (строка) и массив tags с объектами {name}.
    const cleanGroups = obj.tagGroups
      .filter(g => g && typeof g.name === 'string' && g.name.trim())
      .map(g => ({ ...g, tags: Array.isArray(g.tags) ? g.tags.filter(t => t && typeof t.name === 'string' && t.name.trim()) : [] }));

    let groups = cleanGroups;
    if (mode === 'merge') {
      const current = _readRaw(STORAGE_KEYS.TAG_GROUPS, []);
      const byName = new Map(current.map(g => [g.name.toLowerCase(), g]));
      for (const incoming of cleanGroups) {
        const existing = byName.get(incoming.name.toLowerCase());
        if (!existing) {
          current.push(incoming);
          byName.set(incoming.name.toLowerCase(), incoming);
        } else {
          // Группа с таким именем уже есть — добавляем недостающие теги внутрь неё,
          // сохраняя существующие id (иначе привязки channelTags к старым id порвутся).
          
          for (const t of incoming.tags) {
            const same = existing.tags.find(x => x.name.toLowerCase() === t.name.toLowerCase());
            if (!same) existing.tags.push(t);
            else if (t.id && same.id && t.id !== same.id) tagIdRemap.set(t.id, same.id); // привязки файла перенаправим на существующий тег
          }
        }
      }
      groups = current;
    }
    storage.save(STORAGE_KEYS.TAG_GROUPS, groups);
  }

  if (obj.channelTags) {
    let map = obj.channelTags;
    if (mode === 'merge') {
      const current = _readRaw(STORAGE_KEYS.CHANNEL_TAGS, {});
      for (const [url, tagIds] of Object.entries(obj.channelTags)) {
        if (!Array.isArray(tagIds)) continue;
        current[url] = [...new Set([...(current[url] || []), ...tagIds.map(id => tagIdRemap.get(id) || id)])];
      }
      map = current;
    }
    storage.save(STORAGE_KEYS.CHANNEL_TAGS, map);
  }

  // Обновляем UI, если соответствующие панели уже отрисованы
  updateFavSection();
  renderTagsSettingsTab();
  // storage.save() сам сбрасывает кэш настроек при ключе SETTINGS (см. storage.js),
  // так что здесь достаточно уведомить открытую форму настроек перечитать поля.
  applyImportedSettingsToUI();
  showStatus('Данные импортированы', 'success');
  return true;
}

/** После импорта настроек форма настроек (если открыта) может показывать старые
 *  значения из кэша loadSettingsToUI — перечитываем поля формы, если она в DOM. */
function applyImportedSettingsToUI() {
  document.dispatchEvent(new CustomEvent('web7tv:settings-imported'));
}

export function importDataFromFile(file) {
  if (!file) return;
  const mode = document.getElementById('importModeReplace')?.checked ? 'replace' : 'merge';
  const reader = new FileReader();
  reader.onload = () => {
    try {
      const obj = JSON.parse(reader.result);
      importDataFromObject(obj, mode);
    } catch (e) {
      console.error('Import parse error:', e);
      showStatus('Не удалось прочитать файл — неверный JSON', 'error');
    }
  };
  reader.onerror = () => showStatus('Ошибка чтения файла', 'error');
  reader.readAsText(file);
}

export function triggerImportPicker() {
  document.getElementById('importDataFile')?.click();
}
