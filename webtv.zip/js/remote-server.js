import { state } from './state.js';
import { navigateChannel } from './hotkeys.js';
import { playStream, vcTogglePlay, vcSetVolume, vcSetPlaybackRate, getNextChannel, getPrevChannel, toggleMute, seekVideo, changeVolume, restartCurrentVideo, toggleFullscreen, cyclePlayMode, setPlayMode, getPlayMode, closePlayer } from './player.js';
import { getFavourites, toggleFavourite, isFavourite } from './favourites.js';
import { getCurrentEPG, getChannelEPGKey } from './epg.js';
import { PLAY_MODES } from './constants.js';
import { loadSettings, playlistManager } from './storage.js';
import { loadSavedPlaylist } from './playlist.js';
import { toggleDemoMode, isDemoActive } from './demo.js';
import { showSettings, hideSettings } from './settings.js';
import { initWebrtcTv, handleWebrtcMessage } from './webrtc-tv.js';
const WS_PORT=8765;
let ws=null,pin=null;
const genId=()=>`${Date.now().toString(36)}${Math.random().toString(36).slice(2)}`;
const tvId=localStorage.getItem('remote_tv_id')||(localStorage.setItem('remote_tv_id',genId()),localStorage.getItem('remote_tv_id'));
function wsUrl(){const proto=location.protocol==='https:'?'wss':'ws';return `${proto}://${location.hostname}:${WS_PORT}`;}
function wsSend(msg){if(ws&&ws.readyState===1)ws.send(JSON.stringify(msg));}
initWebrtcTv(wsSend);
function connect(){
  ws=new WebSocket(wsUrl());
  ws.onopen=()=>ws.send(JSON.stringify({type:'hello',role:'tv',tv_id:tvId}));
  ws.onmessage=e=>{
    const msg=JSON.parse(e.data);
    if(msg.type==='pin'){pin=msg.pin;renderPin();}
    else if(msg.type==='remote_connected'){pushChannels();pushState();}
    else if(msg.type==='cmd')handleCmd(msg);
    else if(msg.type?.startsWith('webrtc_'))handleWebrtcMessage(msg);
  };
  ws.onclose=()=>setTimeout(connect,3000);
  ws.onerror=()=>ws.close();
}
function handleCmd(msg){
  switch(msg.cmd){
    case'play_pause':vcTogglePlay();break;
    case'volume':vcSetVolume(msg.val);break;
    case'volume_delta':changeVolume(msg.val/100);break;
    case'mute':toggleMute();break;
    case'rate':vcSetPlaybackRate(msg.val);break;
    case'restart':restartCurrentVideo();break;
    case'next':navigateChannel(1);break;
    case'prev':navigateChannel(-1);break;
    case'select':{const ch=state.allChannels.find(c=>c.url===msg.url);if(ch)playStream(ch.url,ch.title);break;}
    case'seek':seekVideo(msg.val);break;
    case'seek_to':{const v=document.getElementById('video');if(v&&v.duration)v.currentTime=Math.max(0,Math.min(v.duration,msg.val));break;}
    case'fullscreen':toggleFullscreen();break;
    case'play_mode_cycle':cyclePlayMode();break;
    case'play_mode_set':setPlayMode(msg.val);break;
    case'fav_toggle':{if(state.currentChannelUrl)toggleFavourite(state.currentChannelUrl);break;}
    case'fav_toggle_url':{if(msg.url)toggleFavourite(msg.url);pushChannels();break;}
    case'select_number':{const ch=state.allChannels[msg.val-1];if(ch)playStream(ch.url,ch.title);break;}
    case'demo_toggle':toggleDemoMode();break;
    case'close_player':closePlayer();break;
    case'playlist_switch':loadSavedPlaylist(msg.id);break;
    case'settings_open':showSettings(msg.tab||'ui');break;
    case'settings_close':hideSettings();break;
    case'get_channels':pushChannels();break;
  }
  pushState();
}
function pushChannels(){
  if(!ws||ws.readyState!==1)return;
  const list=state.allChannels.map(c=>({url:c.url,title:c.title,group:c.group||'',logo:c.logo||''}));
  const groups=[...new Set(list.map(c=>c.group).filter(Boolean))];
  const favs=getFavourites().map(f=>f.url);
  const playlists=playlistManager.getAll().map(p=>({id:p.id,name:p.name}));
  ws.send(JSON.stringify({type:'state',kind:'channels',channels:list,groups,favs,playlists}));
}
function pushState(){
  if(!ws||ws.readyState!==1)return;
  const v=document.getElementById('video');
  const ch=state.allChannels.find(c=>c.url===state.currentChannelUrl);
  const chNum=state.currentChannelUrl?state.allChannels.findIndex(c=>c.url===state.currentChannelUrl)+1:0;
  const now=ch?getCurrentEPG(ch.tvgId,ch.title):null;
  let nextTitle='';
  if(ch&&now){
    const key=getChannelEPGKey(ch.tvgId,ch.title);
    const programs=state.epgData[key]||[];
    const idx=programs.indexOf(now);
    nextTitle=idx>=0?(programs[idx+1]?.title||''):'';
  }
  ws.send(JSON.stringify({type:'state',kind:'playback',
    title:state.currentChannelTitle,url:state.currentChannelUrl,chNum,
    logo:ch?.logo||'',group:ch?.group||'',
    paused:v?.paused??true,volume:Math.round((v?.volume??1)*100),
    muted:v?.muted??false,rate:v?.playbackRate??1,
    fav:state.currentChannelUrl?isFavourite(state.currentChannelUrl):false,
    playMode:getPlayMode(),playModeIcon:PLAY_MODES[getPlayMode()]?.icon||'',
    epgNow:now?.title||'',epgNext:nextTitle,
    duration:v?.duration||0,currentTime:v?.currentTime||0,isLive:state.isLiveStream,
    demoActive:isDemoActive(),
    seekStep:loadSettings().seekStep??15}));
}
function renderPin(){
  let el=document.getElementById('remotePinBadge');
  if(!el){
    el=document.createElement('div');
    el.id='remotePinBadge';
    el.style.cssText='position:fixed;top:10px;right:10px;background:#000c;color:#0af;font:10px monospace;padding:6px 10px;border-radius:6px;z-index:9999;cursor:pointer;';
    el.title='PIN для пульта (нажмите, чтобы скрыть)';
    el.onclick=()=>el.remove();
    document.body.appendChild(el);
  }
  el.textContent=`${pin}`;
}
setInterval(()=>{if(ws&&ws.readyState===1)pushState();},2000);
connect();
