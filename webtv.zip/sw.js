const CACHE_VERSION = 'v7';
const CACHE_NAME = `web7tv-static-${CACHE_VERSION}`;
const PRECACHE_PATHS = [
  '',
  'index.html',
  'manifest.json',
  'css/style.css',
  'js/main.js',
  'js/player.js',
  'js/state.js',
  'js/storage.js',
  'js/ui.js',
  'js/epg.js',
  'js/drawer.js',
  'js/tags.js',
  'js/cast.js',
  'js/data-export.js',
  'js/pwa.js',
  'js/constants.js',
  'js/settings.js',
  'js/demo.js',
  'js/worker.js',
  'js/tv-nav.js',
  'js/hotkeys.js',
  'js/playlist.js',
  'js/favourites.js',
  'js/worker-bridge.js',
  'js/hls.js',
  'rc/',
  'rc/index.html',
  'rc/manifest.json',
  'css/remote.css',
  'js/remote-client.js',
  'js/remote-server.js',
  'js/webrtc-tv.js',
  'js/webrtc-remote.js',
  'favicon.ico',
  'icons/icon-72.png',
  'icons/icon-96.png',
  'icons/icon-128.png',
  'icons/icon-144.png',
  'icons/icon-152.png',
  'icons/icon-192.png',
  'icons/icon-384.png',
  'icons/icon-512.png',
  'icons/icon-maskable-192.png',
  'icons/icon-maskable-512.png',
  'icons/apple-touch-icon.png',
];
const PRECACHE_URLS = PRECACHE_PATHS.map((p) => new URL(p, self.registration.scope).href);
self.addEventListener('install', (event) => {
  event.waitUntil(
    caches.open(CACHE_NAME)
      .then((cache) => cache.addAll(PRECACHE_URLS))
      .then(() => self.skipWaiting())
  );
});
self.addEventListener('activate', (event) => {
  event.waitUntil(
    caches.keys()
      .then((keys) => Promise.all(
        keys.filter((k) => k.startsWith('web7tv-static-') && k !== CACHE_NAME)
            .map((k) => caches.delete(k))
      ))
      .then(() => self.clients.claim())
  );
});
function _isPrecachedAsset(request, url) {
  if (url.origin !== self.location.origin) return false;
  if (request.mode === 'navigate') return true;
  return PRECACHE_URLS.includes(url.href);
}
self.addEventListener('fetch', (event) => {
  const { request } = event;
  if (request.method !== 'GET') return;
  const url = new URL(request.url);
  if (!_isPrecachedAsset(request, url)) return;
  event.respondWith(
    caches.match(request).then((cached) => {
      if (cached) return cached;
      return fetch(request).then((response) => {
        if (response.ok && PRECACHE_URLS.includes(url.href)) {
          const copy = response.clone();
          caches.open(CACHE_NAME).then((cache) => cache.put(request, copy));
        }
        return response;
      }).catch(() => {
        if (request.mode === 'navigate') {
          const scope = self.registration.scope;
          const relPath = url.href.startsWith(scope) ? url.href.slice(scope.length) : '';
          const fallback = relPath.startsWith('rc') ? 'rc/index.html' : 'index.html';
          return caches.match(new URL(fallback, scope).href);
        }
        return new Response('', { status: 504, statusText: 'Offline' });
      });
    })
  );
});
