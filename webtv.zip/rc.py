import asyncio,json,secrets,time,os,ssl,sys,websockets

rooms={}
tv_ids={}
pin_attempts={}  # ip -> [timestamps неудачных попыток за последнюю минуту]
pin_blocked_until={}  # ip -> unix-время, до которого IP заблокирован

MAX_ATTEMPTS=3
ATTEMPTS_WINDOW_SEC=60
BLOCK_DURATION_SEC=3600
TV_IDS_GC_INTERVAL_SEC=1800

async def gc_tv_ids():
    while True:
        await asyncio.sleep(TV_IDS_GC_INTERVAL_SEC)
        for tid,p in list(tv_ids.items()):
            if p not in rooms:del tv_ids[tid]

def new_pin():
    return f'{secrets.randbelow(10000):04d}'

def is_blocked(ip):
    until=pin_blocked_until.get(ip)
    if until is None:return False
    if time.time()>=until:
        del pin_blocked_until[ip]
        pin_attempts.pop(ip,None)
        return False
    return True

def register_failed_attempt(ip):
    now=time.time()
    attempts=[t for t in pin_attempts.get(ip,[]) if now-t<ATTEMPTS_WINDOW_SEC]
    attempts.append(now)
    pin_attempts[ip]=attempts
    if len(attempts)>=MAX_ATTEMPTS:
        pin_blocked_until[ip]=now+BLOCK_DURATION_SEC
        pin_attempts.pop(ip,None)

def register_success(ip):
    pin_attempts.pop(ip,None)

async def handler(ws):
    role=pin=None
    ip=ws.remote_address[0] if ws.remote_address else 'unknown'
    try:
        async for raw in ws:
            msg=json.loads(raw)
            t=msg.get('type')
            if t=='hello':
                role=msg.get('role')
                if role=='tv':
                    tv_id=msg.get('tv_id')
                    pin=tv_ids.get(tv_id) if tv_id else None
                    if not pin or pin not in rooms:
                        pin=new_pin()
                        if tv_id:tv_ids[tv_id]=pin
                    rooms.setdefault(pin,{})['tv']=ws
                    print(pin)
                    await ws.send(json.dumps({'type':'pin','pin':pin}))
                elif role=='remote':
                    if is_blocked(ip):
                        remaining=int(pin_blocked_until[ip]-time.time())
                        await ws.send(json.dumps({'type':'error','msg':'blocked','retry_after':remaining}))
                        continue
                    pin=msg.get('pin')
                    room=rooms.get(pin)
                    if not room or 'tv' not in room:
                        register_failed_attempt(ip)
                        pin=None
                        await ws.send(json.dumps({'type':'error','msg':'invalid_pin'}))
                        continue
                    register_success(ip)
                    room['remote']=ws
                    await ws.send(json.dumps({'type':'joined'}))
                    tv=room.get('tv')
                    if tv:await tv.send(json.dumps({'type':'remote_connected'}))
            elif t=='cmd' and pin:
                room=rooms.get(pin,{})
                target=room.get('tv') if role=='remote' else room.get('remote')
                if target:
                    try:await target.send(raw)
                    except Exception:pass
            elif t=='state' and pin:
                room=rooms.get(pin,{})
                target=room.get('remote')
                if target:
                    try:await target.send(raw)
                    except Exception:pass
            elif t in('webrtc_offer','webrtc_answer','webrtc_ice','webrtc_request','webrtc_stop','webrtc_error')and pin:
                room=rooms.get(pin,{})
                target=room.get('tv')if role=='remote'else room.get('remote')
                if target:
                    try:await target.send(raw)
                    except Exception:pass
    finally:
        if pin and pin in rooms:
            room=rooms[pin]
            if room.get(role) is ws:del room[role]
            if not room:del rooms[pin]
            elif role=='tv':
                r=room.get('remote')
                if r:
                    try:await r.send(json.dumps({'type':'tv_disconnected'}))
                    except Exception:pass
def make_ssl():
    """TLS включается, если заданы сертификат и ключ: --cert/--key или RC_CERT/RC_KEY.
    Нужен, когда страница открыта по https (иначе браузер блокирует ws://)."""
    args=sys.argv[1:]
    def opt(name,env):
        if name in args and args.index(name)+1<len(args):return args[args.index(name)+1]
        return os.environ.get(env)
    cert,key=opt('--cert','RC_CERT'),opt('--key','RC_KEY')
    if not cert:return None
    ctx=ssl.SSLContext(ssl.PROTOCOL_TLS_SERVER)
    ctx.load_cert_chain(cert,key)
    return ctx

async def main():
    asyncio.create_task(gc_tv_ids())
    ctx=make_ssl()
    async with websockets.serve(handler,'0.0.0.0',8765,ssl=ctx,max_size=32*2**20):
        print(('wss' if ctx else 'ws')+' remote server on :8765')
        await asyncio.Future()

if __name__=='__main__':
    try:
        asyncio.run(main())
    except Exception as Ex:
        print(Ex)
